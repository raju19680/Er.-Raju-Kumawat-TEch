# Er. Raju Kumawat Tech - Education Platform

A comprehensive multi-portal education SaaS platform built with Next.js 16, TypeScript, and Prisma.

## 🚀 Features

### Three Portals
- **Admin Portal** - Platform administrators manage teachers, organizations, revenue, and analytics
- **CMS Portal** - Teachers manage courses, test series, digital products, blogs, and students
- **Student Portal** - Students browse, purchase, and consume educational content

### Key Capabilities
- ✅ Multi-organization (multi-tenant) architecture
- ✅ Role-based authentication (platform_admin, teacher, student)
- ✅ JWT + localStorage token-based auth
- ✅ Course management with modules and lessons
- ✅ Test series with MCQ tests, auto-grading, and analytics
- ✅ Digital products (notes, ebooks, PDFs)
- ✅ Razorpay payment integration with commission split
- ✅ Real-time notifications via Socket.IO
- ✅ SMTP email service
- ✅ PWA support (Progressive Web App)
- ✅ Dark/Light theme support
- ✅ **Auto database setup** - tables and seed data created automatically

## 🛠️ Tech Stack

| Technology | Purpose |
|------------|---------|
| Next.js 16 | App Router framework |
| TypeScript 5 | Type-safe JavaScript |
| Tailwind CSS 4 | Utility-first CSS |
| shadcn/ui | Component library |
| Prisma 6 | ORM (SQLite dev / PostgreSQL prod) |
| NextAuth.js 4 | Authentication |
| Zustand 5 | Client state management |
| Socket.IO | Real-time notifications |
| Razorpay | Payment gateway |
| Nodemailer | Email service |

## 📦 Installation & Auto-Setup

### Option 1: Quick Setup (Recommended)
```bash
# 1. Install dependencies (auto-generates Prisma client)
bun install

# 2. Copy environment file and edit
cp .env.example .env
# Edit .env with your values

# 3. Run auto-setup (creates tables + seeds data)
bun run setup
# OR: ./setup.sh

# 4. Start development server
bun run dev
```

### Option 2: Manual Setup
```bash
bun install
cp .env.example .env  # Edit with your values

# Create database tables
bun run db:push

# Seed initial data
bun run db:seed

# Start server
bun run dev
```

### Option 3: Auto-Setup via API (for hosting)
```bash
bun install
cp .env.example .env  # Edit with your values

# Start server (database auto-initializes on first API request)
bun run dev

# Then visit: http://localhost:3000/api/setup
# This creates all tables and seed data automatically
```

## 🗄️ Database Configuration

### SQLite (Development - Default)
```env
DATABASE_URL=file:./db/custom.db
```

### PostgreSQL (Production)
```env
DATABASE_URL=postgresql://user:password@localhost:5432/erkt?schema=public
```

### Supabase / Neon (Cloud PostgreSQL)
```env
DATABASE_URL=postgresql://user:password@host:6543/postgres?schema=public&pgbouncer=true
```

**Note**: The schema auto-adapts. Run `bun run db:push` after changing DATABASE_URL to create tables in the new database.

## 🔐 Login Credentials

| Role | Institute ID | Email | Password |
|------|-------------|-------|----------|
| Super Admin | 9680177120 | rajulalkumawat1995@gmail.com | Kumawat@4321 |
| Teacher 1 | ERKTACADEMY | ravi@errkt.com | Kumawat@4321 |
| Teacher 2 | DPS2024 | priya@dps.edu | Kumawat@4321 |
| Teacher 3 | MODA2024 | amit@modernacademy.in | Kumawat@4321 |
| Teacher 4 | VISN2024 | sneha@visionclasses.com | Kumawat@4321 |
| Teacher 5 | KSP2024 | vikram@kumawatstudy.com | Kumawat@4321 |

## 🧪 Commands

```bash
bun run dev          # Start dev server (port 3000)
bun run build        # Build for production (auto-runs prisma generate)
bun run start        # Start production server
bun run lint         # Run ESLint
bun run setup        # Auto-setup: create tables + seed data
bun run db:push      # Push schema to database (creates tables)
bun run db:generate  # Generate Prisma client
bun run db:seed      # Seed initial data
bun run test         # Run tests
```

## 📁 Project Structure

```
src/
├── app/
│   ├── page.tsx          # Main entry point (view router)
│   ├── layout.tsx        # Root layout
│   └── api/              # API routes (140+)
│       ├── setup/        # Auto-setup endpoint
│       ├── auth/         # Authentication
│       ├── admin/        # Admin APIs
│       ├── teacher/      # Teacher APIs
│       ├── student/      # Student APIs
│       └── payments/     # Payment + webhook
├── components/
│   ├── admin/            # Admin portal (26 pages)
│   ├── cms/              # CMS portal (26 pages)
│   ├── student-portal/   # Student portal (12 pages)
│   ├── login/            # Login & 2FA
│   ├── providers/        # Context providers
│   ├── shared/           # Shared components
│   └── ui/               # shadcn/ui components
├── lib/                  # Utilities, auth, db, store
└── hooks/                # React hooks

mini-services/
└── notification-service/ # Socket.IO server (port 3003)

prisma/
├── schema.prisma         # Database schema (35+ models)
└── seed.ts               # Seed data

public/
├── manifest.json         # PWA manifest
├── sw.js                 # Service worker
├── icons/                # PWA icons
├── banners/              # Banner images
└── favicon.ico           # Favicon
```

## 🌐 Services

| Service | Port | Purpose |
|---------|------|---------|
| Next.js App | 3000 | Main web application |
| Notification Service | 3003 | WebSocket server |

## 🚀 Deployment

### Deploy to Vercel/Netlify/Any Platform
1. Set environment variables (DATABASE_URL, NEXTAUTH_SECRET, etc.)
2. Run `bun install` (auto-generates Prisma client via postinstall)
3. Run `bun run setup` or visit `/api/setup` to create tables + seed data
4. The app is ready!

### Switch to PostgreSQL
1. Update `DATABASE_URL` in `.env` to PostgreSQL connection string
2. Run `bun run db:push` to create tables in PostgreSQL
3. Run `bun run db:seed` to seed data
4. Done!

## 📝 License

Copyright © 2024 Er. Raju Kumawat Tech. All Rights Reserved.
