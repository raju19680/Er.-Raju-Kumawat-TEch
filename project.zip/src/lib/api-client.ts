/**
 * API Client — Wrapper around fetch that automatically includes
 * the API token (x-auth-token) header for authenticated requests.
 *
 * Token is stored in BOTH localStorage AND a cookie for maximum reliability.
 * - localStorage: persists across reloads, fast access
 * - Cookie: works even when localStorage is blocked (iframes, incognito)
 */

const TOKEN_KEY = 'erkt_api_token'
const COOKIE_KEY = 'erkt_api_token'

/**
 * Get token from localStorage (primary) or cookie (fallback).
 */
export function getApiToken(): string | null {
  if (typeof window !== 'undefined') {
    // Try localStorage first
    try {
      const token = localStorage.getItem(TOKEN_KEY)
      if (token && token.length > 20) return token
    } catch {}

    // Fallback: try cookie
    try {
      const match = document.cookie.match(new RegExp('(?:^|; )' + COOKIE_KEY + '=([^;]*)'))
      if (match && match[1] && match[1].length > 20) return match[1]
    } catch {}
  }
  return null
}

/**
 * Set token in localStorage AND cookie.
 */
export function setApiToken(token: string | null) {
  if (typeof window !== 'undefined') {
    // Save to localStorage
    try {
      if (token && token.length > 20) {
        localStorage.setItem(TOKEN_KEY, token)
      } else {
        localStorage.removeItem(TOKEN_KEY)
      }
    } catch {}

    // Also save to cookie (works in iframes, incognito, etc.)
    try {
      if (token && token.length > 20) {
        document.cookie = `${COOKIE_KEY}=${token}; path=/; max-age=${8 * 60 * 60}; SameSite=Lax`
      } else {
        document.cookie = `${COOKIE_KEY}=; path=/; max-age=0`
      }
    } catch {}
  }

  // Also sync to Zustand store
  if (typeof window !== 'undefined') {
    import('@/lib/store')
      .then(({ useAppStore }) => useAppStore.getState().setApiToken(token || ''))
      .catch(() => {})
  }
}

/**
 * Clear token from everywhere.
 */
export function clearApiToken() {
  if (typeof window !== 'undefined') {
    try { localStorage.removeItem(TOKEN_KEY) } catch {}
    try { document.cookie = `${COOKIE_KEY}=; path=/; max-age=0` } catch {}
  }
  if (typeof window !== 'undefined') {
    import('@/lib/store')
      .then(({ useAppStore }) => useAppStore.getState().setApiToken(''))
      .catch(() => {})
  }
}

/**
 * Check if token is valid (just length check - server handles expiry).
 */
function isTokenExpired(token: string): boolean {
  if (!token || token.length < 20) return true
  return false
}

/**
 * Make an authenticated API request.
 * Sends x-auth-token header from localStorage/cookie.
 */
export async function apiFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const token = getApiToken()

  const headers = new Headers(options.headers || {})

  if (token) {
    if (isTokenExpired(token)) {
      clearApiToken()
    } else {
      headers.set('x-auth-token', token)
    }
  }

  if (options.body && !headers.has('Content-Type')) {
    if (typeof options.body === 'string') {
      headers.set('Content-Type', 'application/json')
    }
  }

  return fetch(url, { ...options, headers, credentials: 'include' })
}

/**
 * Make an authenticated API request and parse JSON.
 */
export async function apiFetchJSON<T = any>(url: string, options: RequestInit = {}): Promise<T> {
  const res = await apiFetch(url, options)
  if (!res.ok) {
    let errorMsg = `API Error ${res.status}`
    try {
      const text = await res.text()
      if (text) {
        try {
          const json = JSON.parse(text)
          errorMsg = json.message || json.error || errorMsg
        } catch {
          errorMsg = text.substring(0, 200)
        }
      }
    } catch {}
    throw new Error(errorMsg)
  }
  return res.json()
}
