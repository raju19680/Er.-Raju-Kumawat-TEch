import { create } from 'zustand'
import { apiFetch } from '@/lib/api-client'

// Module-level variable for the polling interval (not serializable, can't be in Zustand state)
let _moduleAccessPollingInterval: ReturnType<typeof setInterval> | null = null

// Navigation items for the sidebar
export type SidebarItem = {
  id: string
  label: string
  icon: string
  children?: SidebarItem[]
}

export type AppView = 'login' | 'cms' | 'admin' | 'student'

export type CMSPage =
  | 'dashboard'
  | 'digital-products'
  | 'store'
  | 'blogs'
  | 'quick-links'
  | 'tests'
  | 'results'
  | 'bulk-uploader'
  | 'reported-questions'
  | 'question-library'
  | 'reports-sales'
  | 'reports-orders'
  | 'reports-users'
  | 'graphics'
  | 'notifications'
  | 'leads'
  | 'coupons'
  | 'payment-pages'
  | 'whatsapp-sales'
  | 'whatsapp-campaigns'
  | 'support-queries'
  | 'support-chat'
  | 'settings-profile'
  | 'settings-security'
  | 'settings-blocked'
  | 'settings-categories'
  | 'chat-manager'
  | 'meetings'
  | 'youtube-courses'
  | 'documents'

export type AdminPage =
  | 'admin-dashboard'
  | 'admin-teachers'
  | 'admin-students'
  | 'admin-organizations'
  | 'admin-analytics'
  | 'admin-orders'
  | 'admin-notifications'
  | 'admin-settings'
  | 'admin-module-access'
  | 'admin-content'
  | 'admin-security'
  | 'admin-commissions'
  | 'admin-builds'
  | 'admin-audit-log'
  | 'admin-bulk-ops'
  | 'admin-payouts'
  | 'admin-health'
  | 'admin-announcements'
  | 'admin-feature-flags'
  | 'admin-app-versions'
  | 'admin-scheduled-notifications'
  | 'admin-db-backup'
  | 'admin-white-label'
  | 'admin-dynamic-config'
  | 'admin-email-templates'
  | 'admin-student-mgmt'

export type StudentPage =
  | 'dashboard'
  | 'my-tests'
  | 'my-courses'
  | 'results'
  | 'profile'
  | 'test-series-detail'
  | 'take-test'
  | 'test-result'
  | 'course-detail'
  | 'store'
  | 'store-product-detail'
  | 'my-library'

interface AppState {
  // Auth
  isAuthenticated: boolean
  currentView: AppView
  orgCode: string
  orgName: string
  userName: string
  userEmail: string
  userRole: string
  loginMode: string // 'admin', 'cms', or 'student'

  // CMS Navigation
  currentPage: CMSPage
  sidebarCollapsed: boolean
  sidebarMobileOpen: boolean

  // Admin Navigation
  adminPage: AdminPage
  adminSidebarCollapsed: boolean
  adminSidebarMobileOpen: boolean

  // Student Navigation
  studentPage: StudentPage
  studentSidebarCollapsed: boolean
  studentSidebarMobileOpen: boolean
  selectedTestSeriesId: string
  selectedTestId: string
  selectedCourseId: string
  selectedAttemptId: string

  // Global search
  globalSearchOpen: boolean
  globalSearchQuery: string

  // API token for admin requests
  apiToken: string

  // Module Access (for CMS portal - teacher's enabled modules)
  moduleAccess: Record<string, boolean>
  moduleAccessLoaded: boolean

  // Admin: pre-selected teacher for module-access page
  adminSelectedTeacherId: string | null

  // Checkout state — allows any child page to trigger payment checkout
  checkoutOpen: boolean
  checkoutItem: {
    id: string
    type: 'test_series' | 'course' | 'digital_product'
    title: string
    price: number
    mrp: number
    thumbnail: string | null
  } | null

  // Logout guard — prevents SessionSync/useAuthSync from re-authenticating during logout
  loggingOut: boolean

  // Actions
  login: (orgCode: string, orgName: string, userName: string, userEmail: string, role: string, loginMode?: string) => void
  logout: () => void
  setCurrentView: (view: AppView) => void
  setCurrentPage: (page: CMSPage) => void
  toggleSidebar: () => void
  setSidebarCollapsed: (collapsed: boolean) => void
  setSidebarMobileOpen: (open: boolean) => void
  setAdminPage: (page: AdminPage) => void
  toggleAdminSidebar: () => void
  setAdminSidebarCollapsed: (collapsed: boolean) => void
  setAdminSidebarMobileOpen: (open: boolean) => void
  setStudentPage: (page: StudentPage) => void
  toggleStudentSidebar: () => void
  setStudentSidebarCollapsed: (collapsed: boolean) => void
  setStudentSidebarMobileOpen: (open: boolean) => void
  setSelectedTestSeriesId: (id: string) => void
  setSelectedTestId: (id: string) => void
  setSelectedCourseId: (id: string) => void
  setSelectedAttemptId: (id: string) => void
  setGlobalSearchOpen: (open: boolean) => void
  setGlobalSearchQuery: (query: string) => void
  setApiToken: (token: string) => void
  setAdminSelectedTeacherId: (id: string | null) => void
  openCheckout: (item: { id: string; type: 'test_series' | 'course' | 'digital_product'; title: string; price: number; mrp: number; thumbnail: string | null }) => void
  closeCheckout: () => void
  fetchModuleAccess: () => Promise<void>
  setModuleAccess: (access: Record<string, boolean>) => void
  startModuleAccessPolling: () => void
  stopModuleAccessPolling: () => void
}

export const useAppStore = create<AppState>((set) => ({
  // Auth defaults
  isAuthenticated: false,
  currentView: 'login',
  orgCode: '',
  orgName: 'Er. Raju Kumawat Tech',
  userName: '',
  userEmail: '',
  userRole: '',
  loginMode: '',

  // CMS Navigation
  currentPage: 'dashboard',
  sidebarCollapsed: true,
  sidebarMobileOpen: false,

  // Admin Navigation
  adminPage: 'admin-dashboard',
  adminSidebarCollapsed: true,
  adminSidebarMobileOpen: false,

  // Student Navigation
  studentPage: 'dashboard',
  studentSidebarCollapsed: false,
  studentSidebarMobileOpen: false,
  selectedTestSeriesId: '',
  selectedTestId: '',
  selectedCourseId: '',
  selectedAttemptId: '',

  // Search
  globalSearchOpen: false,
  globalSearchQuery: '',

  // API token
  apiToken: '',

  // Module Access
  moduleAccess: {},
  moduleAccessLoaded: false,

  // Admin: pre-selected teacher
  adminSelectedTeacherId: null,

  // Checkout
  checkoutOpen: false,
  checkoutItem: null,

  // Logout guard
  loggingOut: false,

  // Actions
  login: (orgCode, orgName, userName, userEmail, role, loginMode) => {
    // Role-based portal redirect:
    // platform_admin → Admin Portal
    // teacher → CMS Portal
    // student → Student Portal
    const mode = loginMode || (role === 'platform_admin' ? 'admin' : role === 'student' ? 'student' : 'cms')

    console.log(`[STORE] login() called: role=${role}, loginMode=${loginMode}, computed mode=${mode}`)

    // Record login time for grace period in session checks
    if (typeof window !== 'undefined') {
      ;(window as any).__ERKT_LOGIN_TIME__ = Date.now()
    }

    let view: AppView = 'cms'
    if (mode === 'admin') {
      view = 'admin'
    } else if (mode === 'student') {
      view = 'student'
    } else {
      view = 'cms'
    }

    set({
      isAuthenticated: true,
      currentView: view,
      orgCode,
      orgName,
      userName,
      userEmail,
      userRole: role,
      loginMode: mode,
    })
  },

  logout: () => {
    // Set loggingOut flag FIRST to prevent SessionSync/useAuthSync from re-authenticating
    set({ loggingOut: true })

    // Clear API token from localStorage
    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem('erkt_api_token')
      } catch {}
    }

    // Clear polling interval directly before resetting state
    if (_moduleAccessPollingInterval) {
      clearInterval(_moduleAccessPollingInterval)
      _moduleAccessPollingInterval = null
    }

    // Reset all Zustand state
    set({
      isAuthenticated: false,
      currentView: 'login',
      orgCode: '',
      orgName: 'Er. Raju Kumawat Tech',
      userName: '',
      userEmail: '',
      userRole: '',
      loginMode: '',
      currentPage: 'dashboard',
      adminPage: 'admin-dashboard',
      studentPage: 'dashboard',
      studentSidebarCollapsed: false,
      studentSidebarMobileOpen: false,
      selectedTestSeriesId: '',
      selectedTestId: '',
      selectedCourseId: '',
      selectedAttemptId: '',
      apiToken: '',
      adminSelectedTeacherId: null,
      checkoutOpen: false,
      checkoutItem: null,
      moduleAccess: {},
      moduleAccessLoaded: false,
    })

    // Sign out from NextAuth and clear loggingOut flag when done
    import('next-auth/react')
      .then(({ signOut }) => signOut({ redirect: false }))
      .finally(() => {
        // Clear the loggingOut flag after signOut completes (or fails)
        // Only clear if we're still on login view (not re-authenticated)
        const state = useAppStore.getState()
        if (state.currentView === 'login') {
          set({ loggingOut: false })
        }
      })
  },

  setCurrentView: (view) => set({ currentView: view }),
  setCurrentPage: (page) => set({ currentPage: page, sidebarMobileOpen: false }),
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
  setSidebarMobileOpen: (open) => set({ sidebarMobileOpen: open }),

  setAdminPage: (page) => {
    // Auto-prefix with 'admin-' if not present, to be forgiving of callers
    const normalizedPage = page.startsWith('admin-') ? page : `admin-${page}` as typeof page
    set({ adminPage: normalizedPage, adminSidebarMobileOpen: false })
  },
  toggleAdminSidebar: () => set((s) => ({ adminSidebarCollapsed: !s.adminSidebarCollapsed })),
  setAdminSidebarCollapsed: (collapsed) => set({ adminSidebarCollapsed: collapsed }),
  setAdminSidebarMobileOpen: (open) => set({ adminSidebarMobileOpen: open }),

  setStudentPage: (page) => set({ studentPage: page, studentSidebarMobileOpen: false }),
  toggleStudentSidebar: () => set((s) => ({ studentSidebarCollapsed: !s.studentSidebarCollapsed })),
  setStudentSidebarCollapsed: (collapsed) => set({ studentSidebarCollapsed: collapsed }),
  setStudentSidebarMobileOpen: (open) => set({ studentSidebarMobileOpen: open }),
  setSelectedTestSeriesId: (id) => set({ selectedTestSeriesId: id }),
  setSelectedTestId: (id) => set({ selectedTestId: id }),
  setSelectedCourseId: (id) => set({ selectedCourseId: id }),
  setSelectedAttemptId: (id) => set({ selectedAttemptId: id }),

  setGlobalSearchOpen: (open) => set({ globalSearchOpen: open }),
  setGlobalSearchQuery: (query) => set({ globalSearchQuery: query }),
  setApiToken: (token) => set({ apiToken: token }),
  setAdminSelectedTeacherId: (id) => set({ adminSelectedTeacherId: id }),

  openCheckout: (item) => set({ checkoutOpen: true, checkoutItem: item }),
  closeCheckout: () => set({ checkoutOpen: false, checkoutItem: null }),

  setModuleAccess: (access) => set({ moduleAccess: access, moduleAccessLoaded: true }),

  fetchModuleAccess: async () => {
    const MAX_RETRIES = 2
    const RETRY_DELAY_MS = 1000

    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        const res = await apiFetch('/api/teacher/module-access')

        // If we get a 401, the API token may not be set yet — retry after a delay
        if (res.status === 401 && attempt < MAX_RETRIES - 1) {
          await new Promise((r) => setTimeout(r, RETRY_DELAY_MS))
          continue
        }

        const data = await res.json()
        if (data.success) {
          set({ moduleAccess: data.modules, moduleAccessLoaded: true })
        } else {
          // Only mark as loaded after exhausting retries
          set({ moduleAccessLoaded: true })
        }
        return
      } catch {
        // If this isn't the last attempt, wait and retry
        if (attempt < MAX_RETRIES - 1) {
          await new Promise((r) => setTimeout(r, RETRY_DELAY_MS))
          continue
        }
        // All retries exhausted — mark as loaded so the UI isn't stuck in grace period forever
        set({ moduleAccessLoaded: true })
      }
    }
  },

  startModuleAccessPolling: () => {
    // Don't start if already polling
    if (_moduleAccessPollingInterval) return

    // Fetch immediately
    const { fetchModuleAccess, userRole } = useAppStore.getState()
    if (userRole !== 'teacher') return
    fetchModuleAccess()

    // Set up interval to poll every 30 seconds
    _moduleAccessPollingInterval = setInterval(() => {
      const state = useAppStore.getState()
      // Only fetch if still a teacher and authenticated
      if (state.isAuthenticated && state.userRole === 'teacher') {
        state.fetchModuleAccess()
      } else {
        // Stop polling if no longer a teacher
        if (_moduleAccessPollingInterval) {
          clearInterval(_moduleAccessPollingInterval)
          _moduleAccessPollingInterval = null
        }
      }
    }, 30000)
  },

  stopModuleAccessPolling: () => {
    if (_moduleAccessPollingInterval) {
      clearInterval(_moduleAccessPollingInterval)
      _moduleAccessPollingInterval = null
    }
  },
}))

// Export the module-level interval accessors for use in components
export function isModuleAccessPolling(): boolean {
  return _moduleAccessPollingInterval !== null
}

// Dev-only: expose store on window for debugging
if (typeof window !== 'undefined') {
  (window as any).__APP_STORE__ = useAppStore
}


// ── Manual localStorage hydration (replaces persist middleware for Turbopack compatibility) ──
const STORAGE_KEY = 'erkt-auth-store'

function saveToStorage() {
  if (typeof window === 'undefined') return
  try {
    const state = useAppStore.getState()
    const persistData = {
      isAuthenticated: state.isAuthenticated,
      currentView: state.currentView,
      orgCode: state.orgCode,
      orgName: state.orgName,
      userName: state.userName,
      userEmail: state.userEmail,
      userRole: state.userRole,
      loginMode: state.loginMode,
      apiToken: state.apiToken,
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(persistData))
  } catch {}
}

function loadFromStorage() {
  if (typeof window === 'undefined') return
  try {
    const data = localStorage.getItem(STORAGE_KEY)
    if (data) {
      const parsed = JSON.parse(data)
      useAppStore.setState(parsed)
    }
  } catch {}
}

// Hydrate on load (client-side only)
if (typeof window !== 'undefined') {
  loadFromStorage()
  
  // Subscribe to state changes and save
  let saveTimeout: ReturnType<typeof setTimeout> | null = null
  useAppStore.subscribe(() => {
    if (saveTimeout) clearTimeout(saveTimeout)
    saveTimeout = setTimeout(saveToStorage, 100)
  })
}
