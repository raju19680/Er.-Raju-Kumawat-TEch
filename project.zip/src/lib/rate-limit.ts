// ─── In-Memory Rate Limiter ──────────────────────────────────────────────────
// Tracks per-IP request counts for auth endpoints.
// Max 10 requests per minute per IP. Expired entries cleaned up every 60s.

interface RateLimitEntry {
  count: number
  resetTime: number
}

const rateLimitMap = new Map<string, RateLimitEntry>()

const WINDOW_MS = 60_000 // 1 minute
const MAX_REQUESTS = 30

// Periodic cleanup of expired entries
let cleanupTimer: ReturnType<typeof setInterval> | null = null

function startCleanup() {
  if (cleanupTimer) return
  cleanupTimer = setInterval(() => {
    const now = Date.now()
    for (const [key, entry] of rateLimitMap.entries()) {
      if (now >= entry.resetTime) {
        rateLimitMap.delete(key)
      }
    }
  }, 60_000)
}

// Auto-start cleanup on first import
startCleanup()

export interface RateLimitResult {
  allowed: boolean
  remaining: number
  resetTime: number
}

/**
 * Check if a request from the given key (IP) is allowed.
 * Returns { allowed, remaining, resetTime }.
 */
export function checkRateLimit(key: string): RateLimitResult {
  const now = Date.now()

  const entry = rateLimitMap.get(key)

  if (!entry || now >= entry.resetTime) {
    // New window
    const resetTime = now + WINDOW_MS
    rateLimitMap.set(key, { count: 1, resetTime })
    return { allowed: true, remaining: MAX_REQUESTS - 1, resetTime }
  }

  // Existing window
  entry.count += 1

  if (entry.count > MAX_REQUESTS) {
    return { allowed: false, remaining: 0, resetTime: entry.resetTime }
  }

  return { allowed: true, remaining: MAX_REQUESTS - entry.count, resetTime: entry.resetTime }
}

/**
 * Extract a client IP from Next.js request headers.
 * Falls back to 'unknown' if no IP headers are found.
 */
export function getClientIp(headers: Headers): string {
  const forwarded = headers.get('x-forwarded-for')
  if (forwarded) {
    return forwarded.split(',')[0].trim()
  }

  const realIp = headers.get('x-real-ip')
  if (realIp) {
    return realIp.trim()
  }

  return 'unknown'
}
