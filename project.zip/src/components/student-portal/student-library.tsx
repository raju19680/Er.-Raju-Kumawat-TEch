'use client'

import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Library,
  BookOpen,
  FileText,
  Package,
  Download,
  Loader2,
  AlertCircle,
  RotateCcw,
  Clock,
  ExternalLink,
} from 'lucide-react'
import { useAppStore } from '@/lib/store'
import { apiFetchJSON } from '@/lib/api-client'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { toast } from 'sonner'

interface PurchasedDigitalProduct {
  id: string
  digitalProductId: string
  accessUrl: string | null
  expiresAt: string | null
  createdAt: string
  digitalProduct: {
    id: string
    title: string
    description: string | null
    thumbnail: string | null
    file: string | null
    type: string
    category: string | null
    price: number
    mrp: number
  }
}

const typeIcons: Record<string, React.ElementType> = {
  ebook: BookOpen,
  notes: FileText,
  other: Package,
}

const typeGradients: Record<string, string> = {
  ebook: 'from-amber-500 to-orange-400',
  notes: 'from-emerald-500 to-teal-400',
  other: 'from-violet-500 to-purple-400',
}

const typeLabels: Record<string, string> = {
  ebook: 'E-Book',
  notes: 'Notes',
  other: 'Other',
}

const typeBadgeColors: Record<string, string> = {
  ebook: 'bg-amber-50 text-amber-700',
  notes: 'bg-emerald-50 text-emerald-700',
  other: 'bg-violet-50 text-violet-700',
}

function ProductSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
      {Array.from({ length: 3 }).map((_, i) => (
        <Card key={i} className="rounded-xl overflow-hidden py-0">
          <Skeleton className="h-36 w-full" />
          <CardContent className="p-4 space-y-3">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-1/2" />
            <Skeleton className="h-9 w-full rounded-lg" />
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

export default function StudentLibrary() {
  const { setStudentPage } = useAppStore()
  const [products, setProducts] = useState<PurchasedDigitalProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await apiFetchJSON<{ success: boolean; products: PurchasedDigitalProduct[] }>(
        '/api/student/digital-products/library'
      )
      if (res.success) {
        setProducts(res.products)
      }
    } catch (err) {
      console.error('Library load error:', err)
      setError('Failed to load your library. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleDownload = (item: PurchasedDigitalProduct) => {
    const url = item.accessUrl || item.digitalProduct.file
    if (!url) {
      toast.error('No download available for this product')
      return
    }
    window.open(url, '_blank')
    toast.success('Download started!')
  }

  const handleViewDetail = (productId: string) => {
    useAppStore.getState().setSelectedCourseId(productId)
    setStudentPage('store-product-detail')
  }

  const renderProductGrid = (items: PurchasedDigitalProduct[]) => {
    if (items.length === 0) {
      return (
        <div className="text-center py-12 text-gray-400">
          <Library className="size-12 mx-auto mb-3 opacity-40" />
          <p className="text-base font-medium">No products yet</p>
          <p className="text-sm mt-1">Products you purchase will appear here</p>
          <Button
            variant="outline"
            className="mt-4 gap-2"
            onClick={() => setStudentPage('store')}
          >
            Browse Store
          </Button>
        </div>
      )
    }

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {items.map((item, idx) => {
          const IconComp = typeIcons[item.digitalProduct.type] || Package
          const gradient = typeGradients[item.digitalProduct.type] || typeGradients.other
          const badgeColor = typeBadgeColors[item.digitalProduct.type] || typeBadgeColors.other
          const typeLabel = typeLabels[item.digitalProduct.type] || 'Product'

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.08 }}
            >
              <Card className="group border border-gray-100 rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg hover:border-gray-200 py-0">
                {/* Thumbnail */}
                <div className={`relative h-36 flex items-center justify-center bg-gradient-to-br ${gradient}`}>
                  <div className="absolute inset-0 bg-black/5" />
                  <IconComp className="size-12 text-white/80" />
                  <Badge className="absolute top-3 right-3 bg-emerald-500 text-white text-xs font-semibold">
                    Owned
                  </Badge>
                  {item.digitalProduct.category && (
                    <Badge className={`absolute top-3 left-3 text-xs font-semibold ${badgeColor}`}>
                      {typeLabel}
                    </Badge>
                  )}
                </div>

                <CardContent className="p-4 flex flex-col gap-3">
                  <h3 className="font-semibold text-gray-900 text-sm sm:text-base leading-snug line-clamp-2">
                    {item.digitalProduct.title}
                  </h3>
                  {item.digitalProduct.description && (
                    <p className="text-gray-500 text-xs line-clamp-2">{item.digitalProduct.description}</p>
                  )}
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Clock className="size-3.5" />
                    <span>Purchased {new Date(item.createdAt).toLocaleDateString()}</span>
                  </div>
                  {item.expiresAt && (
                    <div className="flex items-center gap-1.5 text-xs text-amber-600">
                      <AlertCircle className="size-3.5" />
                      <span>Expires {new Date(item.expiresAt).toLocaleDateString()}</span>
                    </div>
                  )}
                  <div className="flex gap-2">
                    <Button
                      className="flex-1 font-semibold rounded-lg bg-amber-600 hover:bg-amber-700 text-white"
                      onClick={() => handleDownload(item)}
                    >
                      <Download className="size-4 mr-1" />
                      Download
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="shrink-0 rounded-lg"
                      onClick={() => handleViewDetail(item.digitalProduct.id)}
                    >
                      <ExternalLink className="size-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>
    )
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Library</h1>
          <p className="text-gray-500 text-sm mt-1">Access your purchased E-Books, Notes, and digital products</p>
        </div>
        <ProductSkeleton />
      </div>
    )
  }

  if (error) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Library</h1>
          <p className="text-gray-500 text-sm mt-1">Access your purchased E-Books, Notes, and digital products</p>
        </div>
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="flex items-center justify-center w-16 h-16 rounded-full bg-red-50 mb-4">
            <AlertCircle className="size-8 text-red-500" />
          </div>
          <h2 className="text-lg font-semibold text-gray-900 mb-1">Failed to Load</h2>
          <p className="text-gray-500 text-sm mb-4">{error}</p>
          <Button variant="outline" className="gap-2" onClick={load}>
            <RotateCcw className="size-4" /> Try Again
          </Button>
        </div>
      </div>
    )
  }

  const ebooks = products.filter(p => p.digitalProduct.type === 'ebook')
  const notes = products.filter(p => p.digitalProduct.type === 'notes')
  const others = products.filter(p => p.digitalProduct.type === 'other')

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-amber-100 text-amber-600">
          <Library className="size-5" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Library</h1>
          <p className="text-gray-500 text-sm mt-0.5">Access your purchased E-Books, Notes, and digital products</p>
        </div>
      </div>

      {/* Tabs for product types */}
      {products.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <Library className="size-16 mx-auto mb-4 opacity-30" />
          <p className="text-lg font-medium">Your library is empty</p>
          <p className="text-sm mt-1 mb-4">Start building your collection by browsing the store!</p>
          <Button
            className="gap-2 bg-amber-600 hover:bg-amber-700 text-white"
            onClick={() => setStudentPage('store')}
          >
            Browse Store
          </Button>
        </div>
      ) : (
        <Tabs defaultValue="ebook">
          <TabsList className="bg-gray-100">
            <TabsTrigger value="ebook" className="text-xs sm:text-sm">
              E-Books ({ebooks.length})
            </TabsTrigger>
            <TabsTrigger value="notes" className="text-xs sm:text-sm">
              Notes ({notes.length})
            </TabsTrigger>
            <TabsTrigger value="other" className="text-xs sm:text-sm">
              Other ({others.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ebook" className="mt-6">
            {renderProductGrid(ebooks)}
          </TabsContent>
          <TabsContent value="notes" className="mt-6">
            {renderProductGrid(notes)}
          </TabsContent>
          <TabsContent value="other" className="mt-6">
            {renderProductGrid(others)}
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}
