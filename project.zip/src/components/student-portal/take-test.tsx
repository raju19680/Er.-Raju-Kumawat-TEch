'use client'

import React, { useState, useEffect, useCallback, useRef } from 'react'
import { motion } from 'framer-motion'
import {
  Clock,
  ChevronLeft,
  ChevronRight,
  Flag,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  BookmarkCheck,
  ClipboardList,
  AlertCircle,
  RotateCcw,
} from 'lucide-react'
import { useAppStore } from '@/lib/store'
import { apiFetchJSON } from '@/lib/api-client'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { toast } from 'sonner'

interface Question {
  id: string
  type: string
  heading: string | null
  directive: string | null
  title: string
  image1: string | null
  image2: string | null
  image3: string | null
  option1: string | null
  option2: string | null
  option3: string | null
  option4: string | null
  option5: string | null
  option1Image: string | null
  option2Image: string | null
  option3Image: string | null
  option4Image: string | null
  option5Image: string | null
  correctOption?: string | null
  section: string | null
  positiveMarks: number
  negativeMarks: number
  sortOrder: number
}

interface TestData {
  id: string
  title: string
  instructions: string | null
  totalDuration: number
  numberOfQuestions: number
  totalMarks: number
  isLive: boolean
  maxAttempts: number
  negativeMarks: number
  showSolution: boolean
  hasInProgress: boolean
  inProgressAttemptId: string | null
  questions: Question[]
}

export default function TakeTest() {
  const { selectedTestId, setStudentPage, setSelectedAttemptId } = useAppStore()
  const [test, setTest] = useState<TestData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [currentQ, setCurrentQ] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [markedForReview, setMarkedForReview] = useState<Set<string>>(new Set())
  const [timeLeft, setTimeLeft] = useState(0)
  const [submitting, setSubmitting] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const [showInstructions, setShowInstructions] = useState(true)
  const [attemptId, setAttemptId] = useState<string | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const answersRef = useRef(answers)
  answersRef.current = answers

  const load = async () => {
    if (!selectedTestId) return
    setLoading(true)
    setError(null)
    try {
      const res = await apiFetchJSON<{ success: boolean; test: TestData }>(
        `/api/student/tests/${selectedTestId}`
      )
      if (res.success) {
        setTest(res.test)
        setTimeLeft((res.test.totalDuration || 0) * 60)
        if (res.test.hasInProgress && res.test.inProgressAttemptId) {
          setAttemptId(res.test.inProgressAttemptId)
        }
      }
    } catch (err) {
      console.error('Load test error:', err)
      setError('Failed to load test. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [selectedTestId])

  // Start attempt and timer
  const handleStartTest = useCallback(async () => {
    if (!test) return
    try {
      if (!attemptId) {
        const res = await apiFetchJSON<{ success: boolean; attempt: { id: string }; message?: string }>(
          '/api/student/test-attempts',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ testId: test.id }),
          }
        )
        if (res.success) {
          setAttemptId(res.attempt.id)
        } else {
          toast.error(res.message || 'Failed to start test')
          return
        }
      }
      setShowInstructions(false)
      // Start timer
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            if (timerRef.current) clearInterval(timerRef.current)
            // Auto-submit
            handleSubmit(true)
            return 0
          }
          return prev - 1
        })
      }, 1000)
    } catch (err) {
      console.error('Start attempt error:', err)
      toast.error('Failed to start test. Please try again.')
    }
  }, [test, attemptId])

  const handleSubmit = useCallback(async (autoSubmit = false) => {
    if (!autoSubmit && !showConfirm) {
      setShowConfirm(true)
      return
    }

    setSubmitting(true)
    if (timerRef.current) clearInterval(timerRef.current)

    try {
      const timeTaken = test ? (test.totalDuration * 60) - timeLeft : 0
      let currentAttemptId = attemptId

      // If no attempt exists yet, create one first
      if (!currentAttemptId && test) {
        const createRes = await apiFetchJSON<{ success: boolean; attempt: { id: string } }>(
          '/api/student/test-attempts',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ testId: test.id }),
          }
        )
        if (createRes.success && createRes.attempt?.id) {
          currentAttemptId = createRes.attempt.id
          setAttemptId(currentAttemptId)
        } else {
          toast.error('Failed to create test attempt')
          return
        }
      }

      // Submit the attempt with answers
      const res = await apiFetchJSON<{ success: boolean; attempt: { id: string } }>(
        `/api/student/test-attempts/${currentAttemptId}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: answersRef.current,
            timeTaken,
          }),
        }
      )
      if (res.success) {
        setSelectedAttemptId(res.attempt?.id || currentAttemptId || '')
        setStudentPage('test-result')
      } else {
        toast.error('Failed to submit test')
      }
    } catch (err) {
      console.error('Submit test error:', err)
      toast.error('Failed to submit test. Please try again.')
    } finally {
      setSubmitting(false)
      setShowConfirm(false)
    }
  }, [test, timeLeft, attemptId, setSelectedAttemptId, setStudentPage, showConfirm])

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [])

  const selectAnswer = (questionId: string, option: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: option }))
  }

  const toggleMultipleAnswer = (questionId: string, option: string) => {
    setAnswers((prev) => {
      const current = prev[questionId] || ''
      const parts = current ? current.split(',') : []
      if (parts.includes(option)) {
        return { ...prev, [questionId]: parts.filter((p) => p !== option).join(',') }
      }
      return { ...prev, [questionId]: [...parts, option].join(',') }
    })
  }

  const toggleReview = (questionId: string) => {
    setMarkedForReview((prev) => {
      const next = new Set(prev)
      if (next.has(questionId)) next.delete(questionId)
      else next.add(questionId)
      return next
    })
  }

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600)
    const m = Math.floor((seconds % 3600) / 60)
    const s = seconds % 60
    if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
    return `${m}:${String(s).padStart(2, '0')}`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Loader2 className="size-8 animate-spin text-amber-600 mx-auto mb-4" />
          <p className="text-sm text-gray-500">Loading test...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center max-w-md">
          <div className="flex items-center justify-center w-16 h-16 rounded-full bg-red-50 mx-auto mb-4">
            <AlertCircle className="size-8 text-red-500" />
          </div>
          <h2 className="text-lg font-semibold text-gray-900 mb-1">Failed to Load Test</h2>
          <p className="text-gray-500 text-sm mb-4">{error}</p>
          <Button variant="outline" className="gap-2" onClick={load}>
            <RotateCcw className="size-4" /> Try Again
          </Button>
        </div>
      </div>
    )
  }

  if (!test) {
    return (
      <div className="flex items-center justify-center min-h-screen text-gray-400">
        <div className="text-center">
          <AlertCircle className="size-12 mx-auto mb-3 opacity-40" />
          <p className="text-base font-medium">Test not found</p>
          <Button variant="outline" className="mt-3" onClick={() => setStudentPage('my-tests')}>
            Go Back
          </Button>
        </div>
      </div>
    )
  }

  // Instructions Screen
  if (showInstructions) {
    return (
      <div className="max-w-2xl mx-auto p-4 sm:p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-2">{test.title}</h1>
            <p className="text-gray-500">Please read the instructions carefully before starting</p>
          </div>

          <Card className="py-0">
            <CardContent className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <Clock className="size-4 text-amber-600" />
                  Duration: {test.totalDuration} min
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <ClipboardList className="size-4 text-amber-600" />
                  Questions: {test.numberOfQuestions}
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  Total Marks: {test.totalMarks}
                </div>
                {test.negativeMarks > 0 && (
                  <div className="flex items-center gap-2 text-red-500">
                    Negative Marks: -{test.negativeMarks}
                  </div>
                )}
              </div>
              {attemptId && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-50 text-amber-700 text-sm">
                  <AlertTriangle className="size-4 shrink-0" />
                  <span>You have an in-progress attempt. Click Start to resume.</span>
                </div>
              )}
              {test.instructions && (
                <div className="text-sm text-gray-600 whitespace-pre-wrap border-t pt-4">
                  {test.instructions}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex gap-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => setStudentPage('my-tests')}
            >
              Go Back
            </Button>
            <Button
              className="flex-1 bg-amber-600 hover:bg-amber-700 text-white text-lg py-6"
              onClick={handleStartTest}
            >
              {attemptId ? 'Resume Test' : 'Start Test'}
            </Button>
          </div>
        </motion.div>
      </div>
    )
  }

  const questions = test.questions
  const question = questions[currentQ]
  const isWarning = timeLeft <= 300 && timeLeft > 60
  const isDanger = timeLeft <= 60

  return (
    <div className="fixed inset-0 z-50 bg-gray-50 flex flex-col">
      {/* Top Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <h2 className="text-sm font-semibold text-gray-900 truncate">{test.title}</h2>
        </div>
        <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-bold ${
          isDanger ? 'bg-red-50 text-red-600 animate-pulse' :
          isWarning ? 'bg-amber-50 text-amber-600' :
          'bg-gray-100 text-gray-700'
        }`}>
          <Clock className="size-4" />
          {formatTime(timeLeft)}
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {Object.keys(answers).length}/{questions.length} answered
          </Badge>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => handleSubmit(false)}
            disabled={submitting}
          >
            {submitting ? <Loader2 className="size-4 animate-spin" /> : 'Submit'}
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Question Navigation Sidebar - desktop */}
        {sidebarOpen && (
          <div className="hidden md:block w-64 border-r border-gray-200 bg-white overflow-y-auto">
            <div className="p-3">
              <p className="text-xs font-semibold text-gray-400 uppercase mb-2">Questions</p>
              <div className="grid grid-cols-5 gap-1.5">
                {questions.map((q, idx) => {
                  const isAnswered = !!answers[q.id]
                  const isReview = markedForReview.has(q.id)
                  const isCurrent = idx === currentQ
                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentQ(idx)}
                      className={`w-full aspect-square rounded-lg text-xs font-medium flex items-center justify-center transition-all ${
                        isCurrent ? 'ring-2 ring-amber-500' :
                        isReview ? 'bg-violet-100 text-violet-700' :
                        isAnswered ? 'bg-emerald-100 text-emerald-700' :
                        'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  )
                })}
              </div>
              <div className="mt-4 space-y-1.5 text-xs text-gray-500">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-emerald-100 border border-emerald-300" /> Answered
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-violet-100 border border-violet-300" /> Marked for Review
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-gray-100 border border-gray-300" /> Not Answered
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main Question Area */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-6">
            {/* Question Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-amber-600">Question {currentQ + 1}</span>
                <span className="text-sm text-gray-400">of {questions.length}</span>
                {question.section && (
                  <Badge variant="secondary" className="text-xs">{question.section}</Badge>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">
                  +{question.positiveMarks} {question.negativeMarks > 0 ? `/ -${question.negativeMarks}` : ''}
                </span>
                <Button
                  variant={markedForReview.has(question.id) ? 'default' : 'outline'}
                  size="sm"
                  className={markedForReview.has(question.id) ? 'bg-violet-600 hover:bg-violet-700 text-white' : ''}
                  onClick={() => toggleReview(question.id)}
                >
                  <BookmarkCheck className="size-3.5 mr-1" />
                  {markedForReview.has(question.id) ? 'Marked' : 'Mark'}
                </Button>
              </div>
            </div>

            {/* Question */}
            <Card className="py-0">
              <CardContent className="p-5 sm:p-6">
                {question.heading && (
                  <p className="text-sm font-medium text-amber-700 mb-2">{question.heading}</p>
                )}
                {question.directive && (
                  <p className="text-xs text-gray-500 mb-3">{question.directive}</p>
                )}
                <p className="text-base text-gray-900 leading-relaxed whitespace-pre-wrap">{question.title}</p>

                {/* Options */}
                <div className="mt-5 space-y-3">
                  {question.type === 'mcq' || question.type === 'assertion_reason' || question.type === 'true_false' ? (
                    <RadioGroup
                      value={answers[question.id] || ''}
                      onValueChange={(val) => selectAnswer(question.id, val)}
                    >
                      {['1', '2', '3', '4', '5'].map((num) => {
                        const text = (question as any)[`option${num}`]
                        if (!text) return null
                        return (
                          <div key={num} className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 hover:border-amber-200 hover:bg-amber-50/30 transition-colors cursor-pointer">
                            <RadioGroupItem value={num} id={`q${question.id}-${num}`} />
                            <Label htmlFor={`q${question.id}-${num}`} className="flex-1 cursor-pointer text-sm text-gray-800">
                              {text}
                            </Label>
                          </div>
                        )
                      })}
                    </RadioGroup>
                  ) : question.type === 'multiple_correct' ? (
                    <div className="space-y-3">
                      {['1', '2', '3', '4', '5'].map((num) => {
                        const text = (question as any)[`option${num}`]
                        if (!text) return null
                        const selected = (answers[question.id] || '').split(',').includes(num)
                        return (
                          <div
                            key={num}
                            className={`flex items-center gap-3 p-3 rounded-xl border transition-colors cursor-pointer ${
                              selected ? 'border-amber-300 bg-amber-50/50' : 'border-gray-100 hover:border-amber-200'
                            }`}
                            onClick={() => toggleMultipleAnswer(question.id, num)}
                          >
                            <Checkbox checked={selected} />
                            <span className="text-sm text-gray-800">{text}</span>
                          </div>
                        )
                      })}
                    </div>
                  ) : question.type === 'numerical' ? (
                    <div className="mt-3">
                      <Input
                        type="number"
                        placeholder="Enter your answer"
                        value={answers[question.id] || ''}
                        onChange={(e) => selectAnswer(question.id, e.target.value)}
                        className="max-w-xs"
                      />
                    </div>
                  ) : (
                    <RadioGroup
                      value={answers[question.id] || ''}
                      onValueChange={(val) => selectAnswer(question.id, val)}
                    >
                      {['1', '2', '3', '4', '5'].map((num) => {
                        const text = (question as any)[`option${num}`]
                        if (!text) return null
                        return (
                          <div key={num} className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 hover:border-amber-200 transition-colors cursor-pointer">
                            <RadioGroupItem value={num} id={`q${question.id}-${num}`} />
                            <Label htmlFor={`q${question.id}-${num}`} className="flex-1 cursor-pointer text-sm text-gray-800">
                              {text}
                            </Label>
                          </div>
                        )
                      })}
                    </RadioGroup>
                  )}
                </div>

                {/* Clear Answer */}
                {answers[question.id] && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-3 text-gray-500"
                    onClick={() => setAnswers((prev) => {
                      const next = { ...prev }
                      delete next[question.id]
                      return next
                    })}
                  >
                    Clear Answer
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Navigation */}
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={() => setCurrentQ(Math.max(0, currentQ - 1))}
                disabled={currentQ === 0}
              >
                <ChevronLeft className="size-4 mr-1" />
                Previous
              </Button>
              <span className="text-sm text-gray-400">
                {currentQ + 1} / {questions.length}
              </span>
              <Button
                variant="outline"
                onClick={() => setCurrentQ(Math.min(questions.length - 1, currentQ + 1))}
                disabled={currentQ === questions.length - 1}
              >
                Next
                <ChevronRight className="size-4 ml-1" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Question Nav */}
      <div className="md:hidden border-t border-gray-200 bg-white p-3">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {questions.map((q, idx) => {
            const isAnswered = !!answers[q.id]
            const isCurrent = idx === currentQ
            return (
              <button
                key={q.id}
                onClick={() => setCurrentQ(idx)}
                className={`w-8 h-8 rounded-lg text-xs font-medium flex items-center justify-center shrink-0 ${
                  isCurrent ? 'bg-amber-600 text-white' :
                  isAnswered ? 'bg-emerald-100 text-emerald-700' :
                  'bg-gray-100 text-gray-600'
                }`}
              >
                {idx + 1}
              </button>
            )
          })}
        </div>
      </div>

      {/* Submit Confirmation Dialog */}
      <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Submit Test?</DialogTitle>
            <DialogDescription>
              Are you sure you want to submit the test? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Questions answered:</span>
              <span className="font-medium">{Object.keys(answers).length} / {questions.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Unanswered:</span>
              <span className="font-medium">{questions.length - Object.keys(answers).length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Marked for review:</span>
              <span className="font-medium">{markedForReview.size}</span>
            </div>
            {questions.length - Object.keys(answers).length > 0 && (
              <div className="flex items-center gap-2 p-3 bg-amber-50 rounded-lg text-amber-700">
                <AlertTriangle className="size-4 shrink-0" />
                <span>You have {questions.length - Object.keys(answers).length} unanswered question(s).</span>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirm(false)}>Cancel</Button>
            <Button
              className="bg-amber-600 hover:bg-amber-700 text-white"
              onClick={() => handleSubmit(true)}
              disabled={submitting}
            >
              {submitting ? <Loader2 className="size-4 animate-spin mr-1" /> : null}
              Submit Test
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
