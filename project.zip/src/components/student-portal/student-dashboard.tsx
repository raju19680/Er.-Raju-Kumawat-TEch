'use client'

import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  ClipboardList,
  BookOpen,
  Trophy,
  Clock,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Loader2,
  RotateCcw,
} from 'lucide-react'
import { useAppStore } from '@/lib/store'
import { apiFetchJSON } from '@/lib/api-client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'

interface DashboardStats {
  availableTests: number
  completedTests: number
  purchasedCourses: number
  avgScore: number
}

interface RecentAttempt {
  id: string
  testId: string
  score: number
  totalMarks: number
  status: string
  startedAt: string
  completedAt: string | null
  test: {
    id: string
    title: string
    testSeries: { id: string; title: string } | null
  }
}

export default function StudentDashboard() {
  const { userName, setStudentPage, setSelectedTestSeriesId, setSelectedAttemptId } = useAppStore()
  const [stats, setStats] = useState<DashboardStats>({ availableTests: 0, completedTests: 0, purchasedCourses: 0, avgScore: 0 })
  const [recentAttempts, setRecentAttempts] = useState<RecentAttempt[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const [testSeriesRes, attemptsRes, coursesRes] = await Promise.all([
        apiFetchJSON<{ success: boolean; testSeries: any[] }>('/api/student/test-series'),
        apiFetchJSON<{ success: boolean; attempts: RecentAttempt[] }>('/api/student/test-attempts'),
        apiFetchJSON<{ success: boolean; courses: any[] }>('/api/student/courses'),
      ])

      if (testSeriesRes.success) {
        const ts = testSeriesRes.testSeries
        let totalTests = 0
        ts.forEach((s: any) => { totalTests += s.testCount })
        setStats(prev => ({ ...prev, availableTests: totalTests }))
      }

      if (attemptsRes.success) {
        const completed = attemptsRes.attempts.filter((a: RecentAttempt) => a.status === 'completed')
        const avgScore = completed.length > 0
          ? Math.round(completed.reduce((sum: number, a: RecentAttempt) => sum + (a.totalMarks > 0 ? (a.score / a.totalMarks) * 100 : 0), 0) / completed.length)
          : 0
        setStats(prev => ({ ...prev, completedTests: completed.length, avgScore }))
        setRecentAttempts(attemptsRes.attempts.slice(0, 5))
      }

      if (coursesRes.success) {
        setStats(prev => ({ ...prev, purchasedCourses: coursesRes.courses.length }))
      }
    } catch (err) {
      console.error('Dashboard load error:', err)
      setError('Failed to load dashboard data. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const accent = '#D97706'
  const firstName = userName ? userName.split(' ')[0] : 'Student'

  const statCards = [
    { label: 'Available Tests', value: stats.availableTests, icon: ClipboardList, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'Completed Tests', value: stats.completedTests, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'My Courses', value: stats.purchasedCourses, icon: BookOpen, color: 'text-violet-600', bg: 'bg-violet-50' },
    { label: 'Avg Score', value: `${stats.avgScore}%`, icon: Trophy, color: 'text-rose-600', bg: 'bg-rose-50' },
  ]

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-32 w-full rounded-2xl" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="py-0">
              <CardContent className="p-4 sm:p-5">
                <div className="flex items-center gap-3">
                  <Skeleton className="size-10 sm:size-12 rounded-xl" />
                  <div className="space-y-2">
                    <Skeleton className="h-3 w-20" />
                    <Skeleton className="h-6 w-10" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <Card className="py-0">
          <CardHeader className="pb-3">
            <Skeleton className="h-5 w-32" />
          </CardHeader>
          <CardContent className="flex gap-3">
            <Skeleton className="h-9 w-28 rounded-md" />
            <Skeleton className="h-9 w-28 rounded-md" />
            <Skeleton className="h-9 w-28 rounded-md" />
          </CardContent>
        </Card>
        <Card className="py-0">
          <CardHeader className="pb-3">
            <Skeleton className="h-5 w-40" />
          </CardHeader>
          <CardContent className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full rounded-xl" />
            ))}
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="flex items-center justify-center w-16 h-16 rounded-full bg-red-50 mb-4">
            <AlertCircle className="size-8 text-red-500" />
          </div>
          <h2 className="text-lg font-semibold text-gray-900 mb-1">Failed to Load Dashboard</h2>
          <p className="text-gray-500 text-sm mb-4">{error}</p>
          <Button variant="outline" className="gap-2" onClick={load}>
            <RotateCcw className="size-4" /> Try Again
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-600 via-orange-500 to-yellow-400 p-6 sm:p-8"
      >
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-white/10" />
        <div className="absolute -bottom-16 -left-16 w-56 h-56 rounded-full bg-white/10" />
        <div className="relative z-10">
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Welcome back, {firstName}! 👋
          </h1>
          <p className="text-white/90 text-sm sm:text-base">
            Ready to continue your learning journey? Check your progress and take tests.
          </p>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
          >
            <Card className="border-0 shadow-sm hover:shadow-md transition-shadow py-0">
              <CardContent className="p-4 sm:p-5">
                <div className="flex items-center gap-3">
                  <div className={`flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-xl ${stat.bg}`}>
                    <stat.icon className={`size-5 sm:size-6 ${stat.color}`} />
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm text-gray-500 font-medium">{stat.label}</p>
                    <p className="text-xl sm:text-2xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="border-0 shadow-sm py-0">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold text-gray-900">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Button
              onClick={() => setStudentPage('my-tests')}
              className="gap-2 bg-amber-600 hover:bg-amber-700 text-white"
            >
              <ClipboardList className="size-4" />
              Browse Tests
            </Button>
            <Button
              onClick={() => setStudentPage('my-courses')}
              variant="outline"
              className="gap-2 border-amber-200 text-amber-700 hover:bg-amber-50"
            >
              <BookOpen className="size-4" />
              My Courses
            </Button>
            <Button
              onClick={() => setStudentPage('results')}
              variant="outline"
              className="gap-2"
            >
              <Trophy className="size-4" />
              View Results
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      {/* Recent Test Attempts */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="border-0 shadow-sm py-0">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-base font-semibold text-gray-900">Recent Test Attempts</CardTitle>
            {recentAttempts.length > 0 && (
              <Button variant="ghost" size="sm" className="text-amber-600" onClick={() => setStudentPage('results')}>
                View All <ArrowRight className="size-3.5 ml-1" />
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {recentAttempts.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <ClipboardList className="size-10 mx-auto mb-3 opacity-40" />
                <p className="text-sm">No test attempts yet. Start taking tests!</p>
                <Button
                  size="sm"
                  className="mt-3 bg-amber-600 hover:bg-amber-700 text-white"
                  onClick={() => setStudentPage('my-tests')}
                >
                  Browse Tests
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {recentAttempts.map((attempt) => {
                  const pct = attempt.totalMarks > 0 ? Math.round((attempt.score / attempt.totalMarks) * 100) : 0
                  const isCompleted = attempt.status === 'completed'
                  return (
                    <div
                      key={attempt.id}
                      className="flex items-center gap-4 p-3 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer"
                      onClick={() => {
                        if (isCompleted) {
                          setSelectedAttemptId(attempt.id)
                          setStudentPage('test-result')
                        }
                      }}
                    >
                      <div className={`flex items-center justify-center w-10 h-10 rounded-lg ${isCompleted ? 'bg-emerald-50' : 'bg-amber-50'}`}>
                        {isCompleted ? (
                          <CheckCircle2 className="size-5 text-emerald-600" />
                        ) : (
                          <Clock className="size-5 text-amber-600" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">{attempt.test.title}</p>
                        <p className="text-xs text-gray-500">
                          {attempt.test.testSeries?.title || 'Unknown Series'} •{' '}
                          {isCompleted ? `${attempt.score}/${attempt.totalMarks} marks` : 'In Progress'}
                        </p>
                      </div>
                      {isCompleted && (
                        <div className="flex items-center gap-2">
                          <Progress value={pct} className="w-16 h-2" />
                          <span className={`text-sm font-semibold ${pct >= 60 ? 'text-emerald-600' : pct >= 40 ? 'text-amber-600' : 'text-red-500'}`}>
                            {pct}%
                          </span>
                        </div>
                      )}
                      {!isCompleted && (
                        <Badge variant="secondary" className="bg-amber-50 text-amber-700 text-xs">In Progress</Badge>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
