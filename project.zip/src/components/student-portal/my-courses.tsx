'use client'

import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  BookOpen,
  Clock,
  Loader2,
  ExternalLink,
  GraduationCap,
  AlertCircle,
  RotateCcw,
} from 'lucide-react'
import { useAppStore } from '@/lib/store'
import { apiFetchJSON } from '@/lib/api-client'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'

interface PurchasedCourse {
  id: string
  purchasedAt: string
  expiresAt: string | null
  course: {
    id: string
    title: string
    description: string | null
    thumbnail: string | null
    category: string | null
    status: string
  }
}

function CourseSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
      {Array.from({ length: 3 }).map((_, i) => (
        <Card key={i} className="rounded-xl overflow-hidden py-0">
          <Skeleton className="h-40 w-full" />
          <CardContent className="p-4 space-y-3">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-1/2" />
            <Skeleton className="h-9 w-full rounded-lg" />
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

export default function MyCourses() {
  const { setStudentPage, setSelectedCourseId } = useAppStore()
  const [courses, setCourses] = useState<PurchasedCourse[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await apiFetchJSON<{ success: boolean; courses: PurchasedCourse[] }>('/api/student/courses')
      if (res.success) {
        setCourses(res.courses)
      }
    } catch (err) {
      console.error('Courses load error:', err)
      setError('Failed to load courses. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleViewCourse = (courseId: string) => {
    setSelectedCourseId(courseId)
    setStudentPage('course-detail')
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Courses</h1>
          <p className="text-gray-500 text-sm mt-1">Access your purchased courses and study materials</p>
        </div>
        <CourseSkeleton />
      </div>
    )
  }

  if (error) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Courses</h1>
          <p className="text-gray-500 text-sm mt-1">Access your purchased courses and study materials</p>
        </div>
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="flex items-center justify-center w-16 h-16 rounded-full bg-red-50 mb-4">
            <AlertCircle className="size-8 text-red-500" />
          </div>
          <h2 className="text-lg font-semibold text-gray-900 mb-1">Failed to Load</h2>
          <p className="text-gray-500 text-sm mb-4">{error}</p>
          <Button variant="outline" className="gap-2" onClick={load}>
            <RotateCcw className="size-4" /> Try Again
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">My Courses</h1>
        <p className="text-gray-500 text-sm mt-1">Access your purchased courses and study materials</p>
      </div>

      {courses.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <BookOpen className="size-12 mx-auto mb-3 opacity-40" />
          <p className="text-base font-medium">No courses purchased yet</p>
          <p className="text-sm mt-1">Browse available courses and start learning!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {courses.map((item, idx) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.08 }}
            >
              <Card className="group cursor-pointer border border-gray-100 rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg hover:border-gray-200 py-0">
                {/* Thumbnail */}
                <div className="relative h-40 flex items-center justify-center bg-amber-50">
                  <BookOpen className="size-12 text-amber-600/40" />
                  {item.course.category && (
                    <Badge className="absolute top-3 left-3 text-xs font-semibold bg-amber-600 text-white">
                      {item.course.category}
                    </Badge>
                  )}
                </div>

                <CardContent className="p-4 flex flex-col gap-3">
                  <h3 className="font-semibold text-gray-900 text-sm sm:text-base leading-snug line-clamp-2">
                    {item.course.title}
                  </h3>
                  {item.course.description && (
                    <p className="text-gray-500 text-xs line-clamp-2">{item.course.description}</p>
                  )}
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Clock className="size-3.5" />
                    Purchased {new Date(item.purchasedAt).toLocaleDateString()}
                  </div>
                  <Button
                    className="w-full font-semibold rounded-lg bg-amber-600 hover:bg-amber-700 text-white"
                    onClick={() => handleViewCourse(item.course.id)}
                  >
                    <GraduationCap className="size-4 mr-1" />
                    Continue Learning
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
