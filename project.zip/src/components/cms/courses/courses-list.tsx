'use client'

import React, { useState, useEffect, useCallback } from 'react'
import {
  Card,
  CardContent,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from '@/components/ui/sheet'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import {
  Search,
  Plus,
  BookOpen,
  MoreHorizontal,
  Pencil,
  Trash2,
  Eye,
  EyeOff,
  IndianRupee,
  Upload,
  Loader2,
  ChevronLeft,
  ChevronRight,
  AlertCircle,
  RefreshCw,
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { apiFetch } from '@/lib/api-client'
import { useAppStore } from '@/lib/store'
import { toast } from 'sonner'

// ─── Types ────────────────────────────────────────────────────────────────

interface Course {
  id: string
  title: string
  description: string
  category: string
  price: number
  mrp: number
  status: 'Published' | 'Draft' | 'Archived'
  thumbnail: string
  content?: string
  organizationId: string
  enrolledCount?: number
  createdAt?: string
  updatedAt?: string
}

interface Category {
  id: string
  name: string
  [key: string]: unknown
}

const STATUS_COLORS: Record<string, string> = {
  Published: 'bg-emerald-50 text-emerald-700 hover:bg-emerald-50',
  Draft: 'bg-amber-50 text-amber-700 hover:bg-amber-50',
  Archived: 'bg-gray-100 text-gray-500 hover:bg-gray-100',
}

const CATEGORY_COLORS: Record<string, string> = {
  JEE: 'bg-rose-50 text-rose-700',
  NEET: 'bg-rose-50 text-rose-700',
  UPSC: 'bg-purple-50 text-purple-700',
  GATE: 'bg-orange-50 text-orange-700',
  CAT: 'bg-teal-50 text-teal-700',
  CUET: 'bg-cyan-50 text-cyan-700',
  General: 'bg-gray-50 text-gray-700',
}

const DEFAULT_CATEGORY_COLOR = 'bg-gray-50 text-gray-700'

// ─── Component ────────────────────────────────────────────────────────────

export default function CoursesList() {
  const { orgCode } = useAppStore()

  // Data state
  const [courses, setCourses] = useState<Course[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [total, setTotal] = useState(0)
  const [totalPages, setTotalPages] = useState(1)

  // UI state
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [searchDebounced, setSearchDebounced] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [categoryFilter, setCategoryFilter] = useState<string>('all')
  const [page, setPage] = useState(1)
  const limit = 20

  // Drawer state
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [editCourse, setEditCourse] = useState<Course | null>(null)
  const [saving, setSaving] = useState(false)

  // Delete dialog state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [courseToDelete, setCourseToDelete] = useState<Course | null>(null)
  const [deleting, setDeleting] = useState(false)

  // Form state
  const [formTitle, setFormTitle] = useState('')
  const [formDescription, setFormDescription] = useState('')
  const [formThumbnail, setFormThumbnail] = useState('')
  const [formCategory, setFormCategory] = useState('')
  const [formPrice, setFormPrice] = useState('')
  const [formMrp, setFormMrp] = useState('')
  const [formStatus, setFormStatus] = useState<'Published' | 'Draft' | 'Archived'>('Draft')

  // ─── Debounced search ─────────────────────────────────────────────────

  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchDebounced(search)
      setPage(1)
    }, 400)
    return () => clearTimeout(timer)
  }, [search])

  // ─── Fetch courses ────────────────────────────────────────────────────

  const fetchCourses = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: limit.toString(),
        organizationId: orgCode || '',
      })
      if (searchDebounced) params.set('search', searchDebounced)
      if (statusFilter !== 'all') params.set('status', statusFilter)
      if (categoryFilter !== 'all') params.set('category', categoryFilter)

      const res = await apiFetch(`/api/courses?${params}`)
      if (!res.ok) throw new Error('Failed to fetch courses')
      const data = await res.json()
      setCourses(data.items || [])
      setTotal(data.total || 0)
      setTotalPages(Math.ceil((data.total || 0) / limit) || 1)
    } catch (err) {
      console.error('Failed to fetch courses:', err)
      setError('Failed to load courses. Please try again.')
    } finally {
      setLoading(false)
    }
  }, [page, searchDebounced, statusFilter, categoryFilter, orgCode])

  // ─── Fetch categories ─────────────────────────────────────────────────

  const fetchCategories = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        organizationId: orgCode || '',
      })
      const res = await apiFetch(`/api/categories?${params}`)
      if (!res.ok) throw new Error('Failed to fetch categories')
      const data = await res.json()
      setCategories(data.items || [])
    } catch (err) {
      console.error('Failed to fetch categories:', err)
    }
  }, [orgCode])

  // ─── Effects ──────────────────────────────────────────────────────────

  useEffect(() => {
    fetchCourses()
  }, [fetchCourses])

  useEffect(() => {
    fetchCategories()
  }, [fetchCategories])

  // Reset page when filters change
  useEffect(() => {
    setPage(1)
  }, [statusFilter, categoryFilter])

  // ─── Form helpers ─────────────────────────────────────────────────────

  const resetForm = () => {
    setFormTitle('')
    setFormDescription('')
    setFormThumbnail('')
    setFormCategory('')
    setFormPrice('')
    setFormMrp('')
    setFormStatus('Draft')
  }

  const openAddDrawer = () => {
    setEditCourse(null)
    resetForm()
    setDrawerOpen(true)
  }

  const openEditDrawer = (course: Course) => {
    setEditCourse(course)
    setFormTitle(course.title)
    setFormDescription(course.description)
    setFormThumbnail(course.thumbnail || '')
    setFormCategory(course.category)
    setFormPrice(String(course.price))
    setFormMrp(String(course.mrp))
    setFormStatus(course.status)
    setDrawerOpen(true)
  }

  // ─── Save (Create / Update) ───────────────────────────────────────────

  const handleSave = async () => {
    if (!formTitle.trim()) {
      toast.error('Title is required')
      return
    }

    setSaving(true)
    try {
      const body: Record<string, unknown> = {
        title: formTitle.trim(),
        description: formDescription.trim(),
        thumbnail: formThumbnail.trim(),
        price: Number(formPrice) || 0,
        mrp: Number(formMrp) || 0,
        category: formCategory,
        status: formStatus,
        organizationId: orgCode,
      }

      if (editCourse) {
        // Update
        const res = await apiFetch(`/api/courses/${editCourse.id}`, {
          method: 'PUT',
          body: JSON.stringify(body),
        })
        if (!res.ok) throw new Error('Failed to update course')
        toast.success('Course updated successfully')
      } else {
        // Create
        const res = await apiFetch('/api/courses', {
          method: 'POST',
          body: JSON.stringify(body),
        })
        if (!res.ok) throw new Error('Failed to create course')
        toast.success('Course created successfully')
      }

      setDrawerOpen(false)
      fetchCourses()
    } catch (err) {
      console.error('Save failed:', err)
      toast.error(editCourse ? 'Failed to update course' : 'Failed to create course')
    } finally {
      setSaving(false)
    }
  }

  // ─── Delete ───────────────────────────────────────────────────────────

  const handleDelete = async () => {
    if (!courseToDelete) return
    setDeleting(true)
    try {
      const res = await apiFetch(`/api/courses/${courseToDelete.id}`, {
        method: 'DELETE',
      })
      if (!res.ok) throw new Error('Failed to delete course')
      toast.success('Course deleted successfully')
      setDeleteDialogOpen(false)
      setCourseToDelete(null)
      fetchCourses()
    } catch (err) {
      console.error('Delete failed:', err)
      toast.error('Failed to delete course')
    } finally {
      setDeleting(false)
    }
  }

  // ─── Toggle publish/draft ─────────────────────────────────────────────

  const handleTogglePublish = async (course: Course) => {
    const newStatus: 'Published' | 'Draft' = course.status === 'Published' ? 'Draft' : 'Published'
    try {
      const res = await apiFetch(`/api/courses/${course.id}`, {
        method: 'PUT',
        body: JSON.stringify({ status: newStatus }),
      })
      if (!res.ok) throw new Error('Failed to update status')
      toast.success(`Course ${newStatus === 'Published' ? 'published' : 'moved to draft'}`)
      fetchCourses()
    } catch (err) {
      console.error('Toggle publish failed:', err)
      toast.error('Failed to update course status')
    }
  }

  // ─── Discount calculator ──────────────────────────────────────────────

  const discount = (price: number, mrp: number) => {
    if (mrp === 0) return 0
    return Math.round(((mrp - price) / mrp) * 100)
  }

  // ─── Loading Skeletons ────────────────────────────────────────────────

  const renderSkeletons = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {Array.from({ length: 6 }).map((_, i) => (
        <Card key={i} className="rounded-xl overflow-hidden">
          <Skeleton className="h-36 w-full rounded-none" />
          <CardContent className="p-4 space-y-3">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-5 w-16" />
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-2/3" />
            <div className="flex items-center justify-between pt-1">
              <Skeleton className="h-5 w-20" />
              <Skeleton className="h-3 w-16" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )

  // ─── Render ───────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Courses</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your course catalog and content
          </p>
        </div>
        <Button onClick={openAddDrawer} className="w-full sm:w-auto bg-black hover:bg-gray-800 text-white">
          <Plus className="size-4 mr-2" />
          Add Course
        </Button>
      </div>

      {/* Filters Row */}
      <Card className="rounded-xl">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder="Search courses..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 rounded-lg"
              />
            </div>
            <Select value={statusFilter} onValueChange={(val) => { setStatusFilter(val); setPage(1) }}>
              <SelectTrigger className="w-full sm:w-[160px] rounded-lg">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Published">Published</SelectItem>
                <SelectItem value="Draft">Draft</SelectItem>
                <SelectItem value="Archived">Archived</SelectItem>
              </SelectContent>
            </Select>
            <Select value={categoryFilter} onValueChange={(val) => { setCategoryFilter(val); setPage(1) }}>
              <SelectTrigger className="w-full sm:w-[160px] rounded-lg">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.name}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Stats Bar */}
      {!loading && !error && (
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span>{total} course{total !== 1 ? 's' : ''} total</span>
          {totalPages > 1 && (
            <>
              <span>•</span>
              <span>Page {page} of {totalPages}</span>
            </>
          )}
        </div>
      )}

      {/* Error State */}
      {error && !loading && (
        <Card className="rounded-xl">
          <CardContent className="py-16">
            <div className="flex flex-col items-center justify-center text-center">
              <div className="size-12 rounded-full bg-red-50 flex items-center justify-center mb-4">
                <AlertCircle className="size-5 text-red-500" />
              </div>
              <p className="text-sm font-medium text-gray-900">{error}</p>
              <Button
                variant="outline"
                size="sm"
                className="mt-4"
                onClick={fetchCourses}
              >
                <RefreshCw className="size-4 mr-2" />
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading Skeletons */}
      {loading && renderSkeletons()}

      {/* Course Cards Grid */}
      {!loading && !error && courses.length === 0 ? (
        <Card className="rounded-xl">
          <CardContent className="py-16">
            <div className="flex flex-col items-center justify-center text-center">
              <div className="size-12 rounded-full bg-muted flex items-center justify-center mb-4">
                <BookOpen className="size-5 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-gray-900">No courses found</p>
              <p className="text-xs text-muted-foreground mt-1">
                {search || statusFilter !== 'all' || categoryFilter !== 'all'
                  ? 'Try adjusting your search or filter criteria'
                  : 'Create your first course to get started'}
              </p>
              {!search && statusFilter === 'all' && categoryFilter === 'all' && (
                <Button
                  onClick={openAddDrawer}
                  className="mt-4 bg-black hover:bg-gray-800 text-white"
                  size="sm"
                >
                  <Plus className="size-4 mr-2" />
                  Add Course
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ) : !loading && !error ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses.map((course) => {
            const disc = discount(course.price, course.mrp)
            return (
              <Card key={course.id} className="rounded-xl overflow-hidden hover:shadow-md transition-shadow">
                {/* Thumbnail */}
                <div className="h-36 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center relative">
                  {course.thumbnail ? (
                    <img
                      src={course.thumbnail}
                      alt={course.title}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <BookOpen className="size-10 text-gray-400" />
                  )}
                  <Badge
                    className={`absolute top-3 left-3 ${STATUS_COLORS[course.status] || 'bg-gray-100 text-gray-500'}`}
                  >
                    {course.status}
                  </Badge>
                  {disc > 0 && (
                    <Badge className="absolute top-3 right-3 bg-red-500 text-white hover:bg-red-500">
                      {disc}% OFF
                    </Badge>
                  )}
                </div>
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm text-gray-900 truncate">
                        {course.title}
                      </h3>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0 shrink-0">
                          <MoreHorizontal className="size-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEditDrawer(course)}>
                          <Pencil className="size-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleTogglePublish(course)}>
                          {course.status === 'Published' ? (
                            <>
                              <EyeOff className="size-4 mr-2" />
                              Unpublish
                            </>
                          ) : (
                            <>
                              <Eye className="size-4 mr-2" />
                              Publish
                            </>
                          )}
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-red-600 focus:text-red-600"
                          onClick={() => {
                            setCourseToDelete(course)
                            setDeleteDialogOpen(true)
                          }}
                        >
                          <Trash2 className="size-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {course.category && (
                    <Badge variant="secondary" className={CATEGORY_COLORS[course.category] || DEFAULT_CATEGORY_COLOR}>
                      {course.category}
                    </Badge>
                  )}

                  {course.description && (
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {course.description}
                    </p>
                  )}

                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-baseline gap-2">
                      <span className="text-lg font-bold text-gray-900 flex items-center">
                        <IndianRupee className="size-3.5" />
                        {course.price.toLocaleString('en-IN')}
                      </span>
                      {course.mrp > course.price && (
                        <span className="text-xs text-muted-foreground line-through">
                          ₹{course.mrp.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>
                    {course.enrolledCount != null && course.enrolledCount > 0 && (
                      <span className="text-xs text-muted-foreground">
                        {course.enrolledCount} enrolled
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      ) : null}

      {/* Pagination */}
      {!loading && !error && totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <Button
            variant="outline"
            size="sm"
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
          >
            <ChevronLeft className="size-4" />
          </Button>
          <span className="text-sm text-muted-foreground">
            Page {page} of {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
          >
            <ChevronRight className="size-4" />
          </Button>
        </div>
      )}

      {/* Add/Edit Course Drawer */}
      <Sheet open={drawerOpen} onOpenChange={setDrawerOpen}>
        <SheetContent side="right" className="sm:max-w-md md:max-w-lg">
          <SheetHeader>
            <SheetTitle>{editCourse ? 'Edit Course' : 'Add Course'}</SheetTitle>
            <SheetDescription>
              {editCourse
                ? 'Update course details below'
                : 'Fill in the details to create a new course'}
            </SheetDescription>
          </SheetHeader>

          <div className="flex-1 overflow-y-auto px-4 py-6 space-y-5">
            <div className="space-y-2">
              <Label htmlFor="course-title">Course Title</Label>
              <Input
                id="course-title"
                placeholder="Enter course title"
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="course-desc">Description</Label>
              <Textarea
                id="course-desc"
                placeholder="Brief description of the course..."
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                className="min-h-[80px] resize-y"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="course-thumbnail">Thumbnail URL</Label>
              <div className="flex gap-2">
                <Input
                  id="course-thumbnail"
                  placeholder="https://example.com/image.jpg"
                  value={formThumbnail}
                  onChange={(e) => setFormThumbnail(e.target.value)}
                  className="flex-1"
                />
              </div>
              {formThumbnail ? (
                <div className="mt-2 h-28 rounded-lg overflow-hidden border bg-gray-50">
                  <img
                    src={formThumbnail}
                    alt="Thumbnail preview"
                    className="h-full w-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none'
                    }}
                  />
                </div>
              ) : (
                <div className="mt-2 h-28 rounded-lg border-2 border-dashed border-gray-300 hover:border-gray-400 hover:bg-gray-50 transition-colors flex flex-col items-center justify-center gap-2">
                  <Upload className="size-6 text-gray-400" />
                  <span className="text-xs text-gray-500">Enter a thumbnail URL above</span>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="course-category">Category</Label>
                <Select value={formCategory} onValueChange={setFormCategory}>
                  <SelectTrigger id="course-category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.name}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="course-status">Status</Label>
                <Select
                  value={formStatus}
                  onValueChange={(val) =>
                    setFormStatus(val as 'Published' | 'Draft' | 'Archived')
                  }
                >
                  <SelectTrigger id="course-status">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Published">Published</SelectItem>
                    <SelectItem value="Draft">Draft</SelectItem>
                    <SelectItem value="Archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="course-price">Selling Price (₹)</Label>
                <Input
                  id="course-price"
                  type="number"
                  placeholder="0"
                  value={formPrice}
                  onChange={(e) => setFormPrice(e.target.value)}
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="course-mrp">MRP (₹)</Label>
                <Input
                  id="course-mrp"
                  type="number"
                  placeholder="0"
                  value={formMrp}
                  onChange={(e) => setFormMrp(e.target.value)}
                  min="0"
                />
              </div>
            </div>
          </div>

          <SheetFooter className="border-t pt-4">
            <div className="flex gap-3 w-full">
              <Button variant="outline" className="flex-1" onClick={() => setDrawerOpen(false)} disabled={saving}>
                Cancel
              </Button>
              <Button
                className="flex-1 bg-black hover:bg-gray-800 text-white"
                onClick={handleSave}
                disabled={saving}
              >
                {saving ? (
                  <>
                    <Loader2 className="size-4 mr-2 animate-spin" />
                    {editCourse ? 'Saving...' : 'Creating...'}
                  </>
                ) : (
                  editCourse ? 'Save Changes' : 'Create Course'
                )}
              </Button>
            </div>
          </SheetFooter>
        </SheetContent>
      </Sheet>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Course</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete{' '}
              <span className="font-semibold text-foreground">{courseToDelete?.title}</span>? This
              action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} disabled={deleting}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting ? (
                <>
                  <Loader2 className="size-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
