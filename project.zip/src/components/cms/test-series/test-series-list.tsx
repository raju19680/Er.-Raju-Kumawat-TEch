'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetchJSON } from '@/lib/api-client'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination'
import {
  Search,
  Plus,
  Pencil,
  Eye,
  Copy,
  Trash2,
  LayoutGrid,
  List,
  MoreHorizontal,
  Upload,
  Filter,
  X,
  Package,
  ImagePlus,
  AlertCircle,
} from 'lucide-react'
import { toast } from 'sonner'

// ── Types ────────────────────────────────────────────────────────────────────

interface TestSeriesItem {
  id: string
  title: string
  thumbnail: string | null
  isCombo: boolean
  price: number
  mrp: number
  sortOrder: number
  status: 'published' | 'draft'
  category: string
  testCount: number
  [key: string]: unknown
}

interface TestOption {
  id: string
  title: string
}

interface CategoryOption {
  id: string
  name: string
}

interface FormData {
  title: string
  description: string
  category: string
  price: string
  mrp: string
  validityMode: 'days' | 'date' | 'lifetime'
  validityDays: string
  validityDate: string
  isCombo: boolean
  selectedTests: string[]
  includeTestMaker: boolean
  allowPayment: boolean
  seoTitle: string
  seoDescription: string
  richSnippets: boolean
  imagePreview: string | null
  status: 'published' | 'draft'
  sortOrder: string
}

interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  limit: number
}

// ── Category color map ───────────────────────────────────────────────────────

const categoryColors: Record<string, string> = {
  JEE: 'bg-rose-500',
  NEET: 'bg-emerald-500',
  CUET: 'bg-purple-500',
  GATE: 'bg-orange-500',
  UPSC: 'bg-rose-500',
  CAT: 'bg-amber-500',
  Other: 'bg-slate-500',
}

// ── Default form ─────────────────────────────────────────────────────────────

const defaultFormData: FormData = {
  title: '',
  description: '',
  category: '',
  price: '',
  mrp: '',
  validityMode: 'days',
  validityDays: '',
  validityDate: '',
  isCombo: false,
  selectedTests: [],
  includeTestMaker: false,
  allowPayment: true,
  seoTitle: '',
  seoDescription: '',
  richSnippets: false,
  imagePreview: null,
  status: 'draft',
  sortOrder: '',
}

// ── Component ────────────────────────────────────────────────────────────────

export default function TestSeriesList() {
  const { orgCode } = useAppStore()

  // List state
  const [searchQuery, setSearchQuery] = useState('')
  const [categoryFilter, setCategoryFilter] = useState<string>('all')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list')
  const [showFilterDropdown, setShowFilterDropdown] = useState(false)
  const [currentPageNum, setCurrentPageNum] = useState(1)

  // API-driven state
  const [series, setSeries] = useState<TestSeriesItem[]>([])
  const [totalItems, setTotalItems] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Drawer state
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [activeTab, setActiveTab] = useState<string>('basic')
  const [saving, setSaving] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  // Delete dialog
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [seriesToDelete, setSeriesToDelete] = useState<TestSeriesItem | null>(null)
  const [deleting, setDeleting] = useState(false)

  // Form state
  const [formData, setFormData] = useState<FormData>({ ...defaultFormData })

  // Reference data from API
  const [categories, setCategories] = useState<CategoryOption[]>([])
  const [testOptions, setTestOptions] = useState<TestOption[]>([])
  const [loadingTests, setLoadingTests] = useState(false)

  const itemsPerPage = 20

  const updateField = <K extends keyof FormData>(key: K, value: FormData[K]) => {
    setFormData((prev) => ({ ...prev, [key]: value }))
  }

  const resetForm = () => {
    setFormData({ ...defaultFormData })
    setActiveTab('basic')
    setEditingId(null)
  }

  // ── Fetch test series list ───────────────────────────────────────────────

  const fetchSeries = useCallback(async () => {
    if (!orgCode) return
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams({
        search: searchQuery,
        page: String(currentPageNum),
        limit: String(itemsPerPage),
        organizationId: orgCode,
      })
      if (categoryFilter !== 'all') params.set('category', categoryFilter)
      if (statusFilter !== 'all') params.set('status', statusFilter)

      const data = await apiFetchJSON<PaginatedResponse<TestSeriesItem>>(
        `/api/test-series?${params.toString()}`
      )
      setSeries(data.items || [])
      setTotalItems(data.total || 0)
    } catch (err) {
      console.error('Failed to fetch test series:', err)
      setError('Failed to load test series. Please try again.')
    } finally {
      setLoading(false)
    }
  }, [orgCode, searchQuery, currentPageNum, categoryFilter, statusFilter])

  // ── Fetch categories ─────────────────────────────────────────────────────

  const fetchCategories = useCallback(async () => {
    if (!orgCode) return
    try {
      const data = await apiFetchJSON<{ items: CategoryOption[] }>(
        `/api/categories?organizationId=${orgCode}&limit=100`
      )
      setCategories(data.items || [])
    } catch {
      // Silently fail
    }
  }, [orgCode])

  // ── Fetch test options for combo selection ───────────────────────────────

  const fetchTestOptions = useCallback(async () => {
    if (!orgCode) return
    setLoadingTests(true)
    try {
      const data = await apiFetchJSON<PaginatedResponse<TestOption>>(
        `/api/tests?organizationId=${orgCode}&limit=100`
      )
      setTestOptions(data.items || [])
    } catch {
      // Silently fail
    } finally {
      setLoadingTests(false)
    }
  }, [orgCode])

  useEffect(() => {
    fetchSeries()
  }, [fetchSeries])

  useEffect(() => {
    fetchCategories()
  }, [fetchCategories])

  // Load test options when drawer opens with combo enabled
  useEffect(() => {
    if (drawerOpen) {
      fetchTestOptions()
    }
  }, [drawerOpen, fetchTestOptions])

  const totalPages = Math.max(1, Math.ceil(totalItems / itemsPerPage))

  const discount = (price: number, mrp: number) =>
    mrp > price ? Math.round(((mrp - price) / mrp) * 100) : 0

  // ── Delete handler ───────────────────────────────────────────────────────

  const handleDelete = async () => {
    if (!seriesToDelete) return
    setDeleting(true)
    try {
      await apiFetchJSON(`/api/test-series/${seriesToDelete.id}`, { method: 'DELETE' })
      toast.success('Test series deleted successfully')
      setDeleteDialogOpen(false)
      setSeriesToDelete(null)
      fetchSeries()
    } catch {
      toast.error('Failed to delete test series')
    } finally {
      setDeleting(false)
    }
  }

  // ── Open drawer for edit ─────────────────────────────────────────────────

  const openEditDrawer = (item: TestSeriesItem) => {
    setEditingId(item.id)
    setFormData({
      title: item.title || '',
      description: (item.description as string) || '',
      category: item.category || '',
      price: item.price?.toString() || '',
      mrp: item.mrp?.toString() || '',
      validityMode: (item.validityMode as FormData['validityMode']) || 'days',
      validityDays: (item.validityDays as string)?.toString() || '',
      validityDate: (item.validityDate as string) || '',
      isCombo: item.isCombo || false,
      selectedTests: (item.selectedTests as string[]) || [],
      includeTestMaker: (item.includeTestMaker as boolean) || false,
      allowPayment: (item.allowPayment as boolean) ?? true,
      seoTitle: (item.seoTitle as string) || '',
      seoDescription: (item.seoDescription as string) || '',
      richSnippets: (item.richSnippets as boolean) || false,
      imagePreview: item.thumbnail || null,
      status: item.status || 'draft',
      sortOrder: item.sortOrder?.toString() || '',
    })
    setActiveTab('basic')
    setDrawerOpen(true)
  }

  // ── Submit handler ───────────────────────────────────────────────────────

  const handleSubmit = async () => {
    if (!formData.title.trim()) {
      toast.error('Title is required')
      return
    }

    setSaving(true)
    try {
      const body: Record<string, unknown> = {
        title: formData.title,
        description: formData.description,
        category: formData.category,
        price: formData.price ? Number(formData.price) : 0,
        mrp: formData.mrp ? Number(formData.mrp) : 0,
        validityMode: formData.validityMode,
        validityDays: formData.validityDays ? Number(formData.validityDays) : undefined,
        validityDate: formData.validityDate || undefined,
        isCombo: formData.isCombo,
        selectedTests: formData.isCombo ? formData.selectedTests : [],
        includeTestMaker: formData.includeTestMaker,
        allowPayment: formData.allowPayment,
        seoTitle: formData.seoTitle || undefined,
        seoDescription: formData.seoDescription || undefined,
        richSnippets: formData.richSnippets,
        status: formData.status,
        sortOrder: formData.sortOrder ? Number(formData.sortOrder) : undefined,
        thumbnail: formData.imagePreview || undefined,
        organizationId: orgCode,
      }

      if (editingId) {
        await apiFetchJSON(`/api/test-series/${editingId}`, {
          method: 'PUT',
          body: JSON.stringify(body),
        })
        toast.success('Test series updated successfully')
      } else {
        await apiFetchJSON('/api/test-series', {
          method: 'POST',
          body: JSON.stringify(body),
        })
        toast.success('Test series created successfully')
      }

      setDrawerOpen(false)
      resetForm()
      fetchSeries()
    } catch (err) {
      console.error('Failed to save test series:', err)
      toast.error(editingId ? 'Failed to update test series' : 'Failed to create test series')
    } finally {
      setSaving(false)
    }
  }

  // ── Render ───────────────────────────────────────────────────────────────

  return (
    <div className="space-y-5">
      {/* ── Header row ──────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">Test Series</h1>
        <Button
          className="w-full sm:w-fit"
          onClick={() => {
            resetForm()
            setDrawerOpen(true)
          }}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Test Series
        </Button>
      </div>

      {/* ── Search / Filter / View toggle bar ───────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search test series..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value)
              setCurrentPageNum(1)
            }}
            className="pl-9 rounded-lg"
          />
        </div>

        {/* Filter */}
        <div className="relative">
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            onClick={() => setShowFilterDropdown(!showFilterDropdown)}
          >
            <Filter className="h-4 w-4" />
            Filters
            {(categoryFilter !== 'all' || statusFilter !== 'all') && (
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">
                {(categoryFilter !== 'all' ? 1 : 0) + (statusFilter !== 'all' ? 1 : 0)}
              </span>
            )}
          </Button>

          {showFilterDropdown && (
            <div className="absolute right-0 top-full z-50 mt-2 w-72 rounded-xl border bg-white p-4 shadow-lg">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm font-semibold">Filters</span>
                <button
                  onClick={() => setShowFilterDropdown(false)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="space-y-3">
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">
                    Category
                  </label>
                  <Select value={categoryFilter} onValueChange={(v) => { setCategoryFilter(v); setCurrentPageNum(1) }}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.length > 0
                        ? categories.map((c) => (
                            <SelectItem key={c.id} value={c.name}>
                              {c.name}
                            </SelectItem>
                          ))
                        : ['JEE', 'NEET', 'CUET', 'GATE', 'UPSC', 'CAT', 'Other'].map((c) => (
                            <SelectItem key={c} value={c}>
                              {c}
                            </SelectItem>
                          ))
                      }
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">
                    Status
                  </label>
                  <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setCurrentPageNum(1) }}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="published">Published</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full"
                  onClick={() => {
                    setCategoryFilter('all')
                    setStatusFilter('all')
                    setCurrentPageNum(1)
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* View toggle */}
        <div className="flex items-center rounded-lg border bg-muted p-0.5">
          <button
            onClick={() => setViewMode('list')}
            className={`flex items-center justify-center rounded-md p-1.5 transition-colors ${
              viewMode === 'list'
                ? 'bg-background text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <List className="h-4 w-4" />
          </button>
          <button
            onClick={() => setViewMode('grid')}
            className={`flex items-center justify-center rounded-md p-1.5 transition-colors ${
              viewMode === 'grid'
                ? 'bg-background text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <LayoutGrid className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* ── Error state ────────────────────────────────────────────────── */}
      {error && (
        <div className="flex items-center gap-3 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">
          <AlertCircle className="h-4 w-4 flex-shrink-0" />
          <span>{error}</span>
          <Button variant="ghost" size="sm" className="ml-auto" onClick={fetchSeries}>
            Retry
          </Button>
        </div>
      )}

      {/* ── Loading skeletons ────────────────────────────────────────────── */}
      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="overflow-hidden rounded-xl">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Skeleton className="h-14 w-14 rounded-lg" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-6 w-20" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : series.length === 0 ? (
      /* ── Empty state ────────────────────────────────────────────────────── */
        <div className="flex items-center justify-center rounded-xl border bg-white py-16">
          <div className="text-center">
            <Package className="mx-auto h-12 w-12 text-muted-foreground/40" />
            <p className="mt-3 text-sm text-muted-foreground">No test series found.</p>
          </div>
        </div>
      ) : viewMode === 'list' ? (
        /* List view */
        <div className="space-y-3">
          {series.map((item) => (
            <Card key={item.id} className="overflow-hidden rounded-xl">
              <CardContent className="p-0">
                <div className="flex flex-col sm:flex-row items-start gap-3 sm:gap-4 p-4">
                  {/* Thumbnail */}
                  <div
                    className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-lg text-white ${
                      categoryColors[item.category] || 'bg-slate-500'
                    }`}
                  >
                    <span className="text-lg font-bold">{(item.category || '?').charAt(0)}</span>
                  </div>

                  {/* Info */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="truncate text-sm font-semibold">{item.title}</h3>
                      {item.isCombo && (
                        <Badge className="bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100 text-[10px] px-1.5 py-0">
                          COMBO
                        </Badge>
                      )}
                    </div>
                    <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{item.category}</span>
                      <span>&#8226;</span>
                      <span>{item.testCount} tests</span>
                      <span>&#8226;</span>
                      <span>Sort #{item.sortOrder}</span>
                    </div>
                    {/* Mobile: Price & Status row */}
                    <div className="flex items-center gap-3 mt-2 sm:hidden">
                      <div className="text-sm font-bold">
                        ₹{item.price.toLocaleString()}
                      </div>
                      {item.mrp > item.price && (
                        <div className="text-xs text-muted-foreground line-through">
                          ₹{item.mrp.toLocaleString()}
                        </div>
                      )}
                      {item.mrp > item.price && (
                        <span className="text-[10px] font-medium text-emerald-600">
                          {discount(item.price, item.mrp)}% off
                        </span>
                      )}
                      <Badge
                        className={
                          item.status === 'published'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                            : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                        }
                      >
                        {item.status === 'published' ? 'Published' : 'Draft'}
                      </Badge>
                    </div>
                  </div>

                  {/* Desktop: Price */}
                  <div className="hidden sm:block flex-shrink-0 text-right">
                    <div className="text-sm font-bold">
                      ₹{item.price.toLocaleString()}
                    </div>
                    {item.mrp > item.price && (
                      <div className="text-xs text-muted-foreground line-through">
                        ₹{item.mrp.toLocaleString()}
                      </div>
                    )}
                    {item.mrp > item.price && (
                      <span className="text-[10px] font-medium text-emerald-600">
                        {discount(item.price, item.mrp)}% off
                      </span>
                    )}
                  </div>

                  {/* Desktop: Status */}
                  <div className="hidden sm:block flex-shrink-0">
                    <Badge
                      className={
                        item.status === 'published'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }
                    >
                      {item.status === 'published' ? 'Published' : 'Draft'}
                    </Badge>
                  </div>

                  {/* Actions */}
                  <div className="flex-shrink-0 self-start sm:self-center">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Open menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem onClick={() => openEditDrawer(item)}>
                          <Pencil className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Eye className="mr-2 h-4 w-4" />
                          View Tests
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Copy className="mr-2 h-4 w-4" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          variant="destructive"
                          onClick={() => {
                            setSeriesToDelete(item)
                            setDeleteDialogOpen(true)
                          }}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        /* Grid view */
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {series.map((item) => (
            <Card key={item.id} className="overflow-hidden rounded-xl">
              {/* Thumbnail area */}
              <div
                className={`flex h-32 items-center justify-center ${
                  categoryColors[item.category] || 'bg-slate-500'
                }`}
              >
                <span className="text-4xl font-bold text-white">{(item.category || '?').charAt(0)}</span>
              </div>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="truncate text-sm font-semibold">{item.title}</h3>
                      {item.isCombo && (
                        <Badge className="bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100 text-[10px] px-1.5 py-0 flex-shrink-0">
                          COMBO
                        </Badge>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {item.category} &bull; {item.testCount} tests &bull; Sort #{item.sortOrder}
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div>
                    <span className="text-sm font-bold">₹{item.price.toLocaleString()}</span>
                    {item.mrp > item.price && (
                      <span className="ml-1.5 text-xs text-muted-foreground line-through">
                        ₹{item.mrp.toLocaleString()}
                      </span>
                    )}
                    {item.mrp > item.price && (
                      <span className="ml-1.5 text-[10px] font-medium text-emerald-600">
                        {discount(item.price, item.mrp)}% off
                      </span>
                    )}
                  </div>
                  <Badge
                    className={
                      item.status === 'published'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }
                  >
                    {item.status === 'published' ? 'Published' : 'Draft'}
                  </Badge>
                </div>

                <div className="mt-3 flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 flex-1 text-xs"
                    onClick={() => openEditDrawer(item)}
                  >
                    <Pencil className="mr-1 h-3 w-3" />
                    Edit
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 flex-1 text-xs">
                    <Eye className="mr-1 h-3 w-3" />
                    Tests
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="icon" className="h-7 w-7">
                        <MoreHorizontal className="h-3 w-3" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-40">
                      <DropdownMenuItem>
                        <Copy className="mr-2 h-4 w-4" />
                        Duplicate
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        variant="destructive"
                        onClick={() => {
                          setSeriesToDelete(item)
                          setDeleteDialogOpen(true)
                        }}
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* ── Pagination ─────────────────────────────────────────────────── */}
      {totalPages > 1 && (
        <div className="flex justify-center">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  onClick={() => setCurrentPageNum(Math.max(1, currentPageNum - 1))}
                  className={currentPageNum === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                />
              </PaginationItem>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <PaginationItem key={page}>
                  <PaginationLink
                    isActive={page === currentPageNum}
                    onClick={() => setCurrentPageNum(page)}
                    className="cursor-pointer"
                  >
                    {page}
                  </PaginationLink>
                </PaginationItem>
              ))}
              <PaginationItem>
                <PaginationNext
                  onClick={() => setCurrentPageNum(Math.min(totalPages, currentPageNum + 1))}
                  className={currentPageNum === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}

      {/* ── Add / Edit Test Series Drawer ─────────────────────────────────── */}
      <Sheet open={drawerOpen} onOpenChange={(open) => {
        if (!open) resetForm()
        setDrawerOpen(open)
      }}>
        <SheetContent
          side="right"
          className="sm:max-w-lg md:max-w-xl lg:max-w-2xl w-full overflow-y-auto p-0"
        >
          <SheetHeader className="border-b px-6 py-4">
            <SheetTitle className="text-lg">
              {editingId ? 'Edit Test Series' : 'Add Test Series'}
            </SheetTitle>
            <SheetDescription>
              {editingId
                ? 'Update the test series details below.'
                : 'Create a new test series for your students.'}
            </SheetDescription>
          </SheetHeader>

          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            className="flex flex-1 flex-col"
          >
            <div className="border-b px-6">
              <TabsList className="h-10 w-full justify-start rounded-none border-0 bg-transparent p-0">
                <TabsTrigger
                  value="basic"
                  className="relative rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none"
                >
                  Basic
                </TabsTrigger>
                <TabsTrigger
                  value="advanced"
                  className="relative rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none"
                >
                  Advanced
                </TabsTrigger>
              </TabsList>
            </div>

            {/* ── Basic Tab ──────────────────────────────────────────────── */}
            <TabsContent value="basic" className="flex-1 overflow-y-auto px-6 py-5">
              <div className="space-y-5">
                {/* Upload Image */}
                <div className="space-y-2">
                  <Label>Thumbnail</Label>
                  <div
                    className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-muted-foreground/25 bg-muted/30 px-4 py-8 transition-colors hover:border-muted-foreground/40 hover:bg-muted/50"
                    onClick={() => {
                      // Simulate image upload
                      updateField('imagePreview', 'uploaded')
                    }}
                  >
                    {formData.imagePreview ? (
                      <div className="flex flex-col items-center gap-2">
                        <div className="flex h-20 w-20 items-center justify-center rounded-lg bg-emerald-100">
                          <ImagePlus className="h-8 w-8 text-emerald-600" />
                        </div>
                        <span className="text-xs text-emerald-600 font-medium">Image uploaded</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-xs text-destructive"
                          onClick={(e) => {
                            e.stopPropagation()
                            updateField('imagePreview', null)
                          }}
                        >
                          Remove
                        </Button>
                      </div>
                    ) : (
                      <>
                        <Upload className="h-8 w-8 text-muted-foreground/40" />
                        <p className="mt-2 text-sm text-muted-foreground">
                          Click to upload image
                        </p>
                        <p className="text-[11px] text-muted-foreground/60">
                          Recommended: 400&times;300px
                        </p>
                      </>
                    )}
                  </div>
                </div>

                {/* Title */}
                <div className="space-y-2">
                  <Label htmlFor="ts-title">
                    Title <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="ts-title"
                    placeholder="Enter test series title"
                    value={formData.title}
                    onChange={(e) => updateField('title', e.target.value)}
                  />
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="ts-description">Description</Label>
                  <Textarea
                    id="ts-description"
                    placeholder="Describe this test series..."
                    rows={4}
                    value={formData.description}
                    onChange={(e) => updateField('description', e.target.value)}
                  />
                </div>

                {/* Category/Exam */}
                <div className="space-y-2">
                  <Label>Category / Exam</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(v) => updateField('category', v)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.length > 0
                        ? categories.map((c) => (
                            <SelectItem key={c.id} value={c.name}>
                              {c.name}
                            </SelectItem>
                          ))
                        : ['JEE', 'NEET', 'CUET', 'GATE', 'UPSC', 'CAT', 'Other'].map((c) => (
                            <SelectItem key={c} value={c}>
                              {c}
                            </SelectItem>
                          ))
                      }
                    </SelectContent>
                  </Select>
                </div>

                {/* Price row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ts-price">Selling Price (₹)</Label>
                    <Input
                      id="ts-price"
                      type="number"
                      placeholder="0"
                      value={formData.price}
                      onChange={(e) => updateField('price', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ts-mrp">MRP (₹)</Label>
                    <Input
                      id="ts-mrp"
                      type="number"
                      placeholder="0"
                      value={formData.mrp}
                      onChange={(e) => updateField('mrp', e.target.value)}
                    />
                  </div>
                </div>

                {/* Sort Order + Status */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ts-sort-order">Sort Order</Label>
                    <Input
                      id="ts-sort-order"
                      type="number"
                      placeholder="0"
                      value={formData.sortOrder}
                      onChange={(e) => updateField('sortOrder', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(v) => updateField('status', v as 'published' | 'draft')}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator />

                {/* Validity Mode */}
                <div className="space-y-3">
                  <Label>Validity Mode</Label>
                  <RadioGroup
                    value={formData.validityMode}
                    onValueChange={(v) =>
                      updateField('validityMode', v as FormData['validityMode'])
                    }
                    className="flex flex-col gap-2 sm:flex-row sm:gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="days" id="validity-days" />
                      <Label htmlFor="validity-days" className="text-sm font-normal">
                        Validity Days
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="date" id="validity-date" />
                      <Label htmlFor="validity-date" className="text-sm font-normal">
                        End Date
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="lifetime" id="validity-lifetime" />
                      <Label htmlFor="validity-lifetime" className="text-sm font-normal">
                        Lifetime Access
                      </Label>
                    </div>
                  </RadioGroup>

                  {formData.validityMode === 'days' && (
                    <div className="space-y-2">
                      <Label htmlFor="ts-validity-days">Validity (Days)</Label>
                      <Input
                        id="ts-validity-days"
                        type="number"
                        placeholder="e.g. 365"
                        value={formData.validityDays}
                        onChange={(e) => updateField('validityDays', e.target.value)}
                      />
                    </div>
                  )}

                  {formData.validityMode === 'date' && (
                    <div className="space-y-2">
                      <Label htmlFor="ts-validity-date">End Date</Label>
                      <Input
                        id="ts-validity-date"
                        type="date"
                        value={formData.validityDate}
                        onChange={(e) => updateField('validityDate', e.target.value)}
                      />
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            {/* ── Advanced Tab ───────────────────────────────────────────── */}
            <TabsContent value="advanced" className="flex-1 overflow-y-auto px-6 py-5">
              <div className="space-y-5">
                {/* Enable Combo */}
                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <Label className="text-sm">Enable Combo</Label>
                    <p className="text-xs text-muted-foreground">
                      Bundle multiple tests into this series
                    </p>
                  </div>
                  <Switch
                    checked={formData.isCombo}
                    onCheckedChange={(v) => updateField('isCombo', v)}
                  />
                </div>

                {formData.isCombo && (
                  <div className="space-y-2">
                    <Label>Select Tests to Include</Label>
                    <div className="max-h-48 overflow-y-auto rounded-lg border p-2 space-y-1">
                      {loadingTests ? (
                        <div className="p-2 space-y-2">
                          <Skeleton className="h-5 w-full" />
                          <Skeleton className="h-5 w-3/4" />
                          <Skeleton className="h-5 w-1/2" />
                        </div>
                      ) : testOptions.length === 0 ? (
                        <div className="p-2 text-sm text-muted-foreground">No tests available</div>
                      ) : (
                        testOptions.map((test) => (
                          <label
                            key={test.id}
                            className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-muted/50 cursor-pointer"
                          >
                            <input
                              type="checkbox"
                              className="rounded border-muted-foreground/30"
                              checked={formData.selectedTests.includes(test.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  updateField('selectedTests', [
                                    ...formData.selectedTests,
                                    test.id,
                                  ])
                                } else {
                                  updateField(
                                    'selectedTests',
                                    formData.selectedTests.filter((t) => t !== test.id)
                                  )
                                }
                              }}
                            />
                            <span className="text-sm">{test.title}</span>
                          </label>
                        ))
                      )}
                    </div>
                    {formData.selectedTests.length > 0 && (
                      <p className="text-xs text-muted-foreground">
                        {formData.selectedTests.length} test(s) selected
                      </p>
                    )}
                  </div>
                )}

                {/* Include in Test Maker */}
                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <Label className="text-sm">Include in Test Maker</Label>
                    <p className="text-xs text-muted-foreground">
                      Allow students to create custom tests from this series
                    </p>
                  </div>
                  <Switch
                    checked={formData.includeTestMaker}
                    onCheckedChange={(v) => updateField('includeTestMaker', v)}
                  />
                </div>

                {/* Allow Payment */}
                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <Label className="text-sm">Allow Payment</Label>
                    <p className="text-xs text-muted-foreground">
                      Enable paid access for this test series
                    </p>
                  </div>
                  <Switch
                    checked={formData.allowPayment}
                    onCheckedChange={(v) => updateField('allowPayment', v)}
                  />
                </div>

                <Separator />

                {/* SEO Section */}
                <div className="space-y-1">
                  <h3 className="text-sm font-semibold">SEO Settings</h3>
                  <p className="text-xs text-muted-foreground">
                    Optimize how this series appears in search engines
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ts-seo-title">SEO Meta Title</Label>
                  <Input
                    id="ts-seo-title"
                    placeholder="Enter meta title for SEO"
                    value={formData.seoTitle}
                    onChange={(e) => updateField('seoTitle', e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ts-seo-desc">SEO Meta Description</Label>
                  <Textarea
                    id="ts-seo-desc"
                    placeholder="Enter meta description for SEO"
                    rows={3}
                    value={formData.seoDescription}
                    onChange={(e) => updateField('seoDescription', e.target.value)}
                  />
                </div>

                {/* Enable Rich Snippets */}
                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <Label className="text-sm">Enable Rich Snippets</Label>
                    <p className="text-xs text-muted-foreground">
                      Add structured data for better search appearance
                    </p>
                  </div>
                  <Switch
                    checked={formData.richSnippets}
                    onCheckedChange={(v) => updateField('richSnippets', v)}
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Sticky bottom bar */}
          <div className="border-t bg-white px-6 py-4 flex items-center justify-end gap-3 mt-auto">
            <Button
              variant="outline"
              onClick={() => {
                setDrawerOpen(false)
                resetForm()
              }}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={saving}>
              {saving ? 'Saving...' : editingId ? 'Update Test Series' : 'Save Test Series'}
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* ── Delete confirmation dialog ─────────────────────────────────── */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Test Series</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete{' '}
              <span className="font-semibold text-foreground">
                {seriesToDelete?.title}
              </span>
              ? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} disabled={deleting}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting ? 'Deleting...' : 'Delete'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
