'use client';

import React, { useState, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import {
  Bold,
  Italic,
  Underline,
  Image as ImageIcon,
  Superscript,
  Subscript,
  Pi,
  Camera,
  Plus,
  X,
  Play,
  Check,
  Loader2,
} from 'lucide-react';
import { apiFetch } from '@/lib/api-client';
import { toast } from 'sonner';

// ─── Types ───────────────────────────────────────────────────────────────────

type QuestionType =
  | 'MCQ'
  | 'Multiple Correct'
  | 'Assertion Reason'
  | 'Matching'
  | 'True/False'
  | 'Statement Based'
  | 'Numerical'
  | 'Subjective'
  | 'Image Based'
  | 'PDF Based'
  | 'OMR Based';

interface OptionData {
  id: string;
  text: string;
  imageUrl: string;
  isCorrect: boolean;
}

interface ImageSlot {
  id: string;
  url: string;
  name: string;
}

export interface QuestionData {
  id?: string;
  type?: QuestionType;
  questionType?: QuestionType;
  heading?: string;
  questionHeading?: string;
  directive?: string;
  title?: string;
  questionTitle?: string;
  images?: (ImageSlot | null)[];
  options?: OptionData[];
  correctOption?: string;
  solutionHeading?: string;
  solutionImages?: (ImageSlot | null)[];
  solutionVideoLink?: string;
  solutionText?: string;
  section?: string;
  marks?: number;
  positiveMarks?: number;
  negativeMarks?: number;
  sortOrder?: number;
  topic?: string;
  difficulty?: 'Easy' | 'Medium' | 'Hard';
  text?: string;
}

interface QuestionEditorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editData?: QuestionData | null;
  onSave?: () => void;
  testId?: string;
}

// ─── Constants ───────────────────────────────────────────────────────────────

const QUESTION_TYPES: QuestionType[] = [
  'MCQ',
  'Multiple Correct',
  'Assertion Reason',
  'Matching',
  'True/False',
  'Statement Based',
  'Numerical',
  'Subjective',
  'Image Based',
  'PDF Based',
  'OMR Based',
];

const TYPES_WITH_OPTIONS: QuestionType[] = [
  'MCQ',
  'Multiple Correct',
  'Assertion Reason',
  'Matching',
  'True/False',
  'Statement Based',
  'Image Based',
];

const TYPES_WITH_SINGLE_SELECT: QuestionType[] = [
  'MCQ',
  'Assertion Reason',
  'True/False',
];

const TYPES_WITH_MULTISelect: QuestionType[] = [
  'Multiple Correct',
  'Statement Based',
  'Image Based',
];

// ─── Formatting Toolbar ─────────────────────────────────────────────────────

function FormattingToolbar() {
  const toolButtons = [
    { icon: Bold, label: 'Bold' },
    { icon: Italic, label: 'Italic' },
    { icon: Underline, label: 'Underline' },
    { icon: ImageIcon, label: 'Image' },
    { icon: Superscript, label: 'Superscript' },
    { icon: Subscript, label: 'Subscript' },
    { icon: Pi, label: 'LaTeX/Math' },
  ];

  return (
    <div className="flex items-center border rounded-md overflow-hidden bg-gray-50">
      {toolButtons.map((tool) => (
        <button
          key={tool.label}
          type="button"
          className="flex items-center justify-center w-8 h-8 text-gray-600 hover:bg-gray-200 hover:text-gray-900 transition-colors border-r last:border-r-0"
          title={tool.label}
          aria-label={tool.label}
        >
          <tool.icon className="size-3.5" />
        </button>
      ))}
    </div>
  );
}

// ─── Image Upload Slot ──────────────────────────────────────────────────────

function ImageUploadSlot({
  label,
  image,
  onUpload,
  onRemove,
}: {
  label: string;
  image: ImageSlot | null;
  onUpload: () => void;
  onRemove: () => void;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {image ? (
        <div className="relative w-full h-24 rounded-lg border border-gray-200 overflow-hidden group">
          <div className="w-full h-full bg-gray-100 flex items-center justify-center">
            <ImageIcon className="size-8 text-gray-400" />
          </div>
          <button
            type="button"
            onClick={onRemove}
            className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
            aria-label={`Remove ${label}`}
          >
            <X className="size-3" />
          </button>
          <span className="absolute bottom-1 left-1 text-[10px] bg-black/50 text-white px-1.5 py-0.5 rounded truncate max-w-[calc(100%-8px)]">
            {image.name}
          </span>
        </div>
      ) : (
        <button
          type="button"
          onClick={onUpload}
          className="w-full h-24 rounded-lg border-2 border-dashed border-gray-300 hover:border-gray-400 hover:bg-gray-50 transition-colors flex flex-col items-center justify-center gap-1.5 cursor-pointer"
          aria-label={`Upload ${label}`}
        >
          <Camera className="size-6 text-gray-400" />
          <span className="text-xs text-gray-500">Click to upload</span>
        </button>
      )}
    </div>
  );
}

// ─── Main Component ─────────────────────────────────────────────────────────

export function QuestionEditor({
  open,
  onOpenChange,
  editData,
  onSave,
  testId,
}: QuestionEditorProps) {
  const isEditing = !!editData?.id;

  // ─── State ──────────────────────────────────────────────────────────────

  const [saving, setSaving] = useState(false);
  const [questionType, setQuestionType] = useState<QuestionType>(
    editData?.type ?? editData?.questionType ?? 'MCQ'
  );
  const [questionHeading, setQuestionHeading] = useState(
    editData?.heading ?? editData?.questionHeading ?? ''
  );
  const [directive, setDirective] = useState(editData?.directive ?? '');
  const [questionTitle, setQuestionTitle] = useState(
    editData?.title ?? editData?.questionTitle ?? ''
  );
  const [questionImages, setQuestionImages] = useState<(ImageSlot | null)[]>(
    editData?.images ?? [null, null, null]
  );
  const [options, setOptions] = useState<OptionData[]>(
    editData?.options ?? [
      { id: 'opt-1', text: '', imageUrl: '', isCorrect: false },
      { id: 'opt-2', text: '', imageUrl: '', isCorrect: false },
      { id: 'opt-3', text: '', imageUrl: '', isCorrect: false },
      { id: 'opt-4', text: '', imageUrl: '', isCorrect: false },
    ]
  );
  const [solutionHeading, setSolutionHeading] = useState(
    editData?.solutionHeading ?? ''
  );
  const [solutionImages, setSolutionImages] = useState<(ImageSlot | null)[]>(
    editData?.solutionImages ?? [null, null]
  );
  const [solutionVideoLink, setSolutionVideoLink] = useState(
    editData?.solutionVideoLink ?? ''
  );
  const [solutionText, setSolutionText] = useState(
    editData?.solutionText ?? ''
  );
  const [section, setSection] = useState(editData?.section ?? '');
  const [topic, setTopic] = useState(editData?.topic ?? '');
  const [positiveMarks, setPositiveMarks] = useState(
    editData?.marks ?? editData?.positiveMarks ?? 1
  );
  const [negativeMarks, setNegativeMarks] = useState(
    editData?.negativeMarks ?? 0
  );
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>(
    editData?.difficulty ?? 'Medium'
  );
  const [sortOrder, setSortOrder] = useState(editData?.sortOrder ?? 0);
  const [activeTab, setActiveTab] = useState('question');

  // ─── Derived ────────────────────────────────────────────────────────────

  const showOptions = TYPES_WITH_OPTIONS.includes(questionType);
  const isSingleSelect = TYPES_WITH_SINGLE_SELECT.includes(questionType);
  const isMultiSelect = TYPES_WITH_MULTISelect.includes(questionType);

  // ─── Build API Body ─────────────────────────────────────────────────────

  const buildBody = useCallback(() => {
    const correctOption = options.find((o) => o.isCorrect)?.id ?? '';
    return {
      type: questionType,
      heading: questionHeading,
      directive,
      title: questionTitle,
      images: questionImages,
      options: options.map((opt) => ({
        id: opt.id,
        text: opt.text,
        imageUrl: opt.imageUrl,
        isCorrect: opt.isCorrect,
      })),
      correctOption,
      solutionHeading,
      solutionImages,
      solutionVideoLink,
      solutionText,
      section,
      marks: positiveMarks,
      positiveMarks,
      negativeMarks,
      sortOrder,
      topic,
      difficulty,
      ...(testId ? { testId } : {}),
    };
  }, [
    questionType, questionHeading, directive, questionTitle, questionImages,
    options, solutionHeading, solutionImages, solutionVideoLink, solutionText,
    section, positiveMarks, negativeMarks, sortOrder, topic, difficulty, testId,
  ]);

  // ─── Save Handler ───────────────────────────────────────────────────────

  const doSave = useCallback(async () => {
    setSaving(true);
    try {
      const body = buildBody();
      let res: Response;

      if (isEditing && editData?.id) {
        res = await apiFetch(`/api/questions/${editData.id}`, {
          method: 'PUT',
          body: JSON.stringify(body),
        });
      } else {
        res = await apiFetch('/api/questions', {
          method: 'POST',
          body: JSON.stringify(body),
        });
      }

      if (!res.ok) {
        const errData = await res.json().catch(() => null);
        throw new Error(errData?.error ?? `Request failed with status ${res.status}`);
      }

      toast.success(isEditing ? 'Question updated successfully' : 'Question created successfully');
      onSave?.();
      return true;
    } catch (err: any) {
      toast.error(err.message ?? 'Failed to save question');
      return false;
    } finally {
      setSaving(false);
    }
  }, [buildBody, isEditing, editData, onSave]);

  // ─── Handlers ───────────────────────────────────────────────────────────

  const handleOptionTextChange = useCallback(
    (id: string, text: string) => {
      setOptions((prev) =>
        prev.map((opt) => (opt.id === id ? { ...opt, text } : opt))
      );
    },
    []
  );

  const handleCorrectAnswerChange = useCallback(
    (id: string, checked: boolean) => {
      if (isSingleSelect) {
        setOptions((prev) =>
          prev.map((opt) => ({
            ...opt,
            isCorrect: opt.id === id,
          }))
        );
      } else {
        setOptions((prev) =>
          prev.map((opt) =>
            opt.id === id ? { ...opt, isCorrect: checked } : opt
          )
        );
      }
    },
    [isSingleSelect]
  );

  const handleAddOption = useCallback(() => {
    if (options.length >= 6) return;
    const newId = `opt-${Date.now()}`;
    setOptions((prev) => [
      ...prev,
      { id: newId, text: '', imageUrl: '', isCorrect: false },
    ]);
  }, [options.length]);

  const handleRemoveOption = useCallback(
    (id: string) => {
      if (options.length <= 2) return;
      setOptions((prev) => prev.filter((opt) => opt.id !== id));
    },
    [options.length]
  );

  const handleSimulateUpload = useCallback(
    (
      setter: React.Dispatch<React.SetStateAction<(ImageSlot | null)[]>>
    ) => {
      return (index: number) => {
        setter((prev) => {
          const copy = [...prev];
          copy[index] = {
            id: `img-${Date.now()}`,
            url: '#',
            name: `image_${index + 1}.png`,
          };
          return copy;
        });
      };
    },
    []
  );

  const handleRemoveImage = useCallback(
    (
      setter: React.Dispatch<React.SetStateAction<(ImageSlot | null)[]>>
    ) => {
      return (index: number) => {
        setter((prev) => {
          const copy = [...prev];
          copy[index] = null;
          return copy;
        });
      };
    },
    []
  );

  const resetForm = useCallback(() => {
    setQuestionType('MCQ');
    setQuestionHeading('');
    setDirective('');
    setQuestionTitle('');
    setQuestionImages([null, null, null]);
    setOptions([
      { id: 'opt-1', text: '', imageUrl: '', isCorrect: false },
      { id: 'opt-2', text: '', imageUrl: '', isCorrect: false },
      { id: 'opt-3', text: '', imageUrl: '', isCorrect: false },
      { id: 'opt-4', text: '', imageUrl: '', isCorrect: false },
    ]);
    setSolutionHeading('');
    setSolutionImages([null, null]);
    setSolutionVideoLink('');
    setSolutionText('');
    setSection('');
    setTopic('');
    setPositiveMarks(1);
    setNegativeMarks(0);
    setDifficulty('Medium');
    setSortOrder(0);
    setActiveTab('question');
  }, []);

  const handleSaveAndClose = async () => {
    const ok = await doSave();
    if (ok) {
      onOpenChange(false);
    }
  };

  const handleSaveAndAdd = async () => {
    const ok = await doSave();
    if (ok) {
      resetForm();
    }
  };

  // ─── Option Label ──────────────────────────────────────────────────────

  const getOptionLabel = (index: number) => {
    const labels = ['A', 'B', 'C', 'D', 'E', 'F'];
    return labels[index] ?? String(index + 1);
  };

  // ─── Render ─────────────────────────────────────────────────────────────

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="sm:max-w-4xl max-h-[92vh] flex flex-col p-0 gap-0 overflow-hidden"
        showCloseButton={false}
      >
        {/* ─── Header ────────────────────────────────────────────────── */}
        <div className="flex items-center justify-between px-6 py-4 border-b bg-white shrink-0">
          <div className="flex items-center gap-4">
            <DialogTitle className="text-lg font-semibold text-gray-900">
              {isEditing ? 'Edit Question' : 'Add Question'}
            </DialogTitle>
            <Select
              value={questionType}
              onValueChange={(val) => setQuestionType(val as QuestionType)}
              disabled={saving}
            >
              <SelectTrigger className="w-[180px] h-8 text-sm">
                <SelectValue placeholder="Question Type" />
              </SelectTrigger>
              <SelectContent>
                {QUESTION_TYPES.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <button
            type="button"
            onClick={() => onOpenChange(false)}
            className="w-8 h-8 rounded-md flex items-center justify-center text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition-colors"
            aria-label="Close"
          >
            <X className="size-5" />
          </button>
        </div>
        <DialogDescription className="sr-only">
          {isEditing
            ? 'Edit the question details below'
            : 'Create a new question using the form below'}
        </DialogDescription>

        {/* ─── Tabs ──────────────────────────────────────────────────── */}
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="flex flex-col flex-1 min-h-0"
        >
          <div className="px-6 pt-3 shrink-0">
            <TabsList className="w-full max-w-md">
              <TabsTrigger value="question" className="flex-1">
                Question
              </TabsTrigger>
              <TabsTrigger value="solution" className="flex-1">
                Solution
              </TabsTrigger>
              <TabsTrigger value="metadata" className="flex-1">
                Metadata
              </TabsTrigger>
            </TabsList>
          </div>

          {/* ─── Scrollable Content ─────────────────────────────────── */}
          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6">
            {/* ─── Question Tab ──────────────────────────────────────── */}
            <TabsContent value="question" className="space-y-6 mt-0">
              {/* Question Heading */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Question Heading
                </Label>
                <FormattingToolbar />
                <Textarea
                  placeholder="Enter question heading or passage..."
                  value={questionHeading}
                  onChange={(e) => setQuestionHeading(e.target.value)}
                  className="min-h-[100px] resize-y"
                  disabled={saving}
                />
              </div>

              {/* Directive */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Directive{' '}
                  <span className="text-muted-foreground font-normal">
                    (optional)
                  </span>
                </Label>
                <Textarea
                  placeholder="Enter directive for passage-based questions..."
                  value={directive}
                  onChange={(e) => setDirective(e.target.value)}
                  className="min-h-[60px] resize-y"
                  disabled={saving}
                />
              </div>

              <Separator />

              {/* Question Title */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Question Title
                </Label>
                <FormattingToolbar />
                <Textarea
                  placeholder="Enter the question..."
                  value={questionTitle}
                  onChange={(e) => setQuestionTitle(e.target.value)}
                  className="min-h-[80px] resize-y"
                  disabled={saving}
                />
              </div>

              {/* Question Images */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Question Images
                </Label>
                <div className="grid grid-cols-3 gap-4">
                  {questionImages.map((img, idx) => (
                    <ImageUploadSlot
                      key={`q-img-${idx}`}
                      label={`Image ${idx + 1}`}
                      image={img}
                      onUpload={() =>
                        handleSimulateUpload(setQuestionImages)(idx)
                      }
                      onRemove={() =>
                        handleRemoveImage(setQuestionImages)(idx)
                      }
                    />
                  ))}
                </div>
              </div>

              {/* Options Section */}
              {showOptions && (
                <>
                  <Separator />
                  <div className="space-y-3">
                    <Label className="text-sm font-medium text-gray-700">
                      Options
                    </Label>

                    {/* Option rows */}
                    <div className="space-y-3">
                      {options.map((option, idx) => (
                        <div
                          key={option.id}
                          className="flex items-start gap-3 group"
                        >
                          {/* Option label */}
                          <div className="flex items-center justify-center w-7 h-9 rounded bg-gray-100 text-sm font-semibold text-gray-600 shrink-0">
                            {getOptionLabel(idx)}
                          </div>

                          {/* Option text input */}
                          <Input
                            placeholder={`Option ${idx + 1}`}
                            value={option.text}
                            onChange={(e) =>
                              handleOptionTextChange(option.id, e.target.value)
                            }
                            className="flex-1"
                            disabled={saving}
                          />

                          {/* Image upload button */}
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="h-9 px-2 shrink-0"
                            title="Attach image"
                            disabled={saving}
                          >
                            <ImageIcon className="size-4 text-gray-500" />
                          </Button>

                          {/* Correct answer indicator */}
                          {isSingleSelect ? (
                            <div className="flex items-center h-9 shrink-0">
                              <RadioGroup
                                value={
                                  option.isCorrect ? option.id : undefined
                                }
                                onValueChange={() =>
                                  handleCorrectAnswerChange(option.id, true)
                                }
                                className="flex"
                              >
                                <RadioGroupItem
                                  value={option.id}
                                  id={`correct-${option.id}`}
                                  className="data-[state=checked]:border-green-600 data-[state=checked]:text-green-600"
                                />
                              </RadioGroup>
                            </div>
                          ) : (
                            <div className="flex items-center h-9 shrink-0">
                              <Checkbox
                                checked={option.isCorrect}
                                onCheckedChange={(checked) =>
                                  handleCorrectAnswerChange(
                                    option.id,
                                    checked as boolean
                                  )
                                }
                                className="data-[state=checked]:bg-green-600 data-[state=checked]:border-green-600"
                              />
                            </div>
                          )}

                          {/* Remove option button */}
                          {options.length > 2 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveOption(option.id)}
                              className="w-7 h-9 flex items-center justify-center rounded text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100 shrink-0"
                              aria-label={`Remove option ${getOptionLabel(idx)}`}
                            >
                              <X className="size-4" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Add more options */}
                    {options.length < 6 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleAddOption}
                        className="mt-2 text-gray-600"
                        disabled={saving}
                      >
                        <Plus className="size-4 mr-1.5" />
                        Add Option
                      </Button>
                    )}

                    <p className="text-xs text-muted-foreground">
                      {isSingleSelect
                        ? 'Select one correct answer using the radio button'
                        : 'Select all correct answers using the checkboxes'}
                    </p>
                  </div>
                </>
              )}

              {/* Numerical type answer field */}
              {questionType === 'Numerical' && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">
                      Correct Answer (Numerical)
                    </Label>
                    <Input
                      type="number"
                      placeholder="Enter the correct numerical answer"
                      className="max-w-xs"
                      disabled={saving}
                    />
                  </div>
                </>
              )}

              {/* Subjective type answer field */}
              {questionType === 'Subjective' && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">
                      Model Answer
                    </Label>
                    <FormattingToolbar />
                    <Textarea
                      placeholder="Enter the model answer for reference..."
                      className="min-h-[120px] resize-y"
                      disabled={saving}
                    />
                  </div>
                </>
              )}
            </TabsContent>

            {/* ─── Solution Tab ──────────────────────────────────────── */}
            <TabsContent value="solution" className="space-y-6 mt-0">
              {/* Solution Heading */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Solution Heading
                </Label>
                <Input
                  placeholder="Enter solution heading..."
                  value={solutionHeading}
                  onChange={(e) => setSolutionHeading(e.target.value)}
                  disabled={saving}
                />
              </div>

              {/* Solution Images */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Solution Images
                </Label>
                <div className="grid grid-cols-2 gap-4">
                  {solutionImages.map((img, idx) => (
                    <ImageUploadSlot
                      key={`s-img-${idx}`}
                      label={`Image ${idx + 1}`}
                      image={img}
                      onUpload={() =>
                        handleSimulateUpload(setSolutionImages)(idx)
                      }
                      onRemove={() =>
                        handleRemoveImage(setSolutionImages)(idx)
                      }
                    />
                  ))}
                </div>
              </div>

              {/* Solution Video Link */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Solution Video Link
                </Label>
                <div className="relative">
                  <Play className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
                  <Input
                    placeholder="https://youtube.com/watch?v=..."
                    value={solutionVideoLink}
                    onChange={(e) => setSolutionVideoLink(e.target.value)}
                    className="pl-10"
                    disabled={saving}
                  />
                </div>
              </div>

              <Separator />

              {/* Solution Text */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Solution Text
                </Label>
                <FormattingToolbar />
                <Textarea
                  placeholder="Enter detailed solution explanation..."
                  value={solutionText}
                  onChange={(e) => setSolutionText(e.target.value)}
                  className="min-h-[150px] resize-y"
                  disabled={saving}
                />
              </div>
            </TabsContent>

            {/* ─── Metadata Tab ──────────────────────────────────────── */}
            <TabsContent value="metadata" className="space-y-6 mt-0">
              {/* Section */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Section
                </Label>
                <Input
                  placeholder="e.g., Physics, Chemistry, Mathematics..."
                  value={section}
                  onChange={(e) => setSection(e.target.value)}
                  disabled={saving}
                />
              </div>

              {/* Topic */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Topic
                </Label>
                <Input
                  placeholder="e.g., Mechanics, Organic Chemistry..."
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  disabled={saving}
                />
              </div>

              <Separator />

              {/* Marks Row */}
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-700">
                    Positive Marks
                  </Label>
                  <Input
                    type="number"
                    min={0}
                    value={positiveMarks}
                    onChange={(e) =>
                      setPositiveMarks(
                        parseFloat(e.target.value) || 0
                      )
                    }
                    className="max-w-[140px]"
                    disabled={saving}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-700">
                    Negative Marks
                  </Label>
                  <Input
                    type="number"
                    min={0}
                    step={0.25}
                    value={negativeMarks}
                    onChange={(e) =>
                      setNegativeMarks(
                        parseFloat(e.target.value) || 0
                      )
                    }
                    className="max-w-[140px]"
                    disabled={saving}
                  />
                </div>
              </div>

              {/* Sort Order */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Sort Order
                </Label>
                <Input
                  type="number"
                  min={0}
                  value={sortOrder}
                  onChange={(e) =>
                    setSortOrder(parseInt(e.target.value, 10) || 0)
                  }
                  className="max-w-[140px]"
                  disabled={saving}
                />
              </div>

              {/* Difficulty Level */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Difficulty Level
                </Label>
                <Select
                  value={difficulty}
                  onValueChange={(val) =>
                    setDifficulty(val as 'Easy' | 'Medium' | 'Hard')
                  }
                  disabled={saving}
                >
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Select difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Easy">
                      <span className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-green-500" />
                        Easy
                      </span>
                    </SelectItem>
                    <SelectItem value="Medium">
                      <span className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-yellow-500" />
                        Medium
                      </span>
                    </SelectItem>
                    <SelectItem value="Hard">
                      <span className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-red-500" />
                        Hard
                      </span>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>
          </div>
        </Tabs>

        {/* ─── Sticky Bottom Bar ──────────────────────────────────────── */}
        <div className="shrink-0 px-6 py-3 border-t bg-white flex items-center justify-end gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="min-w-[80px]"
            disabled={saving}
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={handleSaveAndAdd}
            className="min-w-[160px]"
            disabled={saving}
          >
            {saving ? (
              <Loader2 className="size-4 mr-1.5 animate-spin" />
            ) : (
              <Check className="size-4 mr-1.5" />
            )}
            Save &amp; Add Another
          </Button>
          <Button
            type="button"
            onClick={handleSaveAndClose}
            className="min-w-[120px] bg-black hover:bg-gray-800 text-white"
            disabled={saving}
          >
            {saving ? (
              <Loader2 className="size-4 mr-1.5 animate-spin" />
            ) : null}
            Save &amp; Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default QuestionEditor;
