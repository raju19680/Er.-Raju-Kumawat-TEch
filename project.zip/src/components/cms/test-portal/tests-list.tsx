'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useAppStore } from '@/lib/store'
import type { CMSPage } from '@/lib/store'
import { useModuleAccess } from '@/hooks/use-module-access'
import { apiFetchJSON } from '@/lib/api-client'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination'

import {
  Search,
  Plus,
  Filter,
  ArrowUpDown,
  MoreHorizontal,
  Lock,
  Circle,
  FileText,
  Pencil,
  Eye,
  Copy,
  Upload,
  ClipboardCheck,
  FileDown,
  RefreshCw,
  Trash2,
  X,
  AlertCircle,
} from 'lucide-react'
import { toast } from 'sonner'
import AddTestDrawer from '@/components/cms/test-portal/add-test-drawer'

// ── Types ──────────────────────────────────────────────────────────────────

interface TestItem {
  id: string
  title: string
  series: string
  testSeriesId: string
  questionsAdded: number
  totalQuestions: number
  totalMarks: number
  duration: number
  status: 'free' | 'paid'
  isLive: boolean
  isLocked: boolean
  price: number
  [key: string]: unknown
}

interface TestSeriesOption {
  id: string
  title: string
}

interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  limit: number
}

// ── Tab definition ──────────────────────────────────────────────────────────

const tabs: { label: string; page: CMSPage }[] = [
  { label: 'Tests', page: 'tests' },
  { label: 'Results', page: 'results' },
  { label: 'Bulk Uploader', page: 'bulk-uploader' },
  { label: 'Reported Questions', page: 'reported-questions' },
  { label: 'Question Library', page: 'question-library' },
]

// ── Component ──────────────────────────────────────────────────────────────

export default function TestsList() {
  const { currentPage, setCurrentPage, orgCode } = useAppStore()
  const { canCreate, canEdit, canDelete, canPublish, isFeatureEnabled } = useModuleAccess('tests')

  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [seriesFilter, setSeriesFilter] = useState<string>('all')
  const [priceFilter, setPriceFilter] = useState<string>('all')
  const [sortBy, setSortBy] = useState<string>('newest')
  const [showFilterDropdown, setShowFilterDropdown] = useState(false)
  const [currentPageNum, setCurrentPageNum] = useState(1)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [testToDelete, setTestToDelete] = useState<TestItem | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [editData, setEditData] = useState<TestItem | undefined>(undefined)

  // API-driven state
  const [tests, setTests] = useState<TestItem[]>([])
  const [totalItems, setTotalItems] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [togglingId, setTogglingId] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  // Test series options for filter dropdown
  const [seriesOptions, setSeriesOptions] = useState<TestSeriesOption[]>([])

  const itemsPerPage = 20

  // ── Fetch tests ────────────────────────────────────────────────────────────

  const fetchTests = useCallback(async () => {
    if (!orgCode) return
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams({
        search: searchQuery,
        page: String(currentPageNum),
        limit: String(itemsPerPage),
        organizationId: orgCode,
      })
      if (seriesFilter !== 'all') params.set('testSeriesId', seriesFilter)
      if (statusFilter === 'live') params.set('status', 'live')
      else if (statusFilter === 'draft') params.set('status', 'draft')

      const data = await apiFetchJSON<PaginatedResponse<TestItem>>(`/api/tests?${params.toString()}`)
      setTests(data.items || [])
      setTotalItems(data.total || 0)
    } catch (err) {
      console.error('Failed to fetch tests:', err)
      setError('Failed to load tests. Please try again.')
    } finally {
      setLoading(false)
    }
  }, [orgCode, searchQuery, currentPageNum, seriesFilter, statusFilter])

  // ── Fetch test series options ──────────────────────────────────────────────

  const fetchSeriesOptions = useCallback(async () => {
    if (!orgCode) return
    try {
      const data = await apiFetchJSON<PaginatedResponse<TestSeriesOption>>(
        `/api/test-series?organizationId=${orgCode}&limit=100`
      )
      setSeriesOptions(data.items || [])
    } catch {
      // Silently fail — filter dropdown just won't show options
    }
  }, [orgCode])

  useEffect(() => {
    fetchTests()
  }, [fetchTests])

  useEffect(() => {
    fetchSeriesOptions()
  }, [fetchSeriesOptions])

  // ── Toggle live/draft ──────────────────────────────────────────────────────

  const toggleLive = async (id: string, currentLive: boolean) => {
    setTogglingId(id)
    try {
      await apiFetchJSON(`/api/tests/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ isLive: !currentLive }),
      })
      toast.success(currentLive ? 'Test moved to draft' : 'Test is now live')
      fetchTests()
    } catch {
      toast.error('Failed to update test status')
    } finally {
      setTogglingId(null)
    }
  }

  // ── Delete test ────────────────────────────────────────────────────────────

  const handleDelete = async () => {
    if (!testToDelete) return
    setDeleting(true)
    try {
      await apiFetchJSON(`/api/tests/${testToDelete.id}`, { method: 'DELETE' })
      toast.success('Test deleted successfully')
      setDeleteDialogOpen(false)
      setTestToDelete(null)
      fetchTests()
    } catch {
      toast.error('Failed to delete test')
    } finally {
      setDeleting(false)
    }
  }

  // ── Client-side sort (API returns unsorted or by page) ────────────────────

  const sorted = [...tests].sort((a, b) => {
    if (sortBy === 'newest') return 0 // API default
    if (sortBy === 'oldest') return 0 // API default reversed — handled by API ideally
    if (sortBy === 'title-asc') return a.title.localeCompare(b.title)
    if (sortBy === 'title-desc') return b.title.localeCompare(a.title)
    return 0
  })

  // ── Client-side price filter (API may not support it) ─────────────────────

  const filtered = sorted.filter((t) => {
    if (priceFilter === 'free' && t.status !== 'free') return false
    if (priceFilter === 'paid' && t.status !== 'paid') return false
    return true
  })

  const totalPages = Math.max(1, Math.ceil(totalItems / itemsPerPage))

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <div className="space-y-5">
      {/* ── Tab navigation ──────────────────────────────────────────────── */}
      <div className="flex items-center gap-1 border-b overflow-x-auto">
        <div className="flex items-center gap-1">
        {tabs.map((tab) => (
          <button
            key={tab.page}
            onClick={() => setCurrentPage(tab.page)}
            className={`px-4 py-2.5 text-sm font-medium transition-colors relative whitespace-nowrap ${
              currentPage === tab.page
                ? 'text-foreground'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {tab.label}
            {currentPage === tab.page && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-foreground rounded-full" />
            )}
          </button>
        ))}
        </div>
      </div>

      {/* ── Header row ─────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-semibold tracking-tight">Tests</h1>
        {canCreate && <Button
          className="w-full sm:w-fit"
          onClick={() => {
            setEditData(undefined)
            setDrawerOpen(true)
          }}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Test
        </Button>}
      </div>

      {/* ── Search / Filter / Sort bar ─────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search tests..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value)
              setCurrentPageNum(1)
            }}
            className="pl-9 rounded-lg"
          />
        </div>

        {/* Filter + Sort row on mobile */}
        <div className="flex items-center gap-2 sm:contents">
        {/* Filter */}
        <div className="relative flex-1 sm:flex-none">
          <Button
            variant="outline"
            size="sm"
            className="gap-2 w-full sm:w-auto"
            onClick={() => setShowFilterDropdown(!showFilterDropdown)}
          >
            <Filter className="h-4 w-4" />
            Filters
            {(statusFilter !== 'all' || seriesFilter !== 'all' || priceFilter !== 'all') && (
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">
                {(statusFilter !== 'all' ? 1 : 0) +
                  (seriesFilter !== 'all' ? 1 : 0) +
                  (priceFilter !== 'all' ? 1 : 0)}
              </span>
            )}
          </Button>

          {showFilterDropdown && (
            <div className="absolute right-0 sm:right-0 left-0 sm:left-auto top-full z-50 mt-2 w-[calc(100vw-2rem)] sm:w-72 rounded-xl border bg-white p-4 shadow-lg">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm font-semibold">Filters</span>
                <button
                  onClick={() => setShowFilterDropdown(false)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">
                    Status
                  </label>
                  <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setCurrentPageNum(1) }}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="live">Live</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">
                    Test Series
                  </label>
                  <Select value={seriesFilter} onValueChange={(v) => { setSeriesFilter(v); setCurrentPageNum(1) }}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Series</SelectItem>
                      {seriesOptions.map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">
                    Free / Paid
                  </label>
                  <Select value={priceFilter} onValueChange={setPriceFilter}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="free">Free</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full"
                  onClick={() => {
                    setStatusFilter('all')
                    setSeriesFilter('all')
                    setPriceFilter('all')
                    setCurrentPageNum(1)
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Sort */}
        <div className="flex-1 sm:flex-none">
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-full sm:w-[160px]" size="sm">
            <ArrowUpDown className="mr-2 h-4 w-4" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">Newest First</SelectItem>
            <SelectItem value="oldest">Oldest First</SelectItem>
            <SelectItem value="title-asc">Title A → Z</SelectItem>
            <SelectItem value="title-desc">Title Z → A</SelectItem>
          </SelectContent>
        </Select>
        </div>
        </div>
      </div>

      {/* ── Error state ────────────────────────────────────────────────── */}
      {error && (
        <div className="flex items-center gap-3 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">
          <AlertCircle className="h-4 w-4 flex-shrink-0" />
          <span>{error}</span>
          <Button variant="ghost" size="sm" className="ml-auto" onClick={fetchTests}>
            Retry
          </Button>
        </div>
      )}

      {/* ── Data table ─────────────────────────────────────────────────── */}
      <div className="rounded-xl border bg-white overflow-x-auto">
        <Table className="min-w-[800px]">
          <TableHeader>
            <TableRow>
              <TableHead className="w-[280px]">Title</TableHead>
              <TableHead>Test Series</TableHead>
              <TableHead>Questions</TableHead>
              <TableHead>Total Marks</TableHead>
              <TableHead>Duration (mins)</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Live</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              // Loading skeletons
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-48" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-14" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-12" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-8" /></TableCell>
                </TableRow>
              ))
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="h-32 text-center text-muted-foreground">
                  No tests found.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((test) => (
                <TableRow key={test.id}>
                  {/* Title */}
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      {test.isLocked && (
                        <Lock className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                      )}
                      <span className={test.isLocked ? 'text-muted-foreground' : ''}>
                        {test.title}
                      </span>
                    </div>
                  </TableCell>

                  {/* Series */}
                  <TableCell className="text-muted-foreground">{test.series}</TableCell>

                  {/* Questions */}
                  <TableCell>
                    <span className="font-medium">{test.questionsAdded}</span>
                    <span className="text-muted-foreground"> / {test.totalQuestions}</span>
                  </TableCell>

                  {/* Total Marks */}
                  <TableCell>{test.totalMarks}</TableCell>

                  {/* Duration */}
                  <TableCell>{test.duration}</TableCell>

                  {/* Status */}
                  <TableCell>
                    <Badge
                      className={
                        test.status === 'free'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                      }
                    >
                      {test.status === 'free' ? 'Free' : `₹${test.price}`}
                    </Badge>
                  </TableCell>

                  {/* Live */}
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {canPublish ? (
                        <Switch
                          checked={test.isLive}
                          disabled={togglingId === test.id}
                          onCheckedChange={() => toggleLive(test.id, test.isLive)}
                          className="data-[state=checked]:bg-emerald-500"
                        />
                      ) : (
                        <Switch
                          checked={test.isLive}
                          disabled
                          className="data-[state=checked]:bg-emerald-500"
                        />
                      )}
                      {test.isLive && (
                        <span className="flex items-center gap-1 text-xs text-emerald-600 font-medium">
                          <Circle className="h-2 w-2 fill-emerald-500 text-emerald-500" />
                          Live
                        </span>
                      )}
                    </div>
                  </TableCell>

                  {/* Actions */}
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Open menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-52">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <FileText className="mr-2 h-4 w-4" />
                          Add Questions
                        </DropdownMenuItem>
                        {canEdit && <DropdownMenuItem
                          onClick={() => {
                            setEditData(test)
                            setDrawerOpen(true)
                          }}
                        >
                          <Pencil className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>}
                        <DropdownMenuItem>
                          <Eye className="mr-2 h-4 w-4" />
                          View Results
                        </DropdownMenuItem>
                        {isFeatureEnabled('duplicate') && <DropdownMenuItem>
                          <Copy className="mr-2 h-4 w-4" />
                          Duplicate
                        </DropdownMenuItem>}
                        <DropdownMenuSeparator />
                        {canPublish && <DropdownMenuItem>
                          <Upload className="mr-2 h-4 w-4" />
                          Publish Changes
                        </DropdownMenuItem>}
                        <DropdownMenuItem>
                          <ClipboardCheck className="mr-2 h-4 w-4" />
                          Review Questions
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <FileDown className="mr-2 h-4 w-4" />
                          Export to PDF
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <RefreshCw className="mr-2 h-4 w-4" />
                          Re-evaluate Attempts
                        </DropdownMenuItem>
                        {canDelete && <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            variant="destructive"
                            onClick={() => {
                              setTestToDelete(test)
                              setDeleteDialogOpen(true)
                            }}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </>}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* ── Pagination ─────────────────────────────────────────────────── */}
      {totalPages > 1 && (
        <div className="flex justify-center">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  onClick={() => setCurrentPageNum(Math.max(1, currentPageNum - 1))}
                  className={currentPageNum === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                />
              </PaginationItem>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <PaginationItem key={page}>
                  <PaginationLink
                    isActive={page === currentPageNum}
                    onClick={() => setCurrentPageNum(page)}
                    className="cursor-pointer"
                  >
                    {page}
                  </PaginationLink>
                </PaginationItem>
              ))}
              <PaginationItem>
                <PaginationNext
                  onClick={() => setCurrentPageNum(Math.min(totalPages, currentPageNum + 1))}
                  className={currentPageNum === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}

      {/* ── Add / Edit Test Drawer ──────────────────────────────────────── */}
      <AddTestDrawer
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
        editData={editData}
        onSave={fetchTests}
      />

      {/* ── Delete confirmation dialog ─────────────────────────────────── */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Test</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete{' '}
              <span className="font-semibold text-foreground">{testToDelete?.title}</span>? This
              action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} disabled={deleting}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting ? 'Deleting...' : 'Delete'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
