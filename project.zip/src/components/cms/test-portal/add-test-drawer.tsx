'use client'

import React, { useState, useEffect, useMemo } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetchJSON } from '@/lib/api-client'

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Skeleton } from '@/components/ui/skeleton'
import { Upload, FileText } from 'lucide-react'
import { toast } from 'sonner'

// ── Props ─────────────────────────────────────────────────────────────────────

interface AddTestDrawerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  editData?: Record<string, unknown>
  onSave?: () => void
}

// ── Form state type ───────────────────────────────────────────────────────────

interface FormState {
  title: string
  status: 'free' | 'paid'
  instructions: string
  testSeriesId: string
  numQuestions: string
  totalMarks: string
  duration: string
  sortingOrder: string
  sectionWiseMarks: boolean
  negativeMarks: string
  startDate: string
  endDate: string
  language: string
  translationTitle: string
  maxAttempts: string
  shuffleQuestions: boolean
  shuffleOptions: boolean
  displayPause: boolean
  allowTestAttempt: boolean
  allQuestionsCompulsory: boolean
  uiType: string
  allowPdfExport: boolean
  enablePartialScoring: boolean
  displayResults: boolean
  displayRank: boolean
  showSolution: boolean
  showTotalStudents: boolean
  showPercentile: boolean
  solutionLink: string
  telegramSettings: string
  markAsLive: boolean
  enabled: boolean
  price: string
}

const defaultFormState: FormState = {
  title: '',
  status: 'free',
  instructions: '',
  testSeriesId: '',
  numQuestions: '',
  totalMarks: '',
  duration: '',
  sortingOrder: '',
  sectionWiseMarks: false,
  negativeMarks: '',
  startDate: '',
  endDate: '',
  language: 'english',
  translationTitle: '',
  maxAttempts: '',
  shuffleQuestions: false,
  shuffleOptions: false,
  displayPause: false,
  allowTestAttempt: true,
  allQuestionsCompulsory: true,
  uiType: 'default',
  allowPdfExport: false,
  enablePartialScoring: false,
  displayResults: true,
  displayRank: true,
  showSolution: true,
  showTotalStudents: false,
  showPercentile: false,
  solutionLink: '',
  telegramSettings: '',
  markAsLive: false,
  enabled: true,
  price: '',
}

function getInitialState(editData?: Record<string, unknown>): FormState {
  if (!editData) return { ...defaultFormState }
  return {
    ...defaultFormState,
    title: (editData.title as string) || '',
    status: (editData.status as 'free' | 'paid') || 'free',
    instructions: (editData.instructions as string) || '',
    testSeriesId: (editData.testSeriesId as string) || (editData.series as string) || '',
    numQuestions: (editData.totalQuestions ?? editData.numQuestions ?? '').toString(),
    totalMarks: (editData.totalMarks ?? '').toString(),
    duration: (editData.duration ?? '').toString(),
    sortingOrder: (editData.sortingOrder ?? '').toString(),
    sectionWiseMarks: (editData.sectionWiseMarks as boolean) || false,
    negativeMarks: (editData.negativeMarks ?? '').toString(),
    startDate: (editData.startDate as string) || '',
    endDate: (editData.endDate as string) || '',
    language: (editData.language as string) || 'english',
    translationTitle: (editData.translationTitle as string) || '',
    maxAttempts: (editData.maxAttempts ?? '').toString(),
    shuffleQuestions: (editData.shuffleQuestions as boolean) || false,
    shuffleOptions: (editData.shuffleOptions as boolean) || false,
    displayPause: (editData.displayPause as boolean) || false,
    allowTestAttempt: (editData.allowTestAttempt as boolean) ?? true,
    allQuestionsCompulsory: (editData.allQuestionsCompulsory as boolean) ?? true,
    uiType: (editData.uiType as string) || 'default',
    allowPdfExport: (editData.allowPdfExport as boolean) || false,
    enablePartialScoring: (editData.enablePartialScoring as boolean) || false,
    displayResults: (editData.displayResults as boolean) ?? true,
    displayRank: (editData.displayRank as boolean) ?? true,
    showSolution: (editData.showSolution as boolean) ?? true,
    showTotalStudents: (editData.showTotalStudents as boolean) || false,
    showPercentile: (editData.showPercentile as boolean) || false,
    solutionLink: (editData.solutionLink as string) || '',
    telegramSettings: (editData.telegramSettings as string) || '',
    markAsLive: (editData.isLive as boolean) || (editData.markAsLive as boolean) || false,
    enabled: (editData.enabled as boolean) ?? true,
    price: (editData.price ?? '').toString(),
  }
}

// ── Test Series option ────────────────────────────────────────────────────────

interface TestSeriesOption {
  id: string
  title: string
}

// ── Inner form component (keyed to reset on editData change) ──────────────────

function DrawerFormContent({
  editData,
  onOpenChange,
  onSave,
}: {
  editData?: Record<string, unknown>
  onOpenChange: (open: boolean) => void
  onSave?: () => void
}) {
  const { orgCode } = useAppStore()
  const isEditMode = !!editData
  const editId = editData?.id as string | undefined

  const [form, setForm] = useState<FormState>(() => getInitialState(editData))
  const [saving, setSaving] = useState(false)
  const [seriesOptions, setSeriesOptions] = useState<TestSeriesOption[]>([])
  const [loadingSeries, setLoadingSeries] = useState(true)

  // Fetch test series options from API
  useEffect(() => {
    async function loadSeries() {
      if (!orgCode) return
      setLoadingSeries(true)
      try {
        const data = await apiFetchJSON<{ items: TestSeriesOption[] }>(
          `/api/test-series?organizationId=${orgCode}&limit=100`
        )
        setSeriesOptions(data.items || [])
      } catch {
        // Silently fail — dropdown will be empty
      } finally {
        setLoadingSeries(false)
      }
    }
    loadSeries()
  }, [orgCode])

  const updateField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  // ── Build request body ───────────────────────────────────────────────────

  const buildBody = (): Record<string, unknown> => ({
    title: form.title,
    status: form.status,
    instructions: form.instructions,
    testSeriesId: form.testSeriesId,
    totalQuestions: form.numQuestions ? Number(form.numQuestions) : undefined,
    totalMarks: form.totalMarks ? Number(form.totalMarks) : undefined,
    duration: form.duration ? Number(form.duration) : undefined,
    sortingOrder: form.sortingOrder ? Number(form.sortingOrder) : undefined,
    sectionWiseMarks: form.sectionWiseMarks,
    negativeMarks: form.negativeMarks ? Number(form.negativeMarks) : undefined,
    startDate: form.startDate || undefined,
    endDate: form.endDate || undefined,
    language: form.language,
    translationTitle: form.translationTitle || undefined,
    maxAttempts: form.maxAttempts ? Number(form.maxAttempts) : undefined,
    shuffleQuestions: form.shuffleQuestions,
    shuffleOptions: form.shuffleOptions,
    displayPause: form.displayPause,
    allowTestAttempt: form.allowTestAttempt,
    allQuestionsCompulsory: form.allQuestionsCompulsory,
    uiType: form.uiType,
    allowPdfExport: form.allowPdfExport,
    enablePartialScoring: form.enablePartialScoring,
    displayResults: form.displayResults,
    displayRank: form.displayRank,
    showSolution: form.showSolution,
    showTotalStudents: form.showTotalStudents,
    showPercentile: form.showPercentile,
    solutionLink: form.solutionLink || undefined,
    telegramSettings: form.telegramSettings || undefined,
    isLive: form.markAsLive,
    enabled: form.enabled,
    price: form.status === 'paid' && form.price ? Number(form.price) : 0,
    organizationId: orgCode,
  })

  // ── Save handler ─────────────────────────────────────────────────────────

  const handleSave = async () => {
    if (!form.title.trim()) {
      toast.error('Title is required')
      return
    }

    setSaving(true)
    try {
      const body = buildBody()

      if (isEditMode && editId) {
        await apiFetchJSON(`/api/tests/${editId}`, {
          method: 'PUT',
          body: JSON.stringify(body),
        })
        toast.success('Test updated successfully')
      } else {
        await apiFetchJSON('/api/tests', {
          method: 'POST',
          body: JSON.stringify(body),
        })
        toast.success('Test created successfully')
      }

      onOpenChange(false)
      onSave?.()
    } catch (err) {
      console.error('Failed to save test:', err)
      toast.error(isEditMode ? 'Failed to update test' : 'Failed to create test')
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      {/* Header */}
      <SheetHeader className="p-6 pb-4 border-b">
        <SheetTitle className="text-lg">
          {isEditMode ? 'Edit Test' : 'Add Test'}
        </SheetTitle>
        <SheetDescription>
          {isEditMode
            ? 'Update the test details below.'
            : 'Fill in the details to create a new test.'}
        </SheetDescription>
      </SheetHeader>

      {/* Tabs + Content */}
      <Tabs defaultValue="basic" className="flex flex-col flex-1 overflow-hidden">
        <div className="px-6 pt-4 border-b">
          <TabsList className="w-full justify-start rounded-none bg-transparent p-0">
            <TabsTrigger
              value="basic"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2"
            >
              Basic
            </TabsTrigger>
            <TabsTrigger
              value="advanced"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2"
            >
              Advanced
            </TabsTrigger>
          </TabsList>
        </div>

        {/* ── Basic Tab ──────────────────────────────────────────────── */}
        <TabsContent value="basic" className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Title */}
          <div className="space-y-1.5">
            <Label htmlFor="test-title">
              Title <span className="text-destructive">*</span>
            </Label>
            <Input
              id="test-title"
              placeholder="Enter test title"
              value={form.title}
              onChange={(e) => updateField('title', e.target.value)}
            />
          </div>

          {/* Status */}
          <div className="space-y-1.5">
            <Label>Status</Label>
            <RadioGroup
              value={form.status}
              onValueChange={(v) => updateField('status', v as 'free' | 'paid')}
              className="flex items-center gap-6"
            >
              <div className="flex items-center gap-2">
                <RadioGroupItem value="free" id="status-free" />
                <Label htmlFor="status-free" className="cursor-pointer font-normal">
                  Free
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <RadioGroupItem value="paid" id="status-paid" />
                <Label htmlFor="status-paid" className="cursor-pointer font-normal">
                  Paid
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Price (if paid) */}
          {form.status === 'paid' && (
            <div className="space-y-1.5">
              <Label htmlFor="test-price">Price (₹)</Label>
              <Input
                id="test-price"
                type="number"
                placeholder="0"
                value={form.price}
                onChange={(e) => updateField('price', e.target.value)}
              />
            </div>
          )}

          {/* Test Instructions */}
          <div className="space-y-1.5">
            <Label htmlFor="test-instructions">Test Instructions</Label>
            <Textarea
              id="test-instructions"
              placeholder="Enter test instructions..."
              rows={4}
              value={form.instructions}
              onChange={(e) => updateField('instructions', e.target.value)}
            />
          </div>

          {/* Test Series */}
          <div className="space-y-1.5">
            <Label>Test Series</Label>
            <Select value={form.testSeriesId} onValueChange={(v) => updateField('testSeriesId', v)}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select test series" />
              </SelectTrigger>
              <SelectContent>
                {loadingSeries ? (
                  <div className="p-2 space-y-2">
                    <Skeleton className="h-5 w-full" />
                    <Skeleton className="h-5 w-3/4" />
                  </div>
                ) : seriesOptions.length === 0 ? (
                  <div className="p-2 text-sm text-muted-foreground">No test series found</div>
                ) : (
                  seriesOptions.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.title}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Number of Questions / Total Marks / Duration — 3 col */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="space-y-1.5">
              <Label htmlFor="num-questions">No. of Questions</Label>
              <Input
                id="num-questions"
                type="number"
                placeholder="0"
                value={form.numQuestions}
                onChange={(e) => updateField('numQuestions', e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="total-marks">Total Marks</Label>
              <Input
                id="total-marks"
                type="number"
                placeholder="0"
                value={form.totalMarks}
                onChange={(e) => updateField('totalMarks', e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="duration">Duration (mins)</Label>
              <Input
                id="duration"
                type="number"
                placeholder="0"
                value={form.duration}
                onChange={(e) => updateField('duration', e.target.value)}
              />
            </div>
          </div>

          {/* Sorting Order / Negative Marks — 2 col */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="sorting-order">Sorting Order</Label>
              <Input
                id="sorting-order"
                type="number"
                placeholder="0"
                value={form.sortingOrder}
                onChange={(e) => updateField('sortingOrder', e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="negative-marks">Negative Marks / Question</Label>
              <Input
                id="negative-marks"
                type="number"
                step="0.25"
                placeholder="0"
                value={form.negativeMarks}
                onChange={(e) => updateField('negativeMarks', e.target.value)}
              />
            </div>
          </div>

          {/* Section-wise marks toggle */}
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label className="cursor-pointer">Section-wise Marks</Label>
              <p className="text-xs text-muted-foreground">
                Enable different marks per section
              </p>
            </div>
            <Switch
              checked={form.sectionWiseMarks}
              onCheckedChange={(v) => updateField('sectionWiseMarks', v)}
            />
          </div>

          <Separator />

          {/* Start / End date */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="start-date">Start Date</Label>
              <Input
                id="start-date"
                type="datetime-local"
                value={form.startDate}
                onChange={(e) => updateField('startDate', e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="end-date">End Date</Label>
              <Input
                id="end-date"
                type="datetime-local"
                value={form.endDate}
                onChange={(e) => updateField('endDate', e.target.value)}
              />
            </div>
          </div>
        </TabsContent>

        {/* ── Advanced Tab ───────────────────────────────────────────── */}
        <TabsContent value="advanced" className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Language */}
          <div className="space-y-1.5">
            <Label>Language</Label>
            <Select value={form.language} onValueChange={(v) => updateField('language', v)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="english">English</SelectItem>
                <SelectItem value="hindi">Hindi</SelectItem>
                <SelectItem value="bilingual">Bilingual</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Translation title (if Hindi/Bilingual) */}
          {(form.language === 'hindi' || form.language === 'bilingual') && (
            <div className="space-y-1.5">
              <Label htmlFor="translation-title">Translation Test Title</Label>
              <Input
                id="translation-title"
                placeholder="Enter test title in Hindi"
                value={form.translationTitle}
                onChange={(e) => updateField('translationTitle', e.target.value)}
              />
            </div>
          )}

          {/* Maximum Attempts */}
          <div className="space-y-1.5">
            <Label htmlFor="max-attempts">Maximum Attempts Allowed</Label>
            <Input
              id="max-attempts"
              type="number"
              placeholder="Unlimited"
              value={form.maxAttempts}
              onChange={(e) => updateField('maxAttempts', e.target.value)}
            />
          </div>

          <Separator />

          {/* Toggle group: Shuffle & Pause */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Shuffle Questions</Label>
              <Switch
                checked={form.shuffleQuestions}
                onCheckedChange={(v) => updateField('shuffleQuestions', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Shuffle Options</Label>
              <Switch
                checked={form.shuffleOptions}
                onCheckedChange={(v) => updateField('shuffleOptions', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Display Pause Option</Label>
              <Switch
                checked={form.displayPause}
                onCheckedChange={(v) => updateField('displayPause', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Allow Test Attempt</Label>
              <Switch
                checked={form.allowTestAttempt}
                onCheckedChange={(v) => updateField('allowTestAttempt', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">All Questions Compulsory</Label>
              <Switch
                checked={form.allQuestionsCompulsory}
                onCheckedChange={(v) => updateField('allQuestionsCompulsory', v)}
              />
            </div>
          </div>

          <Separator />

          {/* UI Type */}
          <div className="space-y-1.5">
            <Label>UI Type</Label>
            <Select value={form.uiType} onValueChange={(v) => updateField('uiType', v)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default</SelectItem>
                <SelectItem value="two-column">Two Column</SelectItem>
                <SelectItem value="one-column">One Column</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Attach PDF */}
          <div className="space-y-1.5">
            <Label>Attach PDF</Label>
            <div className="flex items-center justify-center rounded-lg border-2 border-dashed p-8 transition-colors hover:border-muted-foreground/50">
              <div className="text-center">
                <Upload className="mx-auto h-8 w-8 text-muted-foreground" />
                <p className="mt-2 text-sm text-muted-foreground">
                  Drag & drop a PDF here, or click to browse
                </p>
                <Button variant="outline" size="sm" className="mt-3">
                  <FileText className="mr-2 h-4 w-4" />
                  Choose File
                </Button>
              </div>
            </div>
          </div>

          <Separator />

          {/* More toggles */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Allow PDF Export</Label>
              <Switch
                checked={form.allowPdfExport}
                onCheckedChange={(v) => updateField('allowPdfExport', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Enable Partial Scoring</Label>
              <Switch
                checked={form.enablePartialScoring}
                onCheckedChange={(v) => updateField('enablePartialScoring', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Display Test Results</Label>
              <Switch
                checked={form.displayResults}
                onCheckedChange={(v) => updateField('displayResults', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Display Rank</Label>
              <Switch
                checked={form.displayRank}
                onCheckedChange={(v) => updateField('displayRank', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Show Solution</Label>
              <Switch
                checked={form.showSolution}
                onCheckedChange={(v) => updateField('showSolution', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Show Total Students</Label>
              <Switch
                checked={form.showTotalStudents}
                onCheckedChange={(v) => updateField('showTotalStudents', v)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="cursor-pointer">Show Percentile</Label>
              <Switch
                checked={form.showPercentile}
                onCheckedChange={(v) => updateField('showPercentile', v)}
              />
            </div>
          </div>

          <Separator />

          {/* Test Solution Link */}
          <div className="space-y-1.5">
            <Label htmlFor="solution-link">Test Solution Link</Label>
            <Input
              id="solution-link"
              type="url"
              placeholder="https://..."
              value={form.solutionLink}
              onChange={(e) => updateField('solutionLink', e.target.value)}
            />
          </div>

          {/* Telegram Settings */}
          <div className="space-y-1.5">
            <Label htmlFor="telegram-settings">Telegram Settings</Label>
            <Input
              id="telegram-settings"
              placeholder="Telegram channel or group link"
              value={form.telegramSettings}
              onChange={(e) => updateField('telegramSettings', e.target.value)}
            />
          </div>

          <Separator />

          {/* Live / Enabled toggles */}
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <Label className="cursor-pointer">Mark Test as Live</Label>
                <p className="text-xs text-muted-foreground">
                  Make the test visible to students immediately
                </p>
              </div>
              <Switch
                checked={form.markAsLive}
                onCheckedChange={(v) => updateField('markAsLive', v)}
              />
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <Label className="cursor-pointer">Enable / Disable Status</Label>
                <p className="text-xs text-muted-foreground">
                  Disable to prevent any access to this test
                </p>
              </div>
              <Switch
                checked={form.enabled}
                onCheckedChange={(v) => updateField('enabled', v)}
              />
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* ── Sticky bottom bar ──────────────────────────────────────────── */}
      <div className="border-t bg-white p-4 flex items-center justify-end gap-3">
        <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
          Cancel
        </Button>
        <Button onClick={handleSave} disabled={saving}>
          {saving ? 'Saving...' : isEditMode ? 'Update Test' : 'Create Test'}
        </Button>
      </div>
    </>
  )
}

// ── Main exported component ───────────────────────────────────────────────────

export default function AddTestDrawer({ open, onOpenChange, editData, onSave }: AddTestDrawerProps) {
  // Use editData?.id as key so the form resets when switching between tests
  const formKey = (editData?.id as string) ?? 'new'

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-lg md:max-w-xl lg:max-w-2xl p-0 flex flex-col"
      >
        <DrawerFormContent key={formKey} editData={editData} onOpenChange={onOpenChange} onSave={onSave} />
      </SheetContent>
    </Sheet>
  )
}
