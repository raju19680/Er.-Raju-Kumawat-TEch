import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { decode } from 'next-auth/jwt'

const AUTH_SECRET = process.env.NEXTAUTH_SECRET || 'er-raju-kumawat-tech-secret-key-2024'

// NextAuth internal routes that handle their own auth — skip middleware for these
const SKIP_PATHS = [
  '/api/auth/callback',
  '/api/auth/session',
  '/api/auth/csrf',
  '/api/auth/providers',
  '/api/auth/direct-login',
  '/api/auth/forgot-password',
  '/api/auth/reset-password',
  '/api/auth/verify-org',
]

function safeHeader(value: string): string {
  if (/^[\x00-\xFF]*$/.test(value)) {
    return value
  }
  return encodeURIComponent(value)
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl

  if (!pathname.startsWith('/api/')) {
    return NextResponse.next()
  }

  if (SKIP_PATHS.some(p => pathname.startsWith(p))) {
    return NextResponse.next()
  }

  // ── Strategy 1: Check x-auth-token header FIRST (works in cross-origin) ──
  const authToken = req.headers.get('x-auth-token')
  if (authToken) {
    try {
      const decoded = await decode({
        token: authToken,
        secret: AUTH_SECRET,
      })

      if (decoded && decoded.email) {
        const requestHeaders = new Headers(req.headers)
        requestHeaders.set('x-auth-verified', 'true')
        requestHeaders.set('x-auth-user-id', safeHeader((decoded.id as string) || (decoded.sub as string) || ''))
        requestHeaders.set('x-auth-user-email', safeHeader((decoded.email as string) || ''))
        requestHeaders.set('x-auth-user-name', safeHeader((decoded.name as string) || ''))
        requestHeaders.set('x-auth-user-role', safeHeader((decoded.role as string) || ''))
        requestHeaders.set('x-auth-user-org-id', safeHeader((decoded.orgId as string) || ''))
        requestHeaders.set('x-auth-user-org-code', safeHeader((decoded.orgCode as string) || ''))
        requestHeaders.set('x-auth-user-org-name', safeHeader((decoded.orgName as string) || ''))
        requestHeaders.set('x-auth-user-org-accent', safeHeader((decoded.orgAccent as string) || ''))
        requestHeaders.set('x-auth-user-login-mode', safeHeader((decoded.loginMode as string) || ''))

        return NextResponse.next({
          request: { headers: requestHeaders },
        })
      }
    } catch {
      // Token decode failed, try other strategies
    }
  }

  // ── Strategy 1b: Check erkt_api_token cookie (fallback for iframe/preview) ──
  const cookieToken = req.cookies.get('erkt_api_token')?.value
  if (cookieToken && cookieToken.length > 20) {
    try {
      const decoded = await decode({
        token: cookieToken,
        secret: AUTH_SECRET,
      })

      if (decoded && decoded.email) {
        const requestHeaders = new Headers(req.headers)
        requestHeaders.set('x-auth-verified', 'true')
        requestHeaders.set('x-auth-user-id', safeHeader((decoded.id as string) || (decoded.sub as string) || ''))
        requestHeaders.set('x-auth-user-email', safeHeader((decoded.email as string) || ''))
        requestHeaders.set('x-auth-user-name', safeHeader((decoded.name as string) || ''))
        requestHeaders.set('x-auth-user-role', safeHeader((decoded.role as string) || ''))
        requestHeaders.set('x-auth-user-org-id', safeHeader((decoded.orgId as string) || ''))
        requestHeaders.set('x-auth-user-org-code', safeHeader((decoded.orgCode as string) || ''))
        requestHeaders.set('x-auth-user-org-name', safeHeader((decoded.orgName as string) || ''))
        requestHeaders.set('x-auth-user-org-accent', safeHeader((decoded.orgAccent as string) || ''))
        requestHeaders.set('x-auth-user-login-mode', safeHeader((decoded.loginMode as string) || ''))

        return NextResponse.next({
          request: { headers: requestHeaders },
        })
      }
    } catch {
      // Cookie token decode failed, try session cookie
    }
  }

  // ── Strategy 2: Check session cookie (fallback for same-origin) ──
  const sessionToken =
    req.cookies.get('next-auth.session-token')?.value ||
    req.cookies.get('__Secure-next-auth.session-token')?.value ||
    req.cookies.get('__Host-next-auth.session-token')?.value

  if (!sessionToken) {
    return NextResponse.next()
  }

  try {
    const decoded = await decode({
      token: sessionToken,
      secret: AUTH_SECRET,
    })

    if (!decoded || !decoded.email) {
      return NextResponse.next()
    }

    const requestHeaders = new Headers(req.headers)
    requestHeaders.set('x-auth-verified', 'true')
    requestHeaders.set('x-auth-user-id', safeHeader((decoded.id as string) || (decoded.sub as string) || ''))
    requestHeaders.set('x-auth-user-email', safeHeader((decoded.email as string) || ''))
    requestHeaders.set('x-auth-user-name', safeHeader((decoded.name as string) || ''))
    requestHeaders.set('x-auth-user-role', safeHeader((decoded.role as string) || ''))
    requestHeaders.set('x-auth-user-org-id', safeHeader((decoded.orgId as string) || ''))
    requestHeaders.set('x-auth-user-org-code', safeHeader((decoded.orgCode as string) || ''))
    requestHeaders.set('x-auth-user-org-name', safeHeader((decoded.orgName as string) || ''))
    requestHeaders.set('x-auth-user-org-accent', safeHeader((decoded.orgAccent as string) || ''))
    requestHeaders.set('x-auth-user-login-mode', safeHeader((decoded.loginMode as string) || ''))

    return NextResponse.next({
      request: { headers: requestHeaders },
    })
  } catch {
    return NextResponse.next()
  }
}

export const config = {
  matcher: ['/api/:path*'],
}
