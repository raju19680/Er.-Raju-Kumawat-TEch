import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth-helpers'

export async function GET(req: NextRequest) {
  try {
    const auth = await getAuthUser(req)
    if (!auth) {
      return NextResponse.json({ success: false, message: 'Authentication required' }, { status: 401 })
    }

    if (auth.role !== 'student') {
      return NextResponse.json({ success: false, message: 'Access denied' }, { status: 403 })
    }

    const student = await db.student.findFirst({
      where: { userId: auth.id },
    })
    if (!student) {
      return NextResponse.json({ success: false, message: 'Student profile not found' }, { status: 404 })
    }

    // Get purchased courses
    const purchasedCourses = await db.purchasedCourse.findMany({
      where: { studentId: student.id },
      select: {
        id: true,
        purchasedAt: true,
        expiresAt: true,
        course: {
          select: {
            id: true,
            title: true,
            description: true,
            thumbnail: true,
            category: true,
            status: true,
            content: true,
          },
        },
      },
      orderBy: { purchasedAt: 'desc' },
    })

    const formatted = purchasedCourses.map((pc) => ({
      id: pc.id,
      purchasedAt: pc.purchasedAt,
      expiresAt: pc.expiresAt,
      course: pc.course,
    }))

    return NextResponse.json({ success: true, courses: formatted })
  } catch (error) {
    console.error('Student courses list error:', error)
    return NextResponse.json({ success: false, message: 'Something went wrong' }, { status: 500 })
  }
}
