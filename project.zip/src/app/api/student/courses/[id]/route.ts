import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth-helpers'

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const auth = await getAuthUser(req)
    if (!auth) {
      return NextResponse.json({ success: false, message: 'Authentication required' }, { status: 401 })
    }

    if (auth.role !== 'student') {
      return NextResponse.json({ success: false, message: 'Access denied' }, { status: 403 })
    }

    const { id } = await params

    const student = await db.student.findFirst({
      where: { userId: auth.id },
    })
    if (!student) {
      return NextResponse.json({ success: false, message: 'Student profile not found' }, { status: 404 })
    }

    // Check if student purchased this course
    const purchase = await db.purchasedCourse.findFirst({
      where: { studentId: student.id, courseId: id },
    })

    if (!purchase) {
      return NextResponse.json({ success: false, message: 'You have not purchased this course' }, { status: 403 })
    }

    // Get course with modules and lessons
    const course = await db.course.findFirst({
      where: { id, organizationId: auth.orgId },
      select: {
        id: true,
        title: true,
        description: true,
        thumbnail: true,
        category: true,
        content: true,
        language: true,
        level: true,
        status: true,
        modules: {
          select: {
            id: true,
            title: true,
            description: true,
            sortOrder: true,
            lessons: {
              select: {
                id: true,
                title: true,
                type: true,
                content: true,
                videoUrl: true,
                videoDuration: true,
                fileUrl: true,
                notes: true,
                isFree: true,
                sortOrder: true,
              },
              orderBy: { sortOrder: 'asc' },
            },
          },
          orderBy: { sortOrder: 'asc' },
        },
      },
    })

    if (!course) {
      return NextResponse.json({ success: false, message: 'Course not found' }, { status: 404 })
    }

    // Get lesson progress for this student in this course
    const progress = await db.lessonProgress.findMany({
      where: { studentId: student.id, courseId: id },
      select: {
        lessonId: true,
        status: true,
        completedAt: true,
      },
    })

    // Build progress map
    const progressMap: Record<string, { status: string; completedAt: string | null }> = {}
    for (const p of progress) {
      progressMap[p.lessonId] = { status: p.status, completedAt: p.completedAt?.toISOString() || null }
    }

    // Calculate stats
    const allLessons = course.modules.flatMap(m => m.lessons)
    const totalLessons = allLessons.length
    const completedLessons = allLessons.filter(l => progressMap[l.id]?.status === 'completed').length
    const totalDuration = allLessons.reduce((sum, l) => sum + (l.videoDuration || 0), 0)

    return NextResponse.json({
      success: true,
      course,
      purchase: {
        id: purchase.id,
        purchasedAt: purchase.purchasedAt,
        expiresAt: purchase.expiresAt,
      },
      progress: progressMap,
      stats: {
        totalLessons,
        completedLessons,
        totalDuration,
        progressPercent: totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0,
      },
    })
  } catch (error) {
    console.error('Student course detail error:', error)
    return NextResponse.json({ success: false, message: 'Something went wrong' }, { status: 500 })
  }
}
