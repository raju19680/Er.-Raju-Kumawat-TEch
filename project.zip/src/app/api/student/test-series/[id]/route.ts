import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth-helpers'

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const auth = await getAuthUser(req)
    if (!auth) {
      return NextResponse.json({ success: false, message: 'Authentication required' }, { status: 401 })
    }

    if (auth.role !== 'student') {
      return NextResponse.json({ success: false, message: 'Access denied' }, { status: 403 })
    }

    const { id } = await params

    const student = await db.student.findFirst({
      where: { userId: auth.id },
    })
    if (!student) {
      return NextResponse.json({ success: false, message: 'Student profile not found' }, { status: 404 })
    }

    const testSeries = await db.testSeries.findFirst({
      where: { id, organizationId: auth.orgId },
      select: {
        id: true,
        title: true,
        description: true,
        thumbnail: true,
        price: true,
        mrp: true,
        category: true,
        isCombo: true,
        status: true,
        tests: {
          select: {
            id: true,
            title: true,
            totalDuration: true,
            numberOfQuestions: true,
            totalMarks: true,
            isLive: true,
            isLocked: true,
            maxAttempts: true,
            negativeMarks: true,
            sortOrder: true,
            testAttempts: {
              where: { studentId: student.id },
              select: {
                id: true,
                score: true,
                totalMarks: true,
                status: true,
                startedAt: true,
                completedAt: true,
              },
              orderBy: { startedAt: 'desc' },
            },
          },
          orderBy: { sortOrder: 'asc' },
        },
      },
    })

    if (!testSeries) {
      return NextResponse.json({ success: false, message: 'Test series not found' }, { status: 404 })
    }

    // Check purchase status via PurchasedTestSeries table
    const purchasedRecord = await db.purchasedTestSeries.findUnique({
      where: {
        studentId_testSeriesId: {
          studentId: student.id,
          testSeriesId: testSeries.id,
        },
      },
    })
    let purchased = !!purchasedRecord || testSeries.price === 0

    // Also check completed orders as fallback
    if (!purchased) {
      const completedOrders = await db.order.findMany({
        where: {
          studentId: student.id,
          status: 'completed',
        },
        select: { items: true },
      })

      for (const order of completedOrders) {
        try {
          const items = JSON.parse(order.items)
          if (Array.isArray(items)) {
            for (const item of items) {
              if (item.itemType === 'test_series' && item.itemId === testSeries.id) {
                purchased = true
                break
              }
            }
          }
        } catch {
          // ignore
        }
        if (purchased) break
      }
    }

    const formattedTests = testSeries.tests.map((test) => ({
      id: test.id,
      title: test.title,
      totalDuration: test.totalDuration,
      numberOfQuestions: test.numberOfQuestions,
      totalMarks: test.totalMarks,
      isLive: test.isLive,
      isLocked: test.isLocked,
      maxAttempts: test.maxAttempts,
      negativeMarks: test.negativeMarks,
      attemptCount: test.testAttempts.length,
      attempts: test.testAttempts,
      canAttempt: test.isLive && !test.isLocked && purchased && test.testAttempts.filter(a => a.status === 'completed').length < test.maxAttempts,
    }))

    return NextResponse.json({
      success: true,
      testSeries: {
        id: testSeries.id,
        title: testSeries.title,
        description: testSeries.description,
        thumbnail: testSeries.thumbnail,
        price: testSeries.price,
        mrp: testSeries.mrp,
        category: testSeries.category,
        isCombo: testSeries.isCombo,
        status: testSeries.status,
        purchased,
        tests: formattedTests,
      },
    })
  } catch (error) {
    console.error('Student test-series detail error:', error)
    return NextResponse.json({ success: false, message: 'Something went wrong' }, { status: 500 })
  }
}
