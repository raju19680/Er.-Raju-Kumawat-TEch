import { NextRequest, NextResponse } from 'next/server'
import { hash } from 'bcryptjs'
import { db } from '@/lib/db'
import { validatePasswordStrength, sanitizeEmail, sanitizeInput } from '@/lib/auth-security'
import { checkRateLimit, getClientIp } from '@/lib/rate-limit'
import { getAuthUser } from '@/lib/auth-helpers'

/**
 * Create a new user account.
 * SECURITY: Only authenticated platform_admin or teacher can create accounts.
 * Public registration is DISABLED — admins/teachers create accounts for students.
 * Only 3 roles exist: platform_admin, teacher, student
 */
export async function POST(req: NextRequest) {
  try {
    // ── Auth check: Must be logged in as admin/teacher ──
    const authUser = await getAuthUser(req)
    if (!authUser) {
      return NextResponse.json(
        { success: false, message: 'Authentication required. Only admins can create accounts.' },
        { status: 401 }
      )
    }

    const isPlatformAdmin = authUser.role === 'platform_admin'
    const isTeacher = authUser.role === 'teacher'

    if (!isPlatformAdmin && !isTeacher) {
      return NextResponse.json(
        { success: false, message: 'Access denied. Only platform admin or teachers can create accounts.' },
        { status: 403 }
      )
    }

    // ── Rate limiting ──
    const clientIp = getClientIp(req.headers)
    const rateLimitResult = checkRateLimit(`register:${clientIp}`)

    if (!rateLimitResult.allowed) {
      return NextResponse.json(
        {
          success: false,
          message: 'Too many attempts. Please try again later.',
          retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
        },
        {
          status: 429,
          headers: {
            'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          },
        }
      )
    }

    const { name, email, password, orgCode, role } = await req.json()

    // ── Input validation ──
    if (!name || !email || !password) {
      return NextResponse.json(
        { success: false, message: 'Name, email and password are required' },
        { status: 400 }
      )
    }

    // ── Role restriction ──
    // Only 3 roles: platform_admin, teacher, student
    // Platform admin can create teacher & student
    // Teacher can only create student accounts
    const allowedRoles = isPlatformAdmin
      ? ['teacher', 'student']
      : ['student']

    if (role && !allowedRoles.includes(role)) {
      return NextResponse.json(
        { success: false, message: `You can only create ${allowedRoles.join(' or ')} accounts.` },
        { status: 403 }
      )
    }

    // Sanitize inputs
    const sanitizedName = sanitizeInput(name)
    const sanitizedEmail = sanitizeEmail(email)

    // ── Password strength check ──
    const strength = validatePasswordStrength(password)
    if (strength.score < 2) {
      return NextResponse.json(
        {
          success: false,
          message: 'Password is too weak. Please choose a stronger password.',
          passwordStrength: {
            score: strength.score,
            label: strength.label,
            feedback: strength.feedback,
          },
        },
        { status: 400 }
      )
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email: sanitizedEmail },
    })

    if (existingUser) {
      return NextResponse.json(
        { success: false, message: 'An account with this email already exists' },
        { status: 409 }
      )
    }

    // Determine organization
    let organizationId: string | null = null

    if (isPlatformAdmin && orgCode) {
      // Platform admin can specify any org
      const org = await db.organization.findUnique({
        where: { code: orgCode },
      })
      if (!org) {
        return NextResponse.json(
          { success: false, message: 'Organization not found' },
          { status: 404 }
        )
      }
      organizationId = org.id
    } else if (isTeacher) {
      // Teacher can only create users in their own org
      organizationId = authUser.orgId
    }

    if (!organizationId) {
      return NextResponse.json(
        { success: false, message: 'Organization is required. Please specify an organization.' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await hash(password, 12)

    // Create user
    const user = await db.user.create({
      data: {
        name: sanitizedName,
        email: sanitizedEmail,
        password: hashedPassword,
        role: role || 'student',
        organizationId: organizationId,
        failedLoginAttempts: 0,
        lockedUntil: null,
        passwordChangedAt: new Date(),
      },
    })

    // ── Send welcome email (fire and forget) ──
    ;(async () => {
      try {
        const org = await db.organization.findUnique({
          where: { id: organizationId! },
          select: { name: true, code: true },
        })
        if (org) {
          const { sendWelcomeEmail } = await import('@/lib/email')
          sendWelcomeEmail(
            sanitizedEmail,
            sanitizedName,
            org.name,
            org.code,
            organizationId || undefined
          )
        }
      } catch (emailErr) {
        console.log('[REGISTER] Welcome email failed:', emailErr)
      }
    })()

    return NextResponse.json({
      success: true,
      message: 'Account created successfully',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    })
  } catch (error) {
    console.error('Register error:', error)
    return NextResponse.json(
      { success: false, message: 'Internal server error' },
      { status: 500 }
    )
  }
}
