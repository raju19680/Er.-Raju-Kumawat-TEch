import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { checkModuleAccess } from '@/lib/module-guard'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const access = await checkModuleAccess(request, 'tests')
    if (!access.allowed) {
      return NextResponse.json({ error: access.error }, { status: access.status })
    }

    const { id } = await params
    const test = await db.test.findUnique({
      where: { id },
      include: {
        testSeries: { select: { id: true, title: true } },
        questions: { orderBy: { sortOrder: 'asc' } },
        _count: { select: { questions: true, testAttempts: true } },
      },
    })
    if (!test) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }
    return NextResponse.json(test)
  } catch (error) {
    console.error('Failed to fetch test:', error)
    return NextResponse.json({ error: 'Failed to fetch test' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const access = await checkModuleAccess(request, 'tests')
    if (!access.allowed) {
      return NextResponse.json({ error: access.error }, { status: access.status })
    }

    const { id } = await params
    const body = await request.json()

    const test = await db.test.update({
      where: { id },
      data: {
        title: body.title,
        instructions: body.instructions,
        status: body.status,
        isLive: body.isLive,
        isLocked: body.isLocked,
        numberOfQuestions: body.numberOfQuestions,
        totalMarks: body.totalMarks,
        totalDuration: body.totalDuration,
        sortOrder: body.sortOrder,
        negativeMarks: body.negativeMarks,
        isPdfTest: body.isPdfTest,
        pdfUrl: body.pdfUrl,
        isSubjective: body.isSubjective,
      },
    })

    return NextResponse.json(test)
  } catch (error) {
    console.error('Failed to update test:', error)
    return NextResponse.json({ error: 'Failed to update test' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const access = await checkModuleAccess(request, 'tests')
    if (!access.allowed) {
      return NextResponse.json({ error: access.error }, { status: access.status })
    }

    const { id } = await params
    // Delete related questions first
    await db.question.deleteMany({ where: { testId: id } })
    await db.test.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Failed to delete test:', error)
    return NextResponse.json({ error: 'Failed to delete test' }, { status: 500 })
  }
}
