import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getDemoOrgId } from '@/lib/demo-org'
import { checkModuleAccess } from '@/lib/module-guard'

export async function GET(request: NextRequest) {
  try {
    const access = await checkModuleAccess(request, 'dashboard')
    if (!access.allowed) {
      return NextResponse.json({ error: access.error }, { status: access.status })
    }

    const orgId = await getDemoOrgId(request)
    const now = new Date()

    // ── Core counts ──────────────────────────────────────────────
    const [
      totalStudents,
      totalTests,
      totalTestSeries,
      totalQuestions,
      totalRevenue,
      totalTestAttempts,
      totalCourses,
      totalBlogs,
      totalOrders,
    ] = await Promise.all([
      db.student.count({ where: { organizationId: orgId } }),
      db.test.count({ where: { organizationId: orgId } }),
      db.testSeries.count({ where: { organizationId: orgId } }),
      db.question.count(),
      db.payment.aggregate({ where: { organizationId: orgId, status: 'success' }, _sum: { amount: true } }),
      db.testAttempt.count({ where: { status: 'completed' } }),
      db.course.count({ where: { organizationId: orgId } }),
      db.blog.count({ where: { organizationId: orgId } }),
      db.order.count({ where: { organizationId: orgId, status: 'completed' } }),
    ])

    // ── Monthly revenue for chart (last 12 months) ───────────────
    const payments = await db.payment.findMany({
      where: { organizationId: orgId, status: 'success' },
      select: { amount: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    })

    const monthlyRevenue: { month: string; revenue: number }[] = []
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0)
      const monthPayments = payments.filter(p => {
        const pd = new Date(p.createdAt)
        return pd >= d && pd <= monthEnd
      })
      monthlyRevenue.push({
        month: d.toLocaleDateString('en-US', { month: 'short' }),
        revenue: monthPayments.reduce((s, p) => s + p.amount, 0),
      })
    }

    // ── Monthly signups for chart ────────────────────────────────
    const students = await db.student.findMany({
      where: { organizationId: orgId },
      select: { createdAt: true },
      orderBy: { createdAt: 'asc' },
    })

    const monthlySignups: { month: string; count: number }[] = []
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0)
      const count = students.filter(s => {
        const sd = new Date(s.createdAt)
        return sd >= d && sd <= monthEnd
      }).length
      monthlySignups.push({
        month: d.toLocaleDateString('en-US', { month: 'short' }),
        count,
      })
    }

    // ── Monthly test attempts for chart ──────────────────────────
    const attempts = await db.testAttempt.findMany({
      where: { status: 'completed' },
      select: { completedAt: true, startedAt: true },
      orderBy: { completedAt: 'asc' },
    })

    const monthlyAttempts: { month: string; count: number }[] = []
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0)
      const count = attempts.filter(a => {
        const ad = new Date(a.completedAt || a.startedAt)
        return ad >= d && ad <= monthEnd
      }).length
      monthlyAttempts.push({
        month: d.toLocaleDateString('en-US', { month: 'short' }),
        count,
      })
    }

    // ── Recent activity (last 10 events) ─────────────────────────
    const [recentOrders, recentStudents, recentAttempts] = await Promise.all([
      db.order.findMany({
        where: { organizationId: orgId, status: 'completed' },
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: { student: { select: { name: true } } },
      }),
      db.student.findMany({
        where: { organizationId: orgId },
        orderBy: { createdAt: 'desc' },
        take: 5,
        select: { id: true, name: true, email: true, createdAt: true },
      }),
      db.testAttempt.findMany({
        where: { status: 'completed' },
        orderBy: { completedAt: 'desc' },
        take: 5,
        include: {
          student: { select: { name: true } },
          test: { select: { title: true } },
        },
      }),
    ])

    const recentActivity = [
      ...recentOrders.map(o => ({
        type: 'order' as const,
        title: `New order by ${o.student?.name || 'Unknown'}`,
        description: `₹${o.finalAmount} purchase`,
        time: o.createdAt,
      })),
      ...recentStudents.map(s => ({
        type: 'signup' as const,
        title: `${s.name} signed up`,
        description: s.email,
        time: s.createdAt,
      })),
      ...recentAttempts.map(a => ({
        type: 'attempt' as const,
        title: `${a.student?.name || 'Student'} completed ${a.test?.title || 'a test'}`,
        description: `Score: ${a.score}/${a.totalMarks}`,
        time: a.completedAt || a.startedAt,
      })),
    ]
      .sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime())
      .slice(0, 10)

    // ── Change calculations (compare this month vs last month) ───
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1)
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1)

    const [thisMonthStudents, lastMonthStudents] = await Promise.all([
      db.student.count({ where: { organizationId: orgId, createdAt: { gte: thisMonthStart } } }),
      db.student.count({ where: { organizationId: orgId, createdAt: { gte: lastMonthStart, lt: thisMonthStart } } }),
    ])

    const signupsChange = lastMonthStudents > 0
      ? Math.round(((thisMonthStudents - lastMonthStudents) / lastMonthStudents) * 100)
      : thisMonthStudents > 0 ? 100 : 0

    const thisMonthRevenue = payments
      .filter(p => new Date(p.createdAt) >= thisMonthStart)
      .reduce((s, p) => s + p.amount, 0)
    const lastMonthRevenue = payments
      .filter(p => { const pd = new Date(p.createdAt); return pd >= lastMonthStart && pd < thisMonthStart })
      .reduce((s, p) => s + p.amount, 0)
    const revenueChange = lastMonthRevenue > 0
      ? Math.round(((thisMonthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100)
      : thisMonthRevenue > 0 ? 100 : 0

    const stats = {
      totalStudents,
      totalStudentsChange: signupsChange,
      activeTests: await db.test.count({ where: { organizationId: orgId, isLive: true } }),
      activeTestsChange: (async () => {
        const now2 = new Date()
        const tmStart = new Date(now2.getFullYear(), now2.getMonth(), 1)
        const lmStart = new Date(now2.getFullYear(), now2.getMonth() - 1, 1)
        const lmEnd = new Date(now2.getFullYear(), now2.getMonth(), 0, 23, 59, 59, 999)
        const [tm, lm] = await Promise.all([
          db.test.count({ where: { organizationId: orgId, isLive: true, createdAt: { gte: tmStart } } }),
          db.test.count({ where: { organizationId: orgId, isLive: true, createdAt: { gte: lmStart, lte: lmEnd } } }),
        ])
        return lm > 0 ? Math.round(((tm - lm) / lm) * 100) : tm > 0 ? 100 : 0
      })(),
      revenue: totalRevenue._sum.amount || 0,
      revenueChange,
      completionRate: totalTestAttempts > 0 ? Math.round((totalTestAttempts / (totalTestAttempts + 100)) * 100) : 0,
      completionRateChange: 0,
    }

    return NextResponse.json({
      stats,
      counts: {
        totalTestSeries,
        totalTests,
        totalQuestions,
        totalStudents,
        totalCourses,
        totalBlogs,
        totalOrders,
      },
      charts: {
        monthlyRevenue,
        monthlySignups,
        monthlyAttempts,
      },
      recentActivity,
    })
  } catch (error) {
    console.error('Failed to fetch dashboard:', error)
    return NextResponse.json({ error: 'Failed to fetch dashboard' }, { status: 500 })
  }
}
