import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { checkModuleAccess } from '@/lib/module-guard'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
  try {
    const access = await checkModuleAccess(request, 'courses')
    if (!access.allowed) {
      return NextResponse.json({ error: access.error }, { status: access.status })
    }

    const { moduleId } = await params
    const lessons = await db.courseLesson.findMany({
      where: { moduleId },
      orderBy: { sortOrder: 'asc' },
    })
    return NextResponse.json({ lessons })
  } catch (error) {
    console.error('Failed to fetch lessons:', error)
    return NextResponse.json({ error: 'Failed to fetch lessons' }, { status: 500 })
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
  try {
    const access = await checkModuleAccess(request, 'courses')
    if (!access.allowed) {
      return NextResponse.json({ error: access.error }, { status: access.status })
    }

    const { moduleId } = await params
    const body = await request.json()

    if (!body.title) {
      return NextResponse.json({ error: 'Lesson title is required' }, { status: 400 })
    }

    // Verify module exists
    const existingModule = await db.courseModule.findUnique({ where: { id: moduleId } })
    if (!existingModule) {
      return NextResponse.json({ error: 'Module not found' }, { status: 404 })
    }

    // Get current max sortOrder
    const maxSort = await db.courseLesson.findFirst({
      where: { moduleId },
      orderBy: { sortOrder: 'desc' },
      select: { sortOrder: true },
    })

    const lesson = await db.courseLesson.create({
      data: {
        title: body.title,
        type: body.type || 'video',
        content: body.content || null,
        videoUrl: body.videoUrl || null,
        videoDuration: body.videoDuration || 0,
        fileUrl: body.fileUrl || null,
        notes: body.notes || null,
        isFree: body.isFree ?? false,
        sortOrder: body.sortOrder ?? (maxSort?.sortOrder ?? -1) + 1,
        moduleId,
      },
    })

    return NextResponse.json({ success: true, lesson }, { status: 201 })
  } catch (error) {
    console.error('Failed to create lesson:', error)
    return NextResponse.json({ error: 'Failed to create lesson' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
  try {
    const access = await checkModuleAccess(request, 'courses')
    if (!access.allowed) {
      return NextResponse.json({ error: access.error }, { status: access.status })
    }

    const { moduleId: _moduleId } = await params
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Lesson ID is required' }, { status: 400 })
    }

    const existing = await db.courseLesson.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Lesson not found' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}
    if (body.title !== undefined) data.title = body.title
    if (body.type !== undefined) data.type = body.type
    if (body.content !== undefined) data.content = body.content
    if (body.videoUrl !== undefined) data.videoUrl = body.videoUrl
    if (body.videoDuration !== undefined) data.videoDuration = body.videoDuration
    if (body.fileUrl !== undefined) data.fileUrl = body.fileUrl
    if (body.notes !== undefined) data.notes = body.notes
    if (body.isFree !== undefined) data.isFree = body.isFree
    if (body.sortOrder !== undefined) data.sortOrder = body.sortOrder

    const lesson = await db.courseLesson.update({
      where: { id: body.id },
      data,
    })

    return NextResponse.json({ success: true, lesson })
  } catch (error) {
    console.error('Failed to update lesson:', error)
    return NextResponse.json({ error: 'Failed to update lesson' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
  try {
    const access = await checkModuleAccess(request, 'courses')
    if (!access.allowed) {
      return NextResponse.json({ error: access.error }, { status: access.status })
    }

    const lessonId = request.nextUrl.searchParams.get('id')
    if (!lessonId) {
      return NextResponse.json({ error: 'Lesson ID is required' }, { status: 400 })
    }

    const existing = await db.courseLesson.findUnique({ where: { id: lessonId } })
    if (!existing) {
      return NextResponse.json({ error: 'Lesson not found' }, { status: 404 })
    }

    await db.courseLesson.delete({ where: { id: lessonId } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Failed to delete lesson:', error)
    return NextResponse.json({ error: 'Failed to delete lesson' }, { status: 500 })
  }
}
