import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { checkModuleAccess } from '@/lib/module-guard'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const access = await checkModuleAccess(request, 'courses')
    if (!access.allowed) {
      return NextResponse.json({ error: access.error }, { status: access.status })
    }

    const { id } = await params
    const course = await db.course.findUnique({
      where: { id },
      include: {
        _count: { select: { purchasedBy: true } },
        modules: {
          orderBy: { sortOrder: 'asc' },
          include: {
            lessons: { orderBy: { sortOrder: 'asc' } },
          },
        },
      },
    })

    if (!course) {
      return NextResponse.json({ error: 'Course not found' }, { status: 404 })
    }

    const { _count, modules, ...courseData } = course
    const totalLessons = modules.reduce(
      (sum, m) => sum + m.lessons.length, 0
    )
    const totalDuration = modules.reduce(
      (sum, m) => sum + m.lessons.reduce((s, l) => s + (l.videoDuration || 0), 0), 0
    )

    return NextResponse.json({
      ...courseData,
      purchaseCount: _count.purchasedBy,
      moduleCount: modules.length,
      totalLessons,
      totalDuration,
      modules,
    })
  } catch (error) {
    console.error('Failed to fetch course:', error)
    return NextResponse.json({ error: 'Failed to fetch course' }, { status: 500 })
  }
}
