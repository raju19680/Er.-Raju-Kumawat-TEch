import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requirePlatformAdmin } from '@/lib/auth-helpers'

/**
 * GET /api/admin/student-mgmt
 * Fetch student attendance records, notes, and communication history.
 * Only accessible by platform_admin.
 *
 * Query params:
 *   organizationId — filter by organization
 *   date           — specific date for attendance (YYYY-MM-DD)
 *   studentId      — filter by specific student
 *   type           — "attendance" | "notes" | "communications"
 */
export async function GET(req: NextRequest) {
  try {
    // ── Auth check ──
    const authResult = await requirePlatformAdmin(req)
    if ('error' in authResult) {
      return NextResponse.json(
        { success: false, message: authResult.error },
        { status: authResult.status }
      )
    }

    const { searchParams } = new URL(req.url)
    const organizationId = searchParams.get('organizationId')?.trim() || ''
    const dateStr = searchParams.get('date')?.trim() || ''
    const studentId = searchParams.get('studentId')?.trim() || ''
    const type = searchParams.get('type')?.trim() || 'attendance'

    // ── Build common student filter ──
    const studentWhere: any = {}
    if (organizationId) {
      studentWhere.organizationId = organizationId
    }
    if (studentId) {
      studentWhere.id = studentId
    }

    // ── Parse date for attendance ──
    let attendanceDate: Date | undefined
    if (dateStr) {
      const parsed = new Date(dateStr)
      if (!isNaN(parsed.getTime())) {
        attendanceDate = parsed
      }
    }
    if (!attendanceDate) {
      attendanceDate = new Date()
      attendanceDate.setHours(0, 0, 0, 0)
    }

    // ── Attendance data ──
    if (type === 'attendance') {
      // Get attendance records for the date
      const nextDay = new Date(attendanceDate)
      nextDay.setDate(nextDay.getDate() + 1)

      const attendanceWhere: any = {
        date: {
          gte: attendanceDate,
          lt: nextDay,
        },
      }
      if (organizationId) {
        attendanceWhere.organizationId = organizationId
      }
      if (studentId) {
        attendanceWhere.studentId = studentId
      }

      const [records, students, presentCount, absentCount, lateCount, excusedCount] =
        await Promise.all([
          db.studentAttendance.findMany({
            where: attendanceWhere,
            orderBy: { createdAt: 'desc' },
          }),
          db.student.findMany({
            where: studentWhere,
            select: {
              id: true,
              name: true,
              email: true,
              phone: true,
              organizationId: true,
              organization: {
                select: { id: true, name: true },
              },
            },
            orderBy: { name: 'asc' },
          }),
          db.studentAttendance.count({
            where: { ...attendanceWhere, status: 'present' },
          }),
          db.studentAttendance.count({
            where: { ...attendanceWhere, status: 'absent' },
          }),
          db.studentAttendance.count({
            where: { ...attendanceWhere, status: 'late' },
          }),
          db.studentAttendance.count({
            where: { ...attendanceWhere, status: 'excused' },
          }),
        ])

      // Build student map for quick lookup
      const studentMap = new Map(students.map((s) => [s.id, s]))

      // Format attendance records with student info
      const formattedRecords = records.map((r) => ({
        id: r.id,
        studentId: r.studentId,
        student: studentMap.get(r.studentId) || null,
        date: r.date,
        status: r.status,
        notes: r.notes,
        markedBy: r.markedBy,
        markedByName: r.markedByName,
        createdAt: r.createdAt,
      }))

      // Build student attendance map (studentId -> status)
      const attendanceMap = new Map(records.map((r) => [r.studentId, r.status]))

      // Build full student list with attendance status
      const studentList = students.map((s) => ({
        ...s,
        attendanceStatus: attendanceMap.get(s.id) || null,
        attendanceId: records.find((r) => r.studentId === s.id)?.id || null,
        attendanceNotes: records.find((r) => r.studentId === s.id)?.notes || null,
      }))

      const totalStudents = students.length
      const totalMarked = records.length
      const attendanceRate = totalStudents > 0
        ? Math.round((presentCount / Math.max(totalMarked, 1)) * 100)
        : 0

      // ── Fetch organizations for filter ──
      const organizations = await db.organization.findMany({
        select: { id: true, name: true, code: true },
        orderBy: { name: 'asc' },
      })

      return NextResponse.json({
        success: true,
        type: 'attendance',
        data: {
          date: attendanceDate.toISOString(),
          students: studentList,
          records: formattedRecords,
          summary: {
            totalStudents,
            totalMarked,
            present: presentCount,
            absent: absentCount,
            late: lateCount,
            excused: excusedCount,
            attendanceRate,
          },
          organizations,
        },
      })
    }

    // ── Notes data ──
    if (type === 'notes') {
      const notesWhere: any = {}
      if (studentId) {
        notesWhere.studentId = studentId
      }
      if (organizationId) {
        // Need to filter by student's organization
        notesWhere.student = { organizationId }
      }

      const [notes, students] = await Promise.all([
        db.studentNote.findMany({
          where: notesWhere,
          orderBy: [{ isPinned: 'desc' }, { createdAt: 'desc' }],
          take: 100,
        }),
        db.student.findMany({
          where: studentWhere,
          select: {
            id: true,
            name: true,
            email: true,
            organizationId: true,
            organization: {
              select: { id: true, name: true },
            },
          },
          orderBy: { name: 'asc' },
        }),
      ])

      // Build student map
      const studentMap = new Map(students.map((s) => [s.id, s]))

      const formattedNotes = notes.map((n) => ({
        id: n.id,
        studentId: n.studentId,
        student: studentMap.get(n.studentId) || null,
        note: n.note,
        category: n.category,
        priority: n.priority,
        createdBy: n.createdBy,
        createdByName: n.createdByName,
        isPinned: n.isPinned,
        createdAt: n.createdAt,
        updatedAt: n.updatedAt,
      }))

      return NextResponse.json({
        success: true,
        type: 'notes',
        data: {
          notes: formattedNotes,
          students,
        },
      })
    }

    // ── Communications data ──
    if (type === 'communications') {
      const commWhere: any = {}
      if (studentId) {
        commWhere.studentId = studentId
      }
      if (organizationId) {
        commWhere.organizationId = organizationId
      }

      const [communications, students] = await Promise.all([
        db.studentCommunication.findMany({
          where: commWhere,
          orderBy: { createdAt: 'desc' },
          take: 100,
        }),
        db.student.findMany({
          where: studentWhere,
          select: {
            id: true,
            name: true,
            email: true,
            organizationId: true,
            organization: {
              select: { id: true, name: true },
            },
          },
          orderBy: { name: 'asc' },
        }),
      ])

      // Build student map
      const studentMap = new Map(students.map((s) => [s.id, s]))

      const formattedComms = communications.map((c) => ({
        id: c.id,
        studentId: c.studentId,
        student: studentMap.get(c.studentId) || null,
        type: c.type,
        subject: c.subject,
        message: c.message,
        status: c.status,
        sentBy: c.sentBy,
        sentByName: c.sentByName,
        sentAt: c.sentAt,
        createdAt: c.createdAt,
      }))

      return NextResponse.json({
        success: true,
        type: 'communications',
        data: {
          communications: formattedComms,
          students,
        },
      })
    }

    return NextResponse.json(
      { success: false, message: 'Invalid type parameter. Use: attendance, notes, or communications' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Student management GET error:', error)
    return NextResponse.json(
      { success: false, message: 'Internal server error. Please try again.' },
      { status: 500 }
    )
  }
}

/**
 * POST /api/admin/student-mgmt
 * Mark attendance, add note, or send communication.
 * Only accessible by platform_admin.
 *
 * Body: { action: 'mark_attendance' | 'add_note' | 'send_communication', ...data }
 */
export async function POST(req: NextRequest) {
  try {
    // ── Auth check ──
    const authResult = await requirePlatformAdmin(req)
    if ('error' in authResult) {
      return NextResponse.json(
        { success: false, message: authResult.error },
        { status: authResult.status }
      )
    }

    const auth = authResult.user
    const body = await req.json()
    const { action } = body

    // ── Mark Attendance ──
    if (action === 'mark_attendance') {
      const { studentIds, date, status, organizationId, notes } = body

      if (!studentIds || !Array.isArray(studentIds) || studentIds.length === 0) {
        return NextResponse.json(
          { success: false, message: 'studentIds array is required.' },
          { status: 400 }
        )
      }

      if (!status || !['present', 'absent', 'late', 'excused'].includes(status)) {
        return NextResponse.json(
          { success: false, message: 'Valid status is required: present, absent, late, or excused.' },
          { status: 400 }
        )
      }

      if (!organizationId) {
        return NextResponse.json(
          { success: false, message: 'organizationId is required.' },
          { status: 400 }
        )
      }

      // Parse date
      let attendanceDate: string
      if (date) {
        const parsed = new Date(date)
        if (isNaN(parsed.getTime())) {
          return NextResponse.json(
            { success: false, message: 'Invalid date format.' },
            { status: 400 }
          )
        }
        attendanceDate = parsed.toISOString().split('T')[0]
      } else {
        const now = new Date()
        now.setHours(0, 0, 0, 0)
        attendanceDate = now.toISOString().split('T')[0]
      }

      // Verify students belong to the organization
      const students = await db.student.findMany({
        where: {
          id: { in: studentIds },
          organizationId,
        },
        select: { id: true },
      })

      const validStudentIds = students.map((s) => s.id)
      if (validStudentIds.length === 0) {
        return NextResponse.json(
          { success: false, message: 'No valid students found for the given organization.' },
          { status: 404 }
        )
      }

      // Upsert attendance records (one per student per day)
      const results: unknown[] = []
      for (const sid of validStudentIds) {
        const record = await db.studentAttendance.upsert({
          where: {
            studentId_date: {
              studentId: sid,
              date: attendanceDate,
            },
          },
          update: {
            status,
            notes: notes || null,
            markedBy: auth.id,
            markedByName: auth.name,
          },
          create: {
            studentId: sid,
            organizationId,
            date: attendanceDate,
            status,
            notes: notes || null,
            markedBy: auth.id,
            markedByName: auth.name,
          },
        })
        results.push(record)
      }

      return NextResponse.json({
        success: true,
        message: `Attendance marked for ${results.length} student(s).`,
        data: { updated: results.length },
      })
    }

    // ── Add Note ──
    if (action === 'add_note') {
      const { studentId, note, category, priority } = body

      if (!studentId) {
        return NextResponse.json(
          { success: false, message: 'studentId is required.' },
          { status: 400 }
        )
      }

      if (!note || !note.trim()) {
        return NextResponse.json(
          { success: false, message: 'Note text is required.' },
          { status: 400 }
        )
      }

      // Verify student exists
      const student = await db.student.findUnique({
        where: { id: studentId },
        select: { id: true, name: true, organizationId: true },
      })

      if (!student) {
        return NextResponse.json(
          { success: false, message: 'Student not found.' },
          { status: 404 }
        )
      }

      const validCategories = ['general', 'academic', 'behavioral', 'financial', 'communication']
      const validPriorities = ['normal', 'important', 'urgent']

      const studentNote = await db.studentNote.create({
        data: {
          studentId,
          organizationId: student.organizationId,
          note: note.trim(),
          category: validCategories.includes(category) ? category : 'general',
          priority: validPriorities.includes(priority) ? priority : 'normal',
          createdBy: auth.id,
          createdByName: auth.name,
        },
      })

      return NextResponse.json({
        success: true,
        message: 'Note added successfully.',
        data: studentNote,
      })
    }

    // ── Send Communication ──
    if (action === 'send_communication') {
      const { studentId, type: commType, subject, message, organizationId } = body

      if (!studentId) {
        return NextResponse.json(
          { success: false, message: 'studentId is required.' },
          { status: 400 }
        )
      }

      if (!message || !message.trim()) {
        return NextResponse.json(
          { success: false, message: 'Message text is required.' },
          { status: 400 }
        )
      }

      if (!organizationId) {
        return NextResponse.json(
          { success: false, message: 'organizationId is required.' },
          { status: 400 }
        )
      }

      // Verify student exists
      const student = await db.student.findUnique({
        where: { id: studentId },
        select: { id: true, name: true, email: true },
      })

      if (!student) {
        return NextResponse.json(
          { success: false, message: 'Student not found.' },
          { status: 404 }
        )
      }

      const validTypes = ['email', 'sms', 'whatsapp', 'push']

      const communication = await db.studentCommunication.create({
        data: {
          studentId,
          organizationId,
          type: validTypes.includes(commType) ? commType : 'email',
          subject: subject?.trim() || null,
          message: message.trim(),
          status: 'sent',
          sentBy: auth.id,
          sentByName: auth.name,
          sentAt: new Date(),
        },
      })

      // Try to actually send email if type is email
      if (commType === 'email' && student.email) {
        try {
          const { sendEmail } = await import('@/lib/email')
          await sendEmail({
            to: student.email,
            subject: subject?.trim() || 'Message from Admin',
            body: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
              <p>Hello ${student.name},</p>
              <p>${message.trim()}</p>
              <br/>
              <p style="color: #999; font-size: 12px;">This message was sent via the admin portal.</p>
            </div>`,
            type: 'notification',
          })
        } catch (emailErr) {
          console.error('Failed to send email:', emailErr)
          // Update status to failed but don't block the response
          await db.studentCommunication.update({
            where: { id: communication.id },
            data: { status: 'failed' },
          })
        }
      }

      return NextResponse.json({
        success: true,
        message: 'Communication sent successfully.',
        data: communication,
      })
    }

    return NextResponse.json(
      { success: false, message: 'Invalid action. Use: mark_attendance, add_note, or send_communication' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Student management POST error:', error)
    return NextResponse.json(
      { success: false, message: 'Internal server error. Please try again.' },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/admin/student-mgmt
 * Update a note (pin/unpin) or update communication status.
 */
export async function PUT(req: NextRequest) {
  try {
    const authResult = await requirePlatformAdmin(req)
    if ('error' in authResult) {
      return NextResponse.json(
        { success: false, message: authResult.error },
        { status: authResult.status }
      )
    }

    const body = await req.json()
    const { action } = body

    // ── Toggle Pin Note ──
    if (action === 'toggle_pin_note') {
      const { noteId } = body
      if (!noteId) {
        return NextResponse.json(
          { success: false, message: 'noteId is required.' },
          { status: 400 }
        )
      }

      const note = await db.studentNote.findUnique({ where: { id: noteId } })
      if (!note) {
        return NextResponse.json(
          { success: false, message: 'Note not found.' },
          { status: 404 }
        )
      }

      const updated = await db.studentNote.update({
        where: { id: noteId },
        data: { isPinned: !note.isPinned },
      })

      return NextResponse.json({
        success: true,
        message: updated.isPinned ? 'Note pinned.' : 'Note unpinned.',
        data: updated,
      })
    }

    return NextResponse.json(
      { success: false, message: 'Invalid action.' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Student management PUT error:', error)
    return NextResponse.json(
      { success: false, message: 'Internal server error. Please try again.' },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/admin/student-mgmt
 * Delete a note.
 */
export async function DELETE(req: NextRequest) {
  try {
    const authResult = await requirePlatformAdmin(req)
    if ('error' in authResult) {
      return NextResponse.json(
        { success: false, message: authResult.error },
        { status: authResult.status }
      )
    }

    const { searchParams } = new URL(req.url)
    const noteId = searchParams.get('noteId')?.trim() || ''

    if (!noteId) {
      return NextResponse.json(
        { success: false, message: 'noteId is required.' },
        { status: 400 }
      )
    }

    const note = await db.studentNote.findUnique({ where: { id: noteId } })
    if (!note) {
      return NextResponse.json(
        { success: false, message: 'Note not found.' },
        { status: 404 }
      )
    }

    await db.studentNote.delete({ where: { id: noteId } })

    return NextResponse.json({
      success: true,
      message: 'Note deleted successfully.',
    })
  } catch (error) {
    console.error('Student management DELETE error:', error)
    return NextResponse.json(
      { success: false, message: 'Internal server error. Please try again.' },
      { status: 500 }
    )
  }
}
