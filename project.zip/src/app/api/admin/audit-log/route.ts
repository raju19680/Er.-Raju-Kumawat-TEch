import { NextRequest, NextResponse } from 'next/server'
import { requirePlatformAdmin } from '@/lib/auth-helpers'
import { db } from '@/lib/db'
import { Prisma } from '@prisma/client'

// ── Seed demo data if no audit logs exist ──────────────────────────────────────

async function seedDemoLogsIfEmpty() {
  const count = await db.auditLog.count()
  if (count > 0) return

  const now = new Date()
  const demoLogs = [
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'auth.login',
      category: 'auth',
      details: JSON.stringify({ method: 'credentials', ip: '192.168.1.1' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 5),
    },
    {
      userId: 'seed-teacher-1',
      userName: 'Ravi Sharma',
      userRole: 'teacher',
      action: 'teacher.create',
      category: 'teacher',
      details: JSON.stringify({ teacherId: 'demo-t1', email: 'ravi@example.com' }),
      ipAddress: '192.168.1.2',
      userAgent: 'Firefox/121.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 15),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'student.block',
      category: 'student',
      details: JSON.stringify({ studentId: 'demo-s1', reason: 'Policy violation' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 30),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'organization.update',
      category: 'organization',
      details: JSON.stringify({ orgId: 'demo-org-1', field: 'status', from: 'trial', to: 'active' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 45),
    },
    {
      userId: 'seed-teacher-2',
      userName: 'Priya Patel',
      userRole: 'teacher',
      action: 'content.publish',
      category: 'content',
      details: JSON.stringify({ type: 'test_series', title: 'JEE Mock Test 2024' }),
      ipAddress: '10.0.0.5',
      userAgent: 'Safari/17.2',
      createdAt: new Date(now.getTime() - 1000 * 60 * 60),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'settings.update',
      category: 'settings',
      details: JSON.stringify({ key: 'maintenanceMode', value: 'false' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 90),
    },
    {
      userId: null,
      userName: 'System',
      userRole: 'system',
      action: 'system.backup',
      category: 'system',
      details: JSON.stringify({ type: 'daily', size: '2.3GB' }),
      ipAddress: null,
      userAgent: null,
      createdAt: new Date(now.getTime() - 1000 * 60 * 120),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'auth.login',
      category: 'auth',
      details: JSON.stringify({ method: 'credentials', ip: '192.168.1.1' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 180),
    },
    {
      userId: 'seed-teacher-1',
      userName: 'Ravi Sharma',
      userRole: 'teacher',
      action: 'content.update',
      category: 'content',
      details: JSON.stringify({ type: 'course', title: 'NEET Biology Basics' }),
      ipAddress: '192.168.1.2',
      userAgent: 'Firefox/121.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 240),
    },
    {
      userId: null,
      userName: 'System',
      userRole: 'system',
      action: 'system.cron',
      category: 'system',
      details: JSON.stringify({ job: 'expired_subscriptions_cleanup', affected: 12 }),
      ipAddress: null,
      userAgent: null,
      createdAt: new Date(now.getTime() - 1000 * 60 * 300),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'teacher.suspend',
      category: 'teacher',
      details: JSON.stringify({ teacherId: 'demo-t3', reason: 'Terms violation' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 360),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'auth.failed_login',
      category: 'auth',
      details: JSON.stringify({ email: 'unknown@example.com', ip: '203.0.113.42' }),
      ipAddress: '203.0.113.42',
      userAgent: 'curl/8.1',
      createdAt: new Date(now.getTime() - 1000 * 60 * 420),
    },
    {
      userId: 'seed-teacher-2',
      userName: 'Priya Patel',
      userRole: 'teacher',
      action: 'student.unblock',
      category: 'student',
      details: JSON.stringify({ studentId: 'demo-s2' }),
      ipAddress: '10.0.0.5',
      userAgent: 'Safari/17.2',
      createdAt: new Date(now.getTime() - 1000 * 60 * 480),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'organization.create',
      category: 'organization',
      details: JSON.stringify({ orgId: 'demo-org-2', name: 'New Academy', code: 'NEWACAD' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 540),
    },
    {
      userId: null,
      userName: 'System',
      userRole: 'system',
      action: 'system.alert',
      category: 'system',
      details: JSON.stringify({ type: 'high_cpu', message: 'CPU usage exceeded 90%' }),
      ipAddress: null,
      userAgent: null,
      createdAt: new Date(now.getTime() - 1000 * 60 * 600),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'settings.update',
      category: 'settings',
      details: JSON.stringify({ key: 'emailNotifications', value: 'true' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 720),
    },
    {
      userId: 'seed-teacher-1',
      userName: 'Ravi Sharma',
      userRole: 'teacher',
      action: 'content.delete',
      category: 'content',
      details: JSON.stringify({ type: 'blog', title: 'Outdated Post' }),
      ipAddress: '192.168.1.2',
      userAgent: 'Firefox/121.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 800),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'auth.logout',
      category: 'auth',
      details: JSON.stringify({ method: 'manual' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 900),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'organization.update',
      category: 'organization',
      details: JSON.stringify({ orgId: 'demo-org-1', field: 'adminCommission', from: '20', to: '25' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 1000),
    },
    {
      userId: 'seed-teacher-2',
      userName: 'Priya Patel',
      userRole: 'teacher',
      action: 'auth.login',
      category: 'auth',
      details: JSON.stringify({ method: 'credentials', ip: '10.0.0.5' }),
      ipAddress: '10.0.0.5',
      userAgent: 'Safari/17.2',
      createdAt: new Date(now.getTime() - 1000 * 60 * 1100),
    },
    {
      userId: null,
      userName: 'System',
      userRole: 'system',
      action: 'system.cleanup',
      category: 'system',
      details: JSON.stringify({ job: 'temp_files', deleted: 145 }),
      ipAddress: null,
      userAgent: null,
      createdAt: new Date(now.getTime() - 1000 * 60 * 1200),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'teacher.update',
      category: 'teacher',
      details: JSON.stringify({ teacherId: 'demo-t1', field: 'phone' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 1320),
    },
    {
      userId: 'seed-admin',
      userName: 'Admin User',
      userRole: 'platform_admin',
      action: 'student.create',
      category: 'student',
      details: JSON.stringify({ studentId: 'demo-s3', name: 'Amit Kumar' }),
      ipAddress: '192.168.1.1',
      userAgent: 'Chrome/120.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 1440),
    },
    {
      userId: 'seed-teacher-1',
      userName: 'Ravi Sharma',
      userRole: 'teacher',
      action: 'content.create',
      category: 'content',
      details: JSON.stringify({ type: 'test', title: 'Physics Chapter Test' }),
      ipAddress: '192.168.1.2',
      userAgent: 'Firefox/121.0',
      createdAt: new Date(now.getTime() - 1000 * 60 * 1500),
    },
  ]

  await db.auditLog.createMany({ data: demoLogs })
}

// ── Valid categories ────────────────────────────────────────────────────────────

const VALID_CATEGORIES = ['auth', 'teacher', 'student', 'organization', 'content', 'settings', 'system']

// ── GET handler ─────────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  const auth = await requirePlatformAdmin(req)
  if ('error' in auth) {
    return NextResponse.json({ success: false, error: auth.error }, { status: auth.status })
  }

  try {
    // Seed demo data if empty
    await seedDemoLogsIfEmpty()

    // Parse query params
    const { searchParams } = new URL(req.url)
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10))
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)))
    const category = searchParams.get('category') || undefined
    const action = searchParams.get('action') || undefined
    const search = searchParams.get('search') || undefined
    const dateFrom = searchParams.get('dateFrom') || undefined
    const dateTo = searchParams.get('dateTo') || undefined

    // Build where clause
    const where: Prisma.AuditLogWhereInput = {}

    if (category && VALID_CATEGORIES.includes(category)) {
      where.category = category
    }

    if (action) {
      where.action = { contains: action }
    }

    if (search) {
      where.OR = [
        { userName: { contains: search } },
        { action: { contains: search } },
        { details: { contains: search } },
      ]
    }

    if (dateFrom || dateTo) {
      const createdAtFilter: Prisma.DateTimeFilter = {}
      if (dateFrom) {
        createdAtFilter.gte = new Date(dateFrom)
      }
      if (dateTo) {
        // Add one day to include the entire end date
        const toDate = new Date(dateTo)
        toDate.setDate(toDate.getDate() + 1)
        createdAtFilter.lt = toDate
      }
      where.createdAt = createdAtFilter
    }

    // Fetch paginated logs and stats in parallel
    const [logs, total] = await Promise.all([
      db.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.auditLog.count({ where }),
    ])

    // ── Stats ──
    const [totalAll, byCategoryRows, recentCount] = await Promise.all([
      db.auditLog.count(),
      db.auditLog.groupBy({
        by: ['category'],
        _count: { category: true },
      }),
      db.auditLog.count({
        where: {
          createdAt: {
            gte: new Date(Date.now() - 24 * 60 * 60 * 1000), // last 24 hours
          },
        },
      }),
    ])

    // Build byCategory map with all categories initialized to 0
    const byCategory: Record<string, number> = {}
    for (const cat of VALID_CATEGORIES) {
      byCategory[cat] = 0
    }
    for (const row of byCategoryRows) {
      byCategory[row.category] = row._count.category
    }

    // Format logs for response
    const formattedLogs = logs.map((log) => ({
      id: log.id,
      userId: log.userId,
      userName: log.userName,
      userRole: log.userRole,
      action: log.action,
      category: log.category,
      details: log.details,
      ipAddress: log.ipAddress,
      userAgent: log.userAgent,
      organizationId: log.organizationId,
      createdAt: log.createdAt.toISOString(),
    }))

    const totalPages = Math.ceil(total / limit)

    return NextResponse.json({
      success: true,
      logs: formattedLogs,
      pagination: {
        page,
        limit,
        total,
        totalPages,
      },
      stats: {
        total: totalAll,
        byCategory,
        recentCount,
      },
    })
  } catch (error) {
    console.error('[ADMIN AUDIT LOG] Error fetching audit log data:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch audit log data' },
      { status: 500 }
    )
  }
}
