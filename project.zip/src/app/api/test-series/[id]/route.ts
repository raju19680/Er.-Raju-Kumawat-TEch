import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { checkModuleAccess } from '@/lib/module-guard'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const testSeries = await db.testSeries.findUnique({
      where: { id },
    })

    if (!testSeries) {
      return NextResponse.json(
        { error: 'Test series not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true, testSeries })
  } catch (error) {
    console.error('Failed to fetch test series:', error)
    return NextResponse.json(
      { error: 'Failed to fetch test series' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const accessCheck = await checkModuleAccess(request, 'test_series')
    if (!accessCheck.allowed) {
      return NextResponse.json(
        { success: false, message: accessCheck.error },
        { status: accessCheck.status }
      )
    }

    const { id } = await params
    const body = await request.json()

    // Verify test series exists
    const existing = await db.testSeries.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'Test series not found' },
        { status: 404 }
      )
    }

    // Resolve orgCode to orgId if organizationId is provided
    let orgId = existing.organizationId
    if (body.organizationId) {
      if (body.organizationId.length < 20) {
        const org = await db.organization.findUnique({
          where: { code: body.organizationId },
          select: { id: true },
        })
        orgId = org?.id || body.organizationId
      } else {
        orgId = body.organizationId
      }
    }

    const testSeries = await db.testSeries.update({
      where: { id },
      data: {
        ...(body.title !== undefined && { title: body.title }),
        ...(body.description !== undefined && { description: body.description || null }),
        ...(body.thumbnail !== undefined && { thumbnail: body.thumbnail || null }),
        ...(body.price !== undefined && { price: body.price }),
        ...(body.mrp !== undefined && { mrp: body.mrp }),
        ...(body.category !== undefined && { category: body.category || null }),
        ...(body.isCombo !== undefined && { isCombo: body.isCombo }),
        ...(body.includeTestMaker !== undefined && { includeTestMaker: body.includeTestMaker }),
        ...(body.allowPayment !== undefined && { allowPayment: body.allowPayment }),
        ...(body.validityMode !== undefined && { validityMode: body.validityMode }),
        ...(body.validityDays !== undefined && { validityDays: body.validityDays || null }),
        ...(body.endDate !== undefined && { endDate: body.endDate ? new Date(body.endDate) : null }),
        ...(body.seoTitle !== undefined && { seoTitle: body.seoTitle || null }),
        ...(body.seoDescription !== undefined && { seoDescription: body.seoDescription || null }),
        ...(body.richSnippets !== undefined && { richSnippets: body.richSnippets }),
        ...(body.sortOrder !== undefined && { sortOrder: body.sortOrder }),
        ...(body.status !== undefined && { status: body.status }),
        ...(body.organizationId && { organizationId: orgId }),
      },
    })

    return NextResponse.json({ success: true, testSeries })
  } catch (error) {
    console.error('Failed to update test series:', error)
    return NextResponse.json(
      { error: 'Failed to update test series' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const accessCheck = await checkModuleAccess(request, 'test_series')
    if (!accessCheck.allowed) {
      return NextResponse.json(
        { success: false, message: accessCheck.error },
        { status: accessCheck.status }
      )
    }

    const { id } = await params

    // Verify test series exists
    const existing = await db.testSeries.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { error: 'Test series not found' },
        { status: 404 }
      )
    }

    await db.testSeries.delete({ where: { id } })

    return NextResponse.json({ success: true, message: 'Test series deleted' })
  } catch (error) {
    console.error('Failed to delete test series:', error)
    return NextResponse.json(
      { error: 'Failed to delete test series' },
      { status: 500 }
    )
  }
}
