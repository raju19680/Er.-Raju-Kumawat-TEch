import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { checkModuleAccess } from '@/lib/module-guard'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const search = searchParams.get('search') || ''
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const status = searchParams.get('status') || ''
    const category = searchParams.get('category') || ''
    const skip = (page - 1) * limit

    const where: Record<string, unknown> = {}

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ]
    }

    if (status) {
      where.status = status
    }

    if (category) {
      where.category = category
    }

    const [items, total] = await Promise.all([
      db.testSeries.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          _count: {
            select: { tests: true },
          },
        },
      }),
      db.testSeries.count({ where }),
    ])

    return NextResponse.json({ items, total, page, limit })
  } catch (error) {
    console.error('Failed to fetch test series:', error)
    return NextResponse.json(
      { error: 'Failed to fetch test series' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    // ── Auth check ──
    const accessCheck = await checkModuleAccess(request, 'test-series')
    if (!accessCheck.allowed) {
      return NextResponse.json(
        { error: accessCheck.error },
        { status: accessCheck.status }
      )
    }

    const body = await request.json()

    if (!body.title) {
      return NextResponse.json(
        { error: 'Title is required' },
        { status: 400 }
      )
    }

    if (!body.organizationId) {
      return NextResponse.json(
        { error: 'Organization ID is required' },
        { status: 400 }
      )
    }

    const testSeries = await db.testSeries.create({
      data: {
        title: body.title,
        description: body.description || null,
        thumbnail: body.thumbnail || null,
        price: body.price ?? 0,
        mrp: body.mrp ?? 0,
        category: body.category || null,
        isCombo: body.isCombo ?? false,
        includeTestMaker: body.includeTestMaker ?? false,
        allowPayment: body.allowPayment ?? true,
        validityMode: body.validityMode || 'lifetime',
        validityDays: body.validityDays || null,
        endDate: body.endDate ? new Date(body.endDate) : null,
        seoTitle: body.seoTitle || null,
        seoDescription: body.seoDescription || null,
        richSnippets: body.richSnippets ?? false,
        sortOrder: body.sortOrder ?? 0,
        status: body.status || 'draft',
        organizationId: body.organizationId,
      },
    })

    return NextResponse.json(testSeries, { status: 201 })
  } catch (error) {
    console.error('Failed to create test series:', error)
    return NextResponse.json(
      { error: 'Failed to create test series' },
      { status: 500 }
    )
  }
}
