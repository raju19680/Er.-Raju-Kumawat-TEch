'use client'

import { Component, ReactNode, useCallback, useState } from 'react'
import { useAppStore } from '@/lib/store'
import { AlertTriangle, RefreshCw } from 'lucide-react'

// ── Chunk Load Error Boundary with Auto-Retry ──────────────────────────────
class ChunkErrorBoundary extends Component<
  { children: ReactNode; name: string },
  { hasError: boolean; error: Error | null }
> {
  retryTimer: ReturnType<typeof setTimeout> | null = null

  constructor(props: { children: ReactNode; name: string }) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error: Error) {
    const isChunkError =
      error.name === 'ChunkLoadError' ||
      error.message?.includes('Failed to load chunk') ||
      error.message?.includes('Loading chunk') ||
      error.message?.includes('Loading CSS chunk')

    if (isChunkError) {
      return { hasError: true, error }
    }
    throw error
  }

  componentDidCatch() {
    // Auto-reload after 1.5s to recover from stale chunk hashes
    this.retryTimer = setTimeout(() => {
      window.location.reload()
    }, 1500)
  }

  componentWillUnmount() {
    if (this.retryTimer) clearTimeout(this.retryTimer)
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-white">
          <div className="flex flex-col items-center gap-4 max-w-md text-center px-6">
            <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-amber-50">
              <AlertTriangle className="w-8 h-8 text-amber-500" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Updating...</h2>
            <p className="text-sm text-gray-500">
              The app has been updated. Reloading automatically...
            </p>
            <button
              onClick={() => window.location.reload()}
              className="flex items-center gap-2 px-6 py-2.5 bg-amber-500 text-white rounded-lg font-medium hover:bg-amber-600 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              Reload Now
            </button>
          </div>
        </div>
      )
    }
    return this.props.children
  }
}

// ── Direct imports (no next/dynamic — avoids stale chunk issues) ────────────
import CMSLayoutComponent from '@/components/cms/cms-layout'
import AdminLayoutComponent from '@/components/admin/admin-layout'
import StudentLayoutComponent from '@/components/student-portal/student-layout'
import LoginComponent from '@/components/login/login-page'

// ── View Router ─────────────────────────────────────────────────────────────
function ViewRouter() {
  const currentView = useAppStore((s) => s.currentView)

  switch (currentView) {
    case 'cms':
      return <CMSLayoutComponent />
    case 'admin':
      return <AdminLayoutComponent />
    case 'student':
      return <StudentLayoutComponent />
    case 'login':
    default:
      return <LoginComponent />
  }
}

// ── Main Page ────────────────────────────────────────────────────────────────
export default function Home() {
  return (
    <ChunkErrorBoundary name="Application">
      <ViewRouter />
    </ChunkErrorBoundary>
  )
}
